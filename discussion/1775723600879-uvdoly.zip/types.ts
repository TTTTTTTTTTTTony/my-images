export interface Project {
  id: string;
  title: string;
  description: string;
  content?: string; // Markdown content for project details
  tags: string[];
  imageUrl: string;
  link?: string;
  github?: string;
  pinned?: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  summary: string;
  content: string; // Markdown content
  coverImage?: string;
  date: string;
  category: string;
  /** @deprecated 使用 pinned */
  isFavorite: boolean;
  /** 置顶（原「收藏」） */
  pinned?: boolean;
}

export interface Skill {
  name: string;
  level: number; // 0-100
  category: string;
  /** emoji、关键词或图片 URL */
  icon: string;
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  period: string;
  description: string[];
  imageUrl?: string; // Added to support history images
  content?: string; // Markdown content for details
}

export interface Achievement {
  id: string;
  title: string;
  score: string;
  description: string;
  imageUrl: string;
  content?: string; // Markdown content for details
}

export interface FutureAchievement {
  id: string;
  title: string;
  goal: string;
  description: string;
  imageUrl: string;
  link?: string;
  icon?: 'study' | 'trophy' | 'university' | string; // Added icon type
  content?: string; // Markdown content for details
}

export enum ChatSender {
  User = 'user',
  Bot = 'bot',
}

export interface ChatMessage {
  id: string;
  sender: ChatSender;
  text: string;
  isStreaming?: boolean;
}

export interface SocialLink {
  id: string;
  name: string;
  icon: string;
  url: string;
  /** 自定义图标图（优先于 icon 关键词） */
  imageUrl?: string;
}

export interface ContactMethod {
  id: string;
  /** entry：一行文案 + 可选链接；qr：二维码图片 */
  type: 'entry' | 'qr';
  /** 主标题 */
  title: string;
  /** 副文案（如微信号、说明） */
  subtitle?: string;
  /** 可选外链 */
  href?: string;
  icon?: string;
  imageUrl?: string;
  name?: string;
  value?: string;
}

export interface ProfileData {
  logoUrl: string;
  name: string;
  title: string;
  tagline: string;
  about: string;
  location: string;
  socials: SocialLink[];
  contacts: ContactMethod[];
  skills: Skill[];
  projects: Project[];
  experience: Experience[];
  achievements: Achievement[];
  futureAchievements: FutureAchievement[];
  blogPosts: BlogPost[];
  blogCategories: string[];
  theme?: 'light' | 'dark';
  /** 仅用于首页 Hero「你好我是」区域背景图 */
  heroBackground?: string;
  /** @deprecated 仅兼容旧数据；新逻辑不再使用全站背景 */
  backgrounds?: {
    home?: string;
    projects?: string;
    blog?: string;
  };
  banners?: {
    projects?: string;
    blog?: string;
  };
  notices?: {
    projects?: string;
    blog?: string;
  };
  latestRelease?: string;
}