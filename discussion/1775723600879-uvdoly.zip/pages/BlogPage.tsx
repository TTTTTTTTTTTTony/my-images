import React, { useState, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { usePortfolio } from "../context/PortfolioContext";
import { EditableText } from "../components/EditableText";
import { EditableImage } from "../components/EditableImage";
import { ReorderButtons } from "../components/ReorderButtons";
import { MarkdownEditor } from "../components/MarkdownEditor";
import { Comments } from "../components/Comments";
import { Plus, Trash2, X, Pin, Search, ChevronLeft } from "lucide-react";

const BlogPage: React.FC = () => {
  const { data, updateField, addArrayItem, removeArrayItem, isEditMode } =
    usePortfolio();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState<string>("全部");
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);

  const selectedPostIndex = id
    ? data.blogPosts.findIndex((p) => p.id === id)
    : null;

  const handleAddPost = () => {
    const newId = Math.floor(100000 + Math.random() * 900000).toString();
    addArrayItem(["blogPosts"], {
      id: newId,
      title: "新博客文章",
      summary: "这是一篇新文章的简短摘要...",
      content: "## 新文章标题\n\n在这里开始编写你的博客内容...",
      coverImage: "https://placehold.co/800x400/1e293b/FFF?text=New+Post",
      date: new Date().toISOString().split("T")[0],
      category: data.blogCategories[0] || "未分类",
      isFavorite: false,
      pinned: false,
    });
    navigate(`/blog/${newId}`);
  };

  const handleAddCategory = () => {
    const newCategory = prompt("请输入新分类名称：");
    if (newCategory && !data.blogCategories.includes(newCategory)) {
      addArrayItem(["blogCategories"], newCategory);
    }
  };

  const filteredPostsRaw = data.blogPosts.filter((post) => {
    const pinned = post.pinned ?? post.isFavorite;
    const matchesCategory =
      activeCategory === "全部" ||
      (activeCategory === "置顶" && pinned) ||
      post.category === activeCategory;
    const query = searchQuery.toLowerCase();
    const matchesSearch =
      post.title.toLowerCase().includes(query) ||
      post.summary.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  }).sort((a, b) => {
    const aPinned = a.pinned ?? a.isFavorite;
    const bPinned = b.pinned ?? b.isFavorite;
    if (aPinned && !bPinned) return -1;
    if (!aPinned && bPinned) return 1;
    return 0;
  });

  const totalPages = Math.max(1, Math.ceil(filteredPostsRaw.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const pagedPosts = filteredPostsRaw.slice(
    (safePage - 1) * pageSize,
    safePage * pageSize,
  );

  return (
    <div className="min-h-screen pb-20">
      {/* Banner */}
      {(data.banners?.blog || isEditMode) && (
        <div className="w-full h-48 md:h-64 relative group">
          {isEditMode ? (
            <EditableImage
              src={
                data.banners?.blog ||
                "https://placehold.co/1920x400/1e293b/FFF?text=Blog+Banner"
              }
              alt="Blog Banner"
              onSave={(val) => updateField(["banners", "blog"], val)}
              folderPath="banners"
              className="w-full h-full"
            />
          ) : (
            <img
              src={data.banners?.blog}
              alt="Blog Banner"
              className="w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-black/30 pointer-events-none"></div>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <h1 className="text-4xl md:text-5xl font-bold text-white drop-shadow-lg tracking-wider">
              我的空间
            </h1>
          </div>
          {isEditMode && data.banners?.blog && (
            <button
              onClick={() => updateField(["banners", "blog"], "")}
              className="absolute top-4 right-4 bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity z-10"
              title="移除横幅"
            >
              <Trash2 size={16} />
            </button>
          )}
        </div>
      )}

      <div className={`max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 ${!(data.banners?.blog || isEditMode) ? 'pt-24' : 'mt-8'}`}>
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-6">
          {!data.banners?.blog && (
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">
                我的空间
              </h2>
              <div className="w-20 h-1 bg-primary rounded-full"></div>
            </div>
          )}

          <div className="flex items-center gap-4 w-full md:w-auto flex-1 md:justify-end">
            <div className="relative w-full md:w-64">
              <input
                type="text"
                placeholder="搜索文章..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white dark:bg-slate-800 text-slate-900 dark:text-white border border-gray-300 dark:border-gray-700 rounded-full pl-10 pr-4 py-2 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors"
              />
              <Search
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                size={18}
              />
            </div>

            {isEditMode && (
              <button
                onClick={handleAddPost}
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-full flex items-center gap-2 transition-colors flex-shrink-0"
              >
                <Plus size={18} /> 写文章
              </button>
            )}
          </div>
        </div>

        {/* Notice Board */}
        {(data.notices?.blog || isEditMode) && (
          <div className="mb-8 p-4 bg-primary/10 border border-primary/20 rounded-xl text-slate-800 dark:text-slate-200 relative group">
            <div className="flex items-start gap-2">
              <span className="text-primary font-bold mt-1">📢 公告：</span>
              <div className="flex-1">
                <EditableText
                  as="div"
                  value={data.notices?.blog || "点击此处编辑公告内容..."}
                  onSave={(val) => updateField(["notices", "blog"], val)}
                  className="w-full"
                  multiline
                />
              </div>
            </div>
            {isEditMode && data.notices?.blog && (
              <button
                onClick={() => updateField(["notices", "blog"], "")}
                className="absolute top-2 right-2 text-red-500 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                title="清除公告"
              >
                <X size={16} />
              </button>
            )}
          </div>
        )}

        {/* Categories */}
        <div className="flex flex-wrap gap-3 mb-8">
          <button
            onClick={() => setActiveCategory("全部")}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${activeCategory === "全部" ? "bg-primary text-white" : "bg-gray-100 dark:bg-slate-800 text-slate-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-700"}`}
          >
            全部
          </button>

          {data.blogCategories.map((category, index) => (
            <div key={index} className="relative group/cat">
              <button
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${activeCategory === category ? "bg-primary text-white" : "bg-gray-100 dark:bg-slate-800 text-slate-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-700"}`}
              >
                {category}
              </button>
              {isEditMode && (
                <button
                  onClick={() => removeArrayItem(["blogCategories"], index)}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover/cat:opacity-100 transition-opacity"
                >
                  <X size={12} />
                </button>
              )}
            </div>
          ))}

          {isEditMode && (
            <button
              onClick={handleAddCategory}
              className="px-4 py-2 rounded-full text-sm font-medium border border-dashed border-gray-400 dark:border-gray-600 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors flex items-center gap-1"
            >
              <Plus size={14} /> 添加分类
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-end gap-3 mb-4 text-sm text-slate-600 dark:text-gray-400">
          <label className="flex items-center gap-2">
            每页
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
              className="bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-700 rounded px-2 py-1"
            >
              {[5, 10, 20].map((n) => (
                <option key={n} value={n}>
                  {n} 条
                </option>
              ))}
            </select>
          </label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={safePage <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="px-3 py-1 rounded border border-gray-300 dark:border-gray-600 disabled:opacity-40"
            >
              上一页
            </button>
            <span>
              {safePage} / {totalPages}
            </span>
            <button
              type="button"
              disabled={safePage >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              className="px-3 py-1 rounded border border-gray-300 dark:border-gray-600 disabled:opacity-40"
            >
              下一页
            </button>
          </div>
        </div>

        {/* Blog List (Zhihu Style) */}
        <div className="flex flex-col gap-4">
          {pagedPosts.map((post) => {
            const index = data.blogPosts.findIndex((p) => p.id === post.id);
            const pinned = post.pinned ?? post.isFavorite;
            return (
              <div
                key={post.id || index}
                className="bg-white dark:bg-secondary p-4 md:p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow flex flex-col md:flex-row gap-6 cursor-pointer border border-gray-100 dark:border-gray-800 relative group"
                onClick={() => navigate(`/blog/${post.id}`)}
              >
                {isEditMode && (
                  <>
                    <div
                      className="absolute top-2 right-2 z-20"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        onClick={() => {
                          const next = !pinned;
                          updateField(["blogPosts", index.toString()], {
                            ...data.blogPosts[index],
                            pinned: next,
                            isFavorite: next,
                          });
                        }}
                        className={`p-2 rounded-full shadow-lg ${pinned ? "bg-amber-500 text-white" : "bg-slate-700 text-gray-300 hover:bg-slate-600"}`}
                        title="置顶"
                      >
                        <Pin
                          size={16}
                          className={pinned ? "fill-current" : ""}
                        />
                      </button>
                    </div>
                    <div
                      className="absolute bottom-2 right-2 flex items-center gap-2 z-20"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ReorderButtons
                        path={["blogPosts"]}
                        index={index}
                        totalLength={data.blogPosts.length}
                        className="flex-row scale-90"
                      />
                      <button
                        onClick={() => removeArrayItem(["blogPosts"], index)}
                        className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </>
                )}

                <div className="flex-1 flex flex-col">
                  <h3 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-primary transition-colors flex items-center gap-2">
                    {pinned && <Pin size={20} className="text-amber-500 fill-current flex-shrink-0" />}
                    {post.title}
                  </h3>
                  <p className="text-slate-600 dark:text-gray-400 line-clamp-3 mb-4 flex-grow leading-relaxed">
                    {post.summary}
                  </p>
                  <div className="flex items-center gap-4 text-sm text-slate-500 dark:text-gray-500 mt-auto">
                    <span className="bg-gray-100 dark:bg-slate-800 px-2 py-1 rounded">
                      {post.category}
                    </span>
                    <span>{post.date}</span>
                  </div>
                </div>

                {post.coverImage && (
                  <div className="w-full md:w-48 h-32 md:h-auto flex-shrink-0 overflow-hidden rounded-lg">
                    <img
                      src={post.coverImage}
                      alt={post.title}
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {filteredPostsRaw.length === 0 && (
          <div className="text-center py-20 text-gray-500">
            没有找到相关文章。
          </div>
        )}
      </div>

      {/* Blog Detail Modal (Fullscreen) */}
      {selectedPostIndex !== null && selectedPostIndex !== -1 && (
        <div className="fixed inset-0 z-[100] bg-white dark:bg-dark overflow-y-auto flex flex-col animate-fade-in">
          {/* Header */}
          <div className="sticky top-0 z-50 bg-white/80 dark:bg-dark/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 px-4 py-4 flex justify-between items-center">
            <button
              onClick={() => navigate("/blog")}
              className="flex items-center gap-2 text-slate-600 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              <ChevronLeft size={24} /> 返回文章列表
            </button>
            {isEditMode && (
              <span className="text-sm font-bold text-primary px-3 py-1 bg-primary/10 rounded-full">
                编辑模式
              </span>
            )}
          </div>

          <div className="max-w-4xl mx-auto w-full p-6 md:p-10 flex-grow flex flex-col gap-8">
            {/* Cover Image */}
            <div className="w-full h-64 md:h-96 rounded-2xl overflow-hidden shadow-xl relative">
              {isEditMode ? (
                <EditableImage
                  src={data.blogPosts[selectedPostIndex].coverImage || ""}
                  alt="Cover"
                  onSave={(val) =>
                    updateField(
                      ["blogPosts", selectedPostIndex.toString(), "coverImage"],
                      val,
                    )
                  }
                  className="w-full h-full"
                  folderPath={`blog/${data.blogPosts[selectedPostIndex].id}`}
                />
              ) : (
                data.blogPosts[selectedPostIndex].coverImage && (
                  <img
                    src={data.blogPosts[selectedPostIndex].coverImage}
                    className="w-full h-full object-cover"
                    alt="Cover"
                  />
                )
              )}
            </div>

            {/* Title & Meta */}
            <div className="flex flex-col gap-6">
              {isEditMode ? (
                <EditableText
                  as="h1"
                  value={data.blogPosts[selectedPostIndex].title}
                  onSave={(val) =>
                    updateField(
                      ["blogPosts", selectedPostIndex.toString(), "title"],
                      val,
                    )
                  }
                  className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white"
                />
              ) : (
                <h1 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white">
                  {data.blogPosts[selectedPostIndex].title}
                </h1>
              )}

              <div className="flex items-center gap-4 text-slate-500 dark:text-gray-400">
                {isEditMode ? (
                  <select
                    value={data.blogPosts[selectedPostIndex].category}
                    onChange={(e) =>
                      updateField(
                        ["blogPosts", selectedPostIndex.toString(), "category"],
                        e.target.value,
                      )
                    }
                    className="bg-gray-100 dark:bg-slate-800 text-slate-900 dark:text-white border border-gray-300 dark:border-gray-700 rounded px-3 py-1"
                  >
                    {data.blogCategories.map((cat, i) => (
                      <option key={i} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                ) : (
                  <span className="bg-gray-100 dark:bg-slate-800 px-3 py-1 rounded-full text-sm">
                    {data.blogPosts[selectedPostIndex].category}
                  </span>
                )}

                {isEditMode ? (
                  <input
                    type="date"
                    value={data.blogPosts[selectedPostIndex].date}
                    onChange={(e) =>
                      updateField(
                        ["blogPosts", selectedPostIndex.toString(), "date"],
                        e.target.value,
                      )
                    }
                    className="bg-transparent border-b border-gray-300 dark:border-gray-700 focus:outline-none"
                  />
                ) : (
                  <span>{data.blogPosts[selectedPostIndex].date}</span>
                )}
              </div>

              {isEditMode ? (
                <div className="bg-gray-50 dark:bg-slate-800/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                  <label className="text-xs text-gray-500 uppercase tracking-wider mb-2 block">
                    文章摘要 (显示在列表中)
                  </label>
                  <EditableText
                    as="p"
                    value={data.blogPosts[selectedPostIndex].summary}
                    onSave={(val) =>
                      updateField(
                        ["blogPosts", selectedPostIndex.toString(), "summary"],
                        val,
                      )
                    }
                    className="text-lg text-slate-600 dark:text-gray-400"
                    multiline
                  />
                </div>
              ) : (
                <p className="text-xl text-slate-600 dark:text-gray-400 italic border-l-4 border-primary pl-4">
                  {data.blogPosts[selectedPostIndex].summary}
                </p>
              )}
            </div>

            <div className="w-full h-px bg-gray-200 dark:bg-gray-800 my-4"></div>

            {/* Markdown Content */}
            <div className="pb-10">
              <MarkdownEditor
                value={data.blogPosts[selectedPostIndex].content}
                onSave={(val) =>
                  updateField(
                    ["blogPosts", selectedPostIndex.toString(), "content"],
                    val,
                  )
                }
                folderPath={`blog/${data.blogPosts[selectedPostIndex].id}`}
              />
            </div>

            {/* Comments Section */}
            <div className="pb-20">
              <Comments targetId={data.blogPosts[selectedPostIndex].id} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BlogPage;
