import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Users,
  Eye,
  MessageSquare,
  Bell,
  Activity,
  CheckCircle2,
  Trash2,
  Pencil,
  Check,
  Settings,
  ArrowLeft,
} from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface NotificationRow {
  id: string;
  type: string;
  message: string;
  detail?: string;
  created_at: string;
  read: number;
}

interface DbUser {
  id: number;
  username: string;
  email: string;
  role: string;
  avatar?: string;
  bio?: string;
  email_public?: number;
  muted_until?: string;
}

interface DbComment {
  id: string;
  target_id: string;
  author_name: string;
  content: string;
  created_at: string;
}

export const AdminDashboard: React.FC = () => {
  const { currentUser, data } = usePortfolio();
  const location = useLocation();
  const navigate = useNavigate();

  const [stats, setStats] = useState({ users: 0, views: 0, comments: 0 });
  const [notifications, setNotifications] = useState<NotificationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [adminUsers, setAdminUsers] = useState<DbUser[]>([]);
  const [commentsAll, setCommentsAll] = useState<DbComment[]>([]);
  const [editingComment, setEditingComment] = useState<string | null>(null);
  const [editCommentText, setEditCommentText] = useState('');

  const targetTitle = useMemo(() => {
    const map: Record<string, string> = {};
    data.blogPosts.forEach((p) => {
      map[p.id] = p.title;
    });
    data.projects.forEach((p) => {
      map[p.id] = p.title;
    });
    return map;
  }, [data.blogPosts, data.projects]);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError('');
    try {
      const res = await fetch('/api/admin');
      if (!res.ok) throw new Error(await res.text());
      const d = await res.json();
      setStats({
        users: d.users ?? 0,
        views: d.views ?? 0,
        comments: d.comments ?? 0,
      });
      setNotifications(Array.isArray(d.notifications) ? d.notifications : []);
    } catch (e: any) {
      setLoadError(e?.message || '加载失败');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadUsers = useCallback(async () => {
    try {
      const res = await fetch('/api/users');
      if (!res.ok) return;
      const d = await res.json();
      setAdminUsers(d.users || []);
    } catch {
      // ignore
    }
  }, []);

  const loadCommentsAll = useCallback(async () => {
    try {
      const res = await fetch('/api/comments?all=1');
      if (!res.ok) return;
      const list = await res.json();
      setCommentsAll(Array.isArray(list) ? list : []);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (['owner', 'senior_admin'].includes(currentUser?.role || '')) {
      load();
    }
  }, [currentUser, load]);

  useEffect(() => {
    if (!['owner', 'senior_admin'].includes(currentUser?.role || '')) return;
    if (location.pathname.includes('/users')) loadUsers();
    if (location.pathname.includes('/comments')) loadCommentsAll();
  }, [location.pathname, currentUser, loadUsers, loadCommentsAll]);

  const markRead = async (ids: string[]) => {
    if (!ids.length) return;
    try {
      await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ markReadIds: ids }),
      });
      setNotifications((prev) => prev.map((n) => (ids.includes(n.id) ? { ...n, read: 1 } : n)));
    } catch {
      // ignore
    }
  };

  const handleNotificationClick = (n: NotificationRow) => {
    markRead([n.id]);
    if (n.type === 'register') {
      navigate('/admin/users');
      return;
    }
    if (n.type === 'comment') {
      try {
        const detail = n.detail ? JSON.parse(n.detail) : {};
        const tid = detail.targetId as string;
        if (tid) {
          if (data.blogPosts.some((p) => p.id === tid)) navigate(`/blog/${tid}`);
          else if (data.projects.some((p) => p.id === tid)) navigate(`/projects/${tid}`);
          else navigate('/admin/comments');
        }
      } catch {
        navigate('/admin/comments');
      }
    }
  };

  const updateUserRole = async (username: string, role: string) => {
    const res = await fetch('/api/users', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, role, adminUsername: currentUser?.username }),
    });
    try {
      const d = await res.json();
      if (d?.user) {
        setAdminUsers((prev) => prev.map((u) => (u.username === username ? { ...u, ...d.user } : u)));
        return;
      } else if (d?.error) {
        alert(d.error);
      }
    } catch {
      // ignore
    }
    loadUsers();
  };

  const deleteUser = async (username: string) => {
    if (!window.confirm(`确定删除用户 ${username}？`)) return;
    await fetch(`/api/users?username=${encodeURIComponent(username)}`, { method: 'DELETE' });
    loadUsers();
    load();
  };

  const saveCommentAdmin = async (id: string) => {
    await fetch('/api/comments', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, content: editCommentText.trim(), editorUsername: currentUser?.username }),
    });
    setEditingComment(null);
    loadCommentsAll();
  };

  const deleteCommentAdmin = async (id: string) => {
    if (!window.confirm('删除该评论？')) return;
    await fetch(
      `/api/comments?id=${encodeURIComponent(id)}&editorUsername=${encodeURIComponent(currentUser?.username || '')}`,
      { method: 'DELETE' }
    );
    loadCommentsAll();
    load();
  };

  const formatTime = (iso: string) => {
    try {
      return new Intl.DateTimeFormat('zh-CN', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(iso));
    } catch {
      return iso;
    }
  };

  if (!currentUser || !['owner', 'senior_admin'].includes(currentUser.role)) {
    return (
      <div className="min-h-screen pt-24 px-4 flex items-center justify-center bg-white dark:bg-dark">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-500 mb-2">访问被拒绝</h2>
          <p className="text-gray-500 dark:text-gray-400">您没有权限访问此页面。</p>
        </div>
      </div>
    );
  }

  const isUsers = location.pathname.includes('/users');
  const isComments = location.pathname.includes('/comments');
  const isDms = location.pathname.includes('/dms');
  const isOverview = !isUsers && !isComments && !isDms;

  const commentsByTarget = useMemo(() => {
    const m: Record<string, DbComment[]> = {};
    commentsAll.forEach((c) => {
      if (!m[c.target_id]) m[c.target_id] = [];
      m[c.target_id].push(c);
    });
    return m;
  }, [commentsAll]);

  return (
    <div className="min-h-screen pt-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto bg-white dark:bg-dark pb-16">
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <Link
          to="/admin"
          className={`text-sm px-3 py-1.5 rounded-lg ${isOverview ? 'bg-primary/15 text-primary' : 'text-slate-600 dark:text-gray-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
        >
          概览
        </Link>
        <Link
          to="/admin/users"
          className={`text-sm px-3 py-1.5 rounded-lg ${isUsers ? 'bg-primary/15 text-primary' : 'text-slate-600 dark:text-gray-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
        >
          用户管理
        </Link>
        <Link
          to="/admin/comments"
          className={`text-sm px-3 py-1.5 rounded-lg ${isComments ? 'bg-primary/15 text-primary' : 'text-slate-600 dark:text-gray-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
        >
          评论管理
        </Link>
        <Link
          to="/admin/dms"
          className={`text-sm px-3 py-1.5 rounded-lg ${isDms ? 'bg-primary/15 text-primary' : 'text-slate-600 dark:text-gray-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
        >
          私聊管理
        </Link>
        <Link to="/" className="ml-auto flex items-center gap-1 text-sm text-gray-500 hover:text-primary">
          <ArrowLeft size={16} /> 回首页
        </Link>
      </div>

      {isOverview && (
        <>
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
              <Activity className="text-primary" />
              管理控制台
            </h1>
            <p className="text-gray-500 dark:text-gray-400 mt-2">欢迎，{currentUser.username}。</p>
            {loadError && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{loadError}</p>}
            <button type="button" onClick={() => load()} className="mt-3 text-sm text-primary hover:underline">
              {loading ? '刷新中…' : '刷新数据'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <Link to="/admin" className="block bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 hover:border-primary/40 transition-colors">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">总浏览量</h3>
                <Eye size={24} className="text-blue-500" />
              </div>
              <p className="text-4xl font-bold text-slate-900 dark:text-white">{stats.views}</p>
            </Link>

            <Link to="/admin/users" className="block bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 hover:border-primary/40 transition-colors">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">注册用户</h3>
                <Users size={24} className="text-green-500" />
              </div>
              <p className="text-4xl font-bold text-slate-900 dark:text-white">{stats.users}</p>
              <p className="text-xs text-gray-500 mt-2">点击进入用户管理</p>
            </Link>

            <Link to="/admin/comments" className="block bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 hover:border-primary/40 transition-colors">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">总评论数</h3>
                <MessageSquare size={24} className="text-purple-500" />
              </div>
              <p className="text-4xl font-bold text-slate-900 dark:text-white">{stats.comments}</p>
              <p className="text-xs text-gray-500 mt-2">点击进入评论管理</p>
            </Link>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Bell className="text-primary" size={20} />
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">通知</h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  const unread = notifications.filter((n) => !n.read).map((n) => n.id);
                  markRead(unread);
                }}
                className="text-sm flex items-center gap-1 text-primary hover:underline"
              >
                <CheckCircle2 size={16} /> 全部标为已读
              </button>
            </div>
            <div className="divide-y divide-gray-100 dark:divide-gray-700">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-gray-500 dark:text-gray-400 text-sm">暂无通知</div>
              ) : (
                notifications.map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => handleNotificationClick(n)}
                    className={`w-full text-left p-6 flex items-start gap-4 hover:bg-gray-50 dark:hover:bg-slate-800/50 transition-colors ${
                      n.read ? 'opacity-70' : ''
                    }`}
                  >
                    <div
                      className={`w-2 h-2 mt-2 rounded-full flex-shrink-0 ${
                        n.type === 'register' ? 'bg-blue-500' : 'bg-green-500'
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-slate-900 dark:text-white font-medium">{n.message}</p>
                      <p className="text-gray-400 dark:text-gray-500 text-xs mt-2">{formatTime(n.created_at)}</p>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-800">
            <h4 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Settings size={20} className="text-primary" />
              数据清理与维护
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
                <h5 className="font-semibold mb-2 text-slate-900 dark:text-white">清理社区聊天数据</h5>
                <p className="text-sm text-gray-500 mb-4">删除指定天数前的社区聊天记录。</p>
                <button
                  onClick={async () => {
                    const days = window.prompt('请输入要清理多少天以前的社区聊天记录（例如：30）：', '30');
                    if (!days || isNaN(Number(days))) return;
                    if (!window.confirm(`确定要清理${days}天前的社区聊天记录吗？此操作不可恢复。`)) return;
                    try {
                      const res = await fetch('/api/reset', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'clear_community_chats', days: Number(days), adminUsername: currentUser.username })
                      });
                      if (res.ok) alert('清理成功');
                      else alert('清理失败');
                    } catch (e) {
                      alert('清理失败');
                    }
                  }}
                  className="px-4 py-2 bg-red-100 text-red-600 hover:bg-red-200 dark:bg-red-900/30 dark:hover:bg-red-900/50 rounded-lg text-sm transition-colors"
                >
                  清理社区聊天
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
                <h5 className="font-semibold mb-2 text-slate-900 dark:text-white">清理群主聊天数据</h5>
                <p className="text-sm text-gray-500 mb-4">删除指定天数前的群主聊天记录。</p>
                <button
                  onClick={async () => {
                    const days = window.prompt('请输入要清理多少天以前的群主聊天记录（例如：30）：', '30');
                    if (!days || isNaN(Number(days))) return;
                    if (!window.confirm(`确定要清理${days}天前的群主聊天记录吗？此操作不可恢复。`)) return;
                    try {
                      const res = await fetch('/api/reset', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'clear_owner_chats', days: Number(days), adminUsername: currentUser.username })
                      });
                      if (res.ok) alert('清理成功');
                      else alert('清理失败');
                    } catch (e) {
                      alert('清理失败');
                    }
                  }}
                  className="px-4 py-2 bg-red-100 text-red-600 hover:bg-red-200 dark:bg-red-900/30 dark:hover:bg-red-900/50 rounded-lg text-sm transition-colors"
                >
                  清理群主聊天
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
                <h5 className="font-semibold mb-2 text-slate-900 dark:text-white">清理私聊数据</h5>
                <p className="text-sm text-gray-500 mb-4">删除指定天数前的私聊记录。</p>
                <button
                  onClick={async () => {
                    const days = window.prompt('请输入要清理多少天以前的私聊记录（例如：30）：', '30');
                    if (!days || isNaN(Number(days))) return;
                    if (!window.confirm(`确定要清理${days}天前的私聊记录吗？此操作不可恢复。`)) return;
                    try {
                      const res = await fetch('/api/reset', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'clear_dms', days: Number(days), adminUsername: currentUser.username })
                      });
                      if (res.ok) alert('清理成功');
                      else alert('清理失败');
                    } catch (e) {
                      alert('清理失败');
                    }
                  }}
                  className="px-4 py-2 bg-red-100 text-red-600 hover:bg-red-200 dark:bg-red-900/30 dark:hover:bg-red-900/50 rounded-lg text-sm transition-colors"
                >
                  清理私聊数据
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
                <h5 className="font-semibold mb-2 text-slate-900 dark:text-white">清理已读通知</h5>
                <p className="text-sm text-gray-500 mb-4">删除指定天数前的所有已读通知。</p>
                <button
                  onClick={async () => {
                    const days = window.prompt('请输入要清理多少天以前的已读通知（例如：7）：', '7');
                    if (!days || isNaN(Number(days))) return;
                    if (!window.confirm(`确定要清理${days}天前的已读通知吗？`)) return;
                    try {
                      const res = await fetch('/api/reset', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'clear_notifications', days: Number(days), adminUsername: currentUser.username })
                      });
                      if (res.ok) alert('清理成功');
                      else alert('清理失败');
                    } catch (e) {
                      alert('清理失败');
                    }
                  }}
                  className="px-4 py-2 bg-amber-100 text-amber-600 hover:bg-amber-200 dark:bg-amber-900/30 dark:hover:bg-amber-900/50 rounded-lg text-sm transition-colors"
                >
                  清理已读通知
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
                <h5 className="font-semibold mb-2 text-slate-900 dark:text-white">清理未活跃用户</h5>
                <p className="text-sm text-gray-500 mb-4">删除指定天数内未访问的普通用户账号。</p>
                <button
                  onClick={async () => {
                    const days = window.prompt('请输入要清理多少天未活跃的用户（例如：90）：', '90');
                    if (!days || isNaN(Number(days))) return;
                    if (!window.confirm(`确定要清理${days}天未活跃的用户吗？`)) return;
                    try {
                      const res = await fetch('/api/reset', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'clear_inactive_users', days: Number(days), adminUsername: currentUser.username })
                      });
                      if (res.ok) alert('清理成功');
                      else alert('清理失败');
                    } catch (e) {
                      alert('清理失败');
                    }
                  }}
                  className="px-4 py-2 bg-orange-100 text-orange-600 hover:bg-orange-200 dark:bg-orange-900/30 dark:hover:bg-orange-900/50 rounded-lg text-sm transition-colors"
                >
                  清理未活跃用户
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
                <h5 className="font-semibold mb-2 text-slate-900 dark:text-white">清理多余媒体数据</h5>
                <p className="text-sm text-gray-500 mb-4">清理 GitHub 上不再使用的媒体数据。</p>
                <button
                  onClick={async () => {
                    if (!window.confirm('确定要清理不再使用的媒体数据吗？')) return;
                    try {
                      const res = await fetch('/api/reset', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'clear_unused_media', adminUsername: currentUser.username })
                      });
                      if (res.ok) alert('清理成功');
                      else alert('清理失败');
                    } catch (e) {
                      alert('清理失败');
                    }
                  }}
                  className="px-4 py-2 bg-blue-100 text-blue-600 hover:bg-blue-200 dark:bg-blue-900/30 dark:hover:bg-blue-900/50 rounded-lg text-sm transition-colors"
                >
                  清理媒体数据
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
                <h5 className="font-semibold mb-2 text-slate-900 dark:text-white">整理 Cloudflare 数据</h5>
                <p className="text-sm text-gray-500 mb-4">清理 D1 数据库中的多余数据并优化。</p>
                <button
                  onClick={async () => {
                    if (!window.confirm('确定要整理 Cloudflare 数据吗？')) return;
                    try {
                      const res = await fetch('/api/reset', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'optimize_db', adminUsername: currentUser.username })
                      });
                      if (res.ok) alert('整理成功');
                      else alert('整理失败');
                    } catch (e) {
                      alert('整理失败');
                    }
                  }}
                  className="px-4 py-2 bg-purple-100 text-purple-600 hover:bg-purple-200 dark:bg-purple-900/30 dark:hover:bg-purple-900/50 rounded-lg text-sm transition-colors"
                >
                  整理数据库
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {isUsers && (
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">用户管理</h2>
          <div className="overflow-x-auto border border-gray-200 dark:border-gray-700 rounded-xl">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-50 dark:bg-slate-900/80 text-slate-600 dark:text-gray-400">
                <tr>
                  <th className="px-4 py-3">用户</th>
                  <th className="px-4 py-3">邮箱</th>
                  <th className="px-4 py-3">角色</th>
                  <th className="px-4 py-3">操作</th>
                </tr>
              </thead>
              <tbody>
                {adminUsers.map((u) => (
                  <tr key={u.id} className="border-t border-gray-100 dark:border-gray-800">
                    <td className="px-4 py-3 text-slate-900 dark:text-white font-medium">{u.username}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{u.email || '—'}</td>
                    <td className="px-4 py-3">
                      <select
                        value={u.role}
                        disabled={u.username === 'owner' || (currentUser.role !== 'owner' && u.role === 'senior_admin')}
                        onChange={(e) => updateUserRole(u.username, e.target.value)}
                        className="bg-white dark:bg-slate-900 border border-gray-300 dark:border-gray-700 rounded px-2 py-1"
                      >
                        <option value="user">user</option>
                        <option value="group_admin">群聊管理员</option>
                        <option value="senior_admin">高级管理员</option>
                        {u.username === 'owner' && <option value="owner">owner</option>}
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        disabled={u.username === 'owner' || (currentUser.role !== 'owner' && u.role === 'senior_admin')}
                        onClick={() => deleteUser(u.username)}
                        className="text-red-600 hover:underline disabled:opacity-30 disabled:cursor-not-allowed text-xs"
                      >
                        删除
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {isComments && (
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">评论管理</h2>
          <div className="space-y-8">
            {Object.keys(commentsByTarget).map((tid) => (
              <div key={tid} className="border border-gray-200 dark:border-gray-800 rounded-xl p-4 bg-slate-50 dark:bg-slate-900/40">
                <h3 className="font-bold text-slate-900 dark:text-white mb-2">
                  {targetTitle[tid] || `内容 ID: ${tid}`}
                </h3>
                <div className="space-y-3">
                  {(commentsByTarget[tid] || []).map((c) => (
                    <div key={c.id} className="bg-white dark:bg-slate-800 rounded-lg p-3 border border-gray-100 dark:border-gray-700 text-sm">
                      <div className="flex justify-between text-xs text-gray-500 mb-2">
                        <span>{c.author_name}</span>
                        <span>{formatTime(c.created_at)}</span>
                      </div>
                      {editingComment === c.id ? (
                        <div className="space-y-2">
                          <textarea
                            value={editCommentText}
                            onChange={(e) => setEditCommentText(e.target.value)}
                            rows={3}
                            className="w-full rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-slate-900 p-2 text-sm"
                          />
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => saveCommentAdmin(c.id)}
                              className="flex items-center gap-1 text-xs bg-primary text-white px-2 py-1 rounded"
                            >
                              <Check size={14} /> 保存
                            </button>
                            <button type="button" onClick={() => setEditingComment(null)} className="text-xs text-gray-500">
                              取消
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <p className="text-slate-700 dark:text-gray-300 whitespace-pre-wrap">{c.content}</p>
                          <div className="flex gap-2 mt-2">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingComment(c.id);
                                setEditCommentText(c.content);
                              }}
                              className="text-xs text-amber-600 flex items-center gap-1"
                            >
                              <Pencil size={12} /> 编辑
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteCommentAdmin(c.id)}
                              className="text-xs text-red-600 flex items-center gap-1"
                            >
                              <Trash2 size={12} /> 删除
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
            {Object.keys(commentsByTarget).length === 0 && (
              <p className="text-gray-500 text-sm">暂无评论</p>
            )}
          </div>
        </div>
      )}

      {isDms && (
        <DmManagement currentUser={currentUser} />
      )}
    </div>
  );
};

const DmManagement: React.FC<{ currentUser: any }> = ({ currentUser }) => {
  const [dms, setDms] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDms();
  }, []);

  const fetchDms = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/discussion?channel=dm&admin_all=1&reader=${encodeURIComponent(currentUser.username)}`);
      if (res.ok) {
        const data = await res.json();
        setDms(data.messages || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const recallDm = async (id: string) => {
    if (!window.confirm('确定要撤回这条私聊消息吗？')) return;
    try {
      const res = await fetch('/api/discussion', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messageId: id, kind: 'dm', revokedBy: currentUser.username })
      });
      if (res.ok) {
        setDms(prev => prev.filter(m => m.id !== id));
      } else {
        alert('撤回失败');
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) return <div className="text-gray-500">加载中...</div>;

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6">私聊管理</h2>
      <div className="space-y-4">
        {dms.length === 0 ? (
          <p className="text-gray-500">暂无私聊记录</p>
        ) : (
          dms.map(m => {
            const parts = m.thread_id.split('::');
            const peer1 = parts[0];
            const peer2 = parts[1];
            return (
              <div key={m.id} className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-gray-200 dark:border-gray-700 flex justify-between items-start gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs px-2 py-0.5 bg-slate-100 dark:bg-slate-700 rounded-full text-slate-600 dark:text-gray-300">
                      {peer1} ↔ {peer2}
                    </span>
                    <span className="font-semibold text-sm text-slate-900 dark:text-white">{m.author}</span>
                    <span className="text-xs text-gray-500">{new Date(m.created_at).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-slate-700 dark:text-gray-300 whitespace-pre-wrap">{m.body}</p>
                  {m.media_url && (
                    <img src={m.media_url} alt="media" className="mt-2 max-h-32 rounded-lg" referrerPolicy="no-referrer" />
                  )}
                </div>
                <button
                  onClick={() => recallDm(m.id)}
                  className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-md transition-colors flex-shrink-0"
                  title="撤回消息"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
