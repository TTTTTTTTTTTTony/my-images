import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';
import { EditableText } from '../components/EditableText';
import { EditableImage } from '../components/EditableImage';
import { ReorderButtons } from '../components/ReorderButtons';
import { MarkdownEditor } from '../components/MarkdownEditor';
import { Comments } from '../components/Comments';
import { Plus, Trash2, X, Search, ChevronLeft } from 'lucide-react';

const ProjectsPage: React.FC = () => {
  const { data, updateField, addArrayItem, removeArrayItem, isEditMode } = usePortfolio();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(6);

  const selectedProjectIndex = id ? data.projects.findIndex(p => p.id === id) : null;

  const handleAddProject = () => {
    const newId = Math.floor(100000 + Math.random() * 900000).toString();
    addArrayItem(['projects'], {
      id: newId,
      title: '新项目标题',
      description: '新项目简短描述',
      content: '## 项目详情\n\n在这里编写详细的项目介绍...',
      tags: ['New Tag'],
      imageUrl: 'https://placehold.co/600x400/1e293b/FFF?text=New+Project',
    });
    navigate(`/projects/${newId}`);
  };

  const handleAddTag = (projectIndex: number) => {
    addArrayItem(['projects', projectIndex.toString(), 'tags'], 'New Tag');
  };

  const filteredProjectsRaw = data.projects.filter(project => {
    const query = searchQuery.toLowerCase();
    return (
      (project.title || '').toLowerCase().includes(query) ||
      (project.description || '').toLowerCase().includes(query) ||
      (project.tags || []).some(tag => (tag || '').toLowerCase().includes(query))
    );
  }).sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return 0;
  });

  const totalPages = Math.max(1, Math.ceil(filteredProjectsRaw.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const pagedProjects = filteredProjectsRaw.slice((safePage - 1) * pageSize, safePage * pageSize);

  return (
    <div className="min-h-screen pb-20">
      {/* Banner */}
      {(data.banners?.projects || isEditMode) && (
        <div className="w-full h-48 md:h-64 relative group">
          {isEditMode ? (
            <EditableImage 
              src={data.banners?.projects || 'https://placehold.co/1920x400/1e293b/FFF?text=Projects+Banner'} 
              alt="Projects Banner" 
              onSave={(val) => updateField(['banners', 'projects'], val)} 
              folderPath="banners"
              className="w-full h-full"
            />
          ) : (
            <img src={data.banners?.projects} alt="Projects Banner" className="w-full h-full object-cover" />
          )}
          <div className="absolute inset-0 bg-black/30 pointer-events-none"></div>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <h1 className="text-4xl md:text-5xl font-bold text-white drop-shadow-lg tracking-wider">我的作品</h1>
          </div>
          {isEditMode && data.banners?.projects && (
            <button 
              onClick={() => updateField(['banners', 'projects'], '')}
              className="absolute top-4 right-4 bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity z-10"
              title="移除横幅"
            >
              <Trash2 size={16} />
            </button>
          )}
        </div>
      )}

      <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 ${!(data.banners?.projects || isEditMode) ? 'pt-24' : 'mt-8'}`}>
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-6">
          {!data.banners?.projects && (
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">我的作品</h2>
              <div className="w-20 h-1 bg-primary rounded-full"></div>
            </div>
          )}
          
          <div className="flex items-center gap-4 w-full md:w-auto flex-1 md:justify-end">
            <div className="relative w-full md:w-64">
              <input 
                type="text" 
                placeholder="搜索作品..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white dark:bg-slate-800 text-slate-900 dark:text-white border border-gray-300 dark:border-gray-700 rounded-full pl-10 pr-4 py-2 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            </div>
            
            {isEditMode && (
              <button 
                onClick={handleAddProject}
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-full flex items-center gap-2 transition-colors flex-shrink-0"
              >
                <Plus size={18} /> 添加新项目
              </button>
            )}
          </div>
        </div>

        {/* Notice Board */}
        {(data.notices?.projects || isEditMode) && (
          <div className="mb-8 p-4 bg-primary/10 border border-primary/20 rounded-xl text-slate-800 dark:text-slate-200 relative group">
            <div className="flex items-start gap-2">
              <span className="text-primary font-bold mt-1">📢 公告：</span>
              <div className="flex-1">
                <EditableText
                  as="div"
                  value={data.notices?.projects || '点击此处编辑公告内容...'}
                  onSave={(val) => updateField(['notices', 'projects'], val)}
                  className="w-full"
                  multiline
                />
              </div>
            </div>
            {isEditMode && data.notices?.projects && (
              <button 
                onClick={() => updateField(['notices', 'projects'], '')}
                className="absolute top-2 right-2 text-red-500 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                title="清除公告"
              >
                <X size={16} />
              </button>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-end gap-3 mb-6 text-sm text-slate-600 dark:text-gray-400">
          <label className="flex items-center gap-2">
            每页
            <select
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
              className="bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-700 rounded px-2 py-1"
            >
              {[3, 6, 9, 12].map((n) => (
                <option key={n} value={n}>{n} 条</option>
              ))}
            </select>
          </label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={safePage <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="px-3 py-1 rounded border border-gray-300 dark:border-gray-600 disabled:opacity-40"
            >
              上一页
            </button>
            <span>
              {safePage} / {totalPages}
            </span>
            <button
              type="button"
              disabled={safePage >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              className="px-3 py-1 rounded border border-gray-300 dark:border-gray-600 disabled:opacity-40"
            >
              下一页
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {pagedProjects.map((project) => {
            const index = data.projects.findIndex(p => p.id === project.id);
            return (
              <div 
                key={project.id || index} 
                className="bg-white dark:bg-secondary rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group flex flex-col relative cursor-pointer border border-gray-100 dark:border-gray-800"
                onClick={() => navigate(`/projects/${project.id}`)}
              >
                {isEditMode && (
                  <div className="absolute bottom-2 right-2 flex items-center gap-2 z-20" onClick={e => e.stopPropagation()}>
                    <ReorderButtons path={['projects']} index={index} totalLength={data.projects.length} className="flex-row scale-90" />
                    <button 
                      onClick={() => {
                        updateField(['projects', index.toString()], {
                          ...data.projects[index],
                          pinned: !data.projects[index].pinned,
                        });
                      }}
                      className={`p-2 rounded-full shadow-lg ${data.projects[index].pinned ? 'bg-amber-500 text-white' : 'bg-slate-700 text-gray-300 hover:bg-slate-600'}`}
                      title={data.projects[index].pinned ? "取消置顶" : "设为置顶"}
                    >
                      <Pin size={16} className={data.projects[index].pinned ? "fill-current" : ""} />
                    </button>
                    <button 
                      onClick={() => removeArrayItem(['projects'], index)}
                      className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                )}
                
                <div className="h-48 overflow-hidden relative">
                  {project.pinned && (
                    <div className="absolute top-2 left-2 z-10 bg-amber-500 text-white text-xs px-2 py-1 rounded-md flex items-center gap-1 shadow-sm">
                      <Pin size={12} className="fill-current" /> 置顶
                    </div>
                  )}
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                  />
                </div>
                
                <div className="p-6 flex-grow flex flex-col">
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{project.title}</h3>
                  <p className="text-slate-600 dark:text-gray-400 mb-4 flex-grow line-clamp-2">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {(project.tags || []).map((tag, tagIndex) => (
                      <span key={tagIndex} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        {filteredProjectsRaw.length === 0 && (
          <div className="text-center py-20 text-gray-500">
            没有找到相关作品。
          </div>
        )}
      </div>

      {/* Project Detail Modal (Fullscreen) */}
      {selectedProjectIndex !== null && selectedProjectIndex !== -1 && (
        <div className="fixed inset-0 z-[100] bg-white dark:bg-dark overflow-y-auto flex flex-col animate-fade-in">
          {/* Header */}
          <div className="sticky top-0 z-50 bg-white/80 dark:bg-dark/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 px-4 py-4 flex justify-between items-center">
            <button 
              onClick={() => navigate('/projects')}
              className="flex items-center gap-2 text-slate-600 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              <ChevronLeft size={24} /> 返回作品列表
            </button>
            {isEditMode && <span className="text-sm font-bold text-primary px-3 py-1 bg-primary/10 rounded-full">编辑模式</span>}
          </div>
          
          <div className="max-w-4xl mx-auto w-full p-6 md:p-10 flex-grow flex flex-col gap-8">
            {/* Cover Image */}
            <div className="w-full h-64 md:h-96 rounded-2xl overflow-hidden shadow-xl relative">
              {isEditMode ? (
                <EditableImage
                  src={data.projects[selectedProjectIndex].imageUrl}
                  alt="Cover"
                  onSave={(val) => updateField(['projects', selectedProjectIndex.toString(), 'imageUrl'], val)}
                  className="w-full h-full"
                  folderPath={`projects/${data.projects[selectedProjectIndex].id}`}
                />
              ) : (
                <img src={data.projects[selectedProjectIndex].imageUrl} className="w-full h-full object-cover" alt="Cover" />
              )}
            </div>

            {/* Title & Description */}
            <div className="flex flex-col gap-4">
              {isEditMode ? (
                <EditableText
                  as="h1"
                  value={data.projects[selectedProjectIndex].title}
                  onSave={(val) => updateField(['projects', selectedProjectIndex.toString(), 'title'], val)}
                  className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white"
                />
              ) : (
                <h1 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white">{data.projects[selectedProjectIndex].title}</h1>
              )}

              {isEditMode ? (
                <EditableText
                  as="p"
                  value={data.projects[selectedProjectIndex].description}
                  onSave={(val) => updateField(['projects', selectedProjectIndex.toString(), 'description'], val)}
                  className="text-xl text-slate-600 dark:text-gray-400"
                  multiline
                />
              ) : (
                <p className="text-xl text-slate-600 dark:text-gray-400">{data.projects[selectedProjectIndex].description}</p>
              )}
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-2">
              {(data.projects[selectedProjectIndex].tags || []).map((tag, tagIndex) => (
                <div key={tagIndex} className="relative group/tag">
                  {isEditMode && (
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 flex items-center gap-1 opacity-0 group-hover/tag:opacity-100 transition-opacity z-20 bg-white dark:bg-slate-800 rounded p-1 shadow-lg border border-gray-200 dark:border-gray-700">
                      <ReorderButtons path={['projects', selectedProjectIndex.toString(), 'tags']} index={tagIndex} totalLength={(data.projects[selectedProjectIndex].tags || []).length} className="flex-row scale-75" />
                      <button 
                        onClick={() => removeArrayItem(['projects', selectedProjectIndex.toString(), 'tags'], tagIndex)}
                        className="text-red-500 hover:text-red-600"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  )}
                  {isEditMode ? (
                    <EditableText
                      as="span"
                      value={tag}
                      onSave={(val) => updateField(['projects', selectedProjectIndex.toString(), 'tags', tagIndex.toString()], val)}
                      className="px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium"
                    />
                  ) : (
                    <span className="px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium">{tag}</span>
                  )}
                </div>
              ))}
              {isEditMode && (
                <button 
                  onClick={() => handleAddTag(selectedProjectIndex)}
                  className="px-4 py-2 bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 text-slate-600 dark:text-gray-300 rounded-full text-sm font-medium flex items-center gap-1 transition-colors"
                >
                  <Plus size={16} /> 添加标签
                </button>
              )}
            </div>

            <div className="w-full h-px bg-gray-200 dark:bg-gray-800 my-4"></div>

            {/* Markdown Content */}
            <div className="pb-10">
              <MarkdownEditor
                value={data.projects[selectedProjectIndex].content || data.projects[selectedProjectIndex].description}
                onSave={(val) => updateField(['projects', selectedProjectIndex.toString(), 'content'], val)}
                folderPath={`projects/${data.projects[selectedProjectIndex].id}`}
              />
            </div>

            {/* Comments Section */}
            <div className="pb-20">
              <Comments targetId={data.projects[selectedProjectIndex].id} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectsPage;
