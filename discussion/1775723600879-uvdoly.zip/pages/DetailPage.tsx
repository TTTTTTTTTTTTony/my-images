import React, { useEffect, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { usePortfolio } from "../context/PortfolioContext";
import { ArrowLeft, Save, X, Pencil } from "lucide-react";
import { MarkdownEditor } from "../components/MarkdownEditor";

export default function DetailPage() {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const {
    data,
    updateField,
    isEditMode,
    setIsEditMode,
    saveData,
    beginEdit,
    cancelEdit,
    currentUser,
  } = usePortfolio();

  const [type, setType] = useState<
    "achievements" | "futureAchievements" | "experience" | null
  >(null);
  const [itemIndex, setItemIndex] = useState<number>(-1);

  useEffect(() => {
    if (location.pathname.startsWith("/achievements/")) {
      setType("achievements");
      const idx = data.achievements?.findIndex((a) => a.id === id);
      setItemIndex(idx !== undefined ? idx : -1);
    } else if (location.pathname.startsWith("/future-achievements/")) {
      setType("futureAchievements");
      const idx = data.futureAchievements?.findIndex((a) => a.id === id);
      setItemIndex(idx !== undefined ? idx : -1);
    } else if (location.pathname.startsWith("/experience/")) {
      setType("experience");
      const idx = data.experience?.findIndex((a) => a.id === id);
      setItemIndex(idx !== undefined ? idx : -1);
    }
  }, [location.pathname, id, data]);

  if (type === null || itemIndex === -1) {
    return (
      <div className="min-h-screen flex items-center justify-center text-slate-500">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">未找到内容</h2>
          <button
            onClick={() => navigate("/")}
            className="text-primary hover:underline"
          >
            返回首页
          </button>
        </div>
      </div>
    );
  }

  const item = data[type][itemIndex] as any;
  const title =
    type === "experience" ? item.role + " @ " + item.company : item.title;
  const isOwner = currentUser?.role === "owner";

  return (
    <div className="fixed inset-0 z-[100] bg-white dark:bg-dark overflow-y-auto flex flex-col animate-fade-in">
      <div className="sticky top-0 z-50 bg-white/80 dark:bg-dark/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 px-4 py-4 flex justify-between items-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-slate-600 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white transition-colors"
        >
          <ArrowLeft size={24} /> 返回首页
        </button>
        {isOwner && isEditMode && (
          <span className="text-sm font-bold text-primary px-3 py-1 bg-primary/10 rounded-full">
            编辑模式
          </span>
        )}
      </div>

      <div className="max-w-4xl mx-auto w-full p-6 md:p-10 flex-grow flex flex-col gap-8">
        <div className="flex justify-between items-start">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white">
            {title}
          </h1>
          {isOwner &&
            (isEditMode ? (
              <div className="flex gap-2">
                <button
                  onClick={async () => {
                    await saveData();
                    setIsEditMode(false);
                  }}
                  className="flex items-center gap-1 text-sm px-3 py-1.5 rounded-md transition-colors bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30"
                >
                  <Save size={14} /> 保存
                </button>
                <button
                  onClick={() => cancelEdit()}
                  className="flex items-center gap-1 text-sm px-3 py-1.5 rounded-md transition-colors bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 border border-slate-200 dark:border-gray-700"
                >
                  <X size={14} /> 取消
                </button>
              </div>
            ) : (
              <button
                onClick={() => beginEdit()}
                className="flex items-center gap-1 text-sm px-3 py-1.5 rounded-md transition-colors bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 border border-slate-200 dark:border-gray-700"
              >
                <Pencil size={14} /> 编辑
              </button>
            ))}
        </div>

        {/* Removed original card elements (imageUrl) as requested */}

        <div className="prose dark:prose-invert max-w-none pb-10">
          <MarkdownEditor
            value={item.content || ""}
            onSave={(val) =>
              updateField([type, itemIndex.toString(), "content"], val)
            }
            folderPath={`${type}/${item.id}`}
            alwaysEdit={isEditMode && isOwner}
            disabled={!isEditMode || !isOwner}
            placeholder="在这里输入详细内容（支持 Markdown）..."
          />
        </div>
      </div>
    </div>
  );
}
