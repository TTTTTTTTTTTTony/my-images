import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';
import {
  MessageSquare,
  Send,
  Shield,
  Users,
  ChevronLeft,
  Image as ImageIcon,
  User as UserIcon,
  Trash2,
  AtSign,
  X,
} from 'lucide-react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import { MediaUploadModal } from '../components/MediaUploadModal';
import { PublicProfileModal } from '../components/PublicProfileModal';
import { MarkdownEditor } from '../components/MarkdownEditor';

type ChatKind = 'community' | 'staff';

interface ChatMsg {
  id: string;
  channel?: string;
  author: string;
  body: string;
  media_url?: string | null;
  created_at: string;
}

interface DmMsg {
  id: string;
  thread_id: string;
  author: string;
  body: string;
  media_url?: string | null;
  created_at: string;
}

interface ThreadInfo {
  thread_id: string;
  peer: string;
  last_at: string;
}

interface PresenceItem {
  username: string;
  last_seen: string;
}

const DiscussPage: React.FC = () => {
  const { currentUser } = usePortfolio();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [tab, setTab] = useState<ChatKind | 'dm'>('community');
  const [dmPeer, setDmPeer] = useState<string | null>(null);
  const [threads, setThreads] = useState<ThreadInfo[]>([]);

  const [messages, setMessages] = useState<(ChatMsg | DmMsg)[]>([]);
  const [text, setText] = useState('');
  const [pendingMedia, setPendingMedia] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);
  const [mediaOpen, setMediaOpen] = useState(false);
  const [profileUser, setProfileUser] = useState<string | null>(null);

  const [mentionNames, setMentionNames] = useState<string[]>([]);
  const [mentionOpen, setMentionOpen] = useState(false);
  const [mentionFilter, setMentionFilter] = useState('');
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const [userListOpen, setUserListOpen] = useState(false);
  const [userSearch, setUserSearch] = useState('');
  const [presence, setPresence] = useState<PresenceItem[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);

  useEffect(() => {
    if (!currentUser) {
      navigate('/');
      return;
    }
    fetch('/api/users')
      .then((r) => r.json())
      .then((d) => {
        const users = Array.isArray(d.users) ? d.users : [];
        setAllUsers(users);
        const names = users.map((u: any) => u.username);
        if (currentUser.role !== 'user') {
          names.unshift('所有人');
        }
        setMentionNames(names);
      })
      .catch(() => {});
  }, [currentUser, navigate]);

  const dmFromUrl = searchParams.get('dm');
  const channelFromUrl = searchParams.get('channel') as ChatKind | null;

  useEffect(() => {
    if (dmFromUrl) {
      setTab('dm');
      setDmPeer(dmFromUrl);
    } else if (channelFromUrl === 'staff' || channelFromUrl === 'community') {
      setTab(channelFromUrl);
      setDmPeer(null);
    }
  }, [dmFromUrl, channelFromUrl]);

  const loadThreads = useCallback(async () => {
    if (!currentUser) return;
    const res = await fetch(`/api/discussion?channel=dm&list=1&reader=${encodeURIComponent(currentUser.username)}`);
    if (res.ok) {
      const d = await res.json();
      setThreads(Array.isArray(d.threads) ? d.threads : []);
    }
  }, [currentUser]);

  const load = useCallback(async (isBackground = false) => {
    if (!currentUser) return;
    if (!isBackground) setLoading(true);
    try {
      if (tab === 'dm' && dmPeer) {
        const res = await fetch(
          `/api/discussion?channel=dm&peer=${encodeURIComponent(dmPeer)}&reader=${encodeURIComponent(currentUser.username)}`
        );
        if (res.ok) {
          const d = await res.json();
          const newMessages = Array.isArray(d.messages) ? d.messages : [];
          setMessages(prev => JSON.stringify(prev) !== JSON.stringify(newMessages) ? newMessages : prev);
        }
      } else if (tab === 'community' || tab === 'staff') {
        const res = await fetch(`/api/discussion?channel=${tab}`);
        if (res.ok) {
          const d = await res.json();
          const newMessages = Array.isArray(d.messages) ? d.messages : [];
          setMessages(prev => JSON.stringify(prev) !== JSON.stringify(newMessages) ? newMessages : prev);
        }
      } else {
        setMessages([]);
      }
      await loadThreads();
    } finally {
      if (!isBackground) setLoading(false);
    }
  }, [currentUser, tab, dmPeer, loadThreads]);

  useEffect(() => {
    load();
  }, [load]);

  // realtime auto refresh
  useEffect(() => {
    if (!currentUser) return;
    const tick = async () => {
      try {
        const r = await fetch('/api/users');
        if (r.ok) {
          const d = await r.json();
          const users = Array.isArray(d.users) ? d.users : [];
          setAllUsers(users);
          setMentionNames(users.map((u: any) => u.username));
        }
      } catch {
        // ignore
      }
      load(true);
    };
    const t = setInterval(tick, 3500);
    return () => clearInterval(t);
  }, [currentUser, load]);

  const loadPresence = useCallback(async () => {
    try {
      const res = await fetch('/api/presence');
      if (!res.ok) return;
      const d = await res.json();
      setPresence(Array.isArray(d.items) ? d.items : []);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (!userListOpen) return;
    loadPresence();
    const t = setInterval(loadPresence, 5000);
    return () => clearInterval(t);
  }, [userListOpen, loadPresence]);

  const prevMessagesLengthRef = useRef(0);

  useEffect(() => {
    if (messages.length > prevMessagesLengthRef.current) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
    prevMessagesLengthRef.current = messages.length;
  }, [messages]);

  const allowedMentions = useMemo(() => {
    if (!currentUser) return [];
    // DM: only @对方
    if (tab === 'dm') {
      return dmPeer ? [dmPeer] : [];
    }
    // staff(管理员频道): 只允许 @owner（紧急请 @owner）
    if (tab === 'staff') {
      return ['owner'];
    }
    // community: everyone
    return mentionNames;
  }, [currentUser, tab, dmPeer, mentionNames]);

  const filteredMentions = useMemo(() => {
    const q = mentionFilter.toLowerCase();
    return allowedMentions.filter((n) => n.toLowerCase().includes(q)).slice(0, 12);
  }, [allowedMentions, mentionFilter]);

  const onTextChange = (v: string) => {
    setText(v);
    const lastAt = v.lastIndexOf('@');
    if (lastAt >= 0 && (lastAt === 0 || /[\s\n]/.test(v[lastAt - 1]))) {
      const after = v.slice(lastAt + 1);
      if (!after.includes(' ') && !after.includes('\n')) {
        setMentionFilter(after);
        setMentionOpen(true);
        return;
      }
    }
    setMentionOpen(false);
  };

  const insertMention = (name: string) => {
    const v = text;
    const lastAt = v.lastIndexOf('@');
    if (lastAt < 0) return;
    const next = v.slice(0, lastAt) + '@' + name + ' ';
    setText(next);
    setMentionOpen(false);
    inputRef.current?.focus();
  };

  const send = async (overrideText?: string) => {
    const t = (overrideText !== undefined ? overrideText : text).trim();
    if (!t && !pendingMedia) return;
    if (!currentUser) return;
    const bodyText = t || (pendingMedia ? ' ' : '');
    if (overrideText === undefined) {
      setText('');
    }
    const mediaUrl = pendingMedia;
    setPendingMedia(null);
    try {
      if (tab === 'dm' && dmPeer) {
        const res = await fetch('/api/discussion', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            channel: 'dm',
            author: currentUser.username,
            body: bodyText,
            media_url: mediaUrl || undefined,
            peer: dmPeer,
          }),
        });
        if (res.ok) {
          const d = await res.json();
          if (d.message) {
            setMessages(prev => [...prev, d.message]);
          } else {
            await load(true);
          }
        } else {
          const d = await res.json();
          if (d.error) alert(d.error);
        }
      } else {
        const res = await fetch('/api/discussion', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            channel: tab,
            author: currentUser.username,
            body: bodyText,
            media_url: mediaUrl || undefined,
          }),
        });
        if (res.ok) {
          const d = await res.json();
          if (d.message) {
            setMessages(prev => [...prev, d.message]);
          } else {
            await load(true);
          }
        } else {
          const d = await res.json();
          if (d.error) alert(d.error);
        }
      }
    } catch {
      await load(true);
    }
  };

  const revoke = async (msg: ChatMsg | DmMsg, kind: 'chat' | 'dm') => {
    if (!currentUser) return;
    if (!window.confirm('确定撤回这条消息？')) return;
    setMessages(prev => prev.filter(m => m.id !== msg.id));
    await fetch('/api/discussion', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messageId: msg.id,
        kind,
        revokedBy: currentUser.username,
      }),
    });
  };

  const switchTab = (next: ChatKind | 'dm') => {
    setTab(next);
    setDmPeer(null);
    const p = new URLSearchParams();
    if (next === 'staff') p.set('channel', 'staff');
    else if (next === 'community') p.set('channel', 'community');
    setSearchParams(p);
  };

  const openDm = (peer: string) => {
    setTab('dm');
    setDmPeer(peer);
    setSearchParams({ dm: peer });
  };

  const presenceMap = useMemo(() => {
    const m = new Map<string, string>();
    for (const p of presence) {
      m.set(p.username, p.last_seen);
    }
    return m;
  }, [presence]);

  const isOnline = (u: string) => {
    const last = presenceMap.get(u);
    if (!last) return false;
    const ms = Date.parse(last);
    return Number.isFinite(ms) && Date.now() - ms <= 2 * 60 * 1000;
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen pt-24 px-4 flex items-center justify-center bg-white dark:bg-dark">
        <div className="text-center">
          <p className="text-gray-500 dark:text-gray-400">正在返回首页...</p>
        </div>
      </div>
    );
  }

  const muteUser = async (username: string, minutes: number | 'forever' | 'clear') => {
    if (!currentUser || !['owner', 'senior_admin', 'group_admin'].includes(currentUser.role)) return;
    const targetUser = allUsers.find(u => u.username === username);
    if (!targetUser) return;
    
    // Role hierarchy: owner > senior_admin > group_admin > user
    const roleWeight = { owner: 4, senior_admin: 3, group_admin: 2, user: 1 };
    const myWeight = roleWeight[currentUser.role as keyof typeof roleWeight] || 1;
    const targetWeight = roleWeight[(targetUser.role || 'user') as keyof typeof roleWeight] || 1;
    
    if (myWeight <= targetWeight && currentUser.username !== 'owner') {
      alert('权限不足，无法操作该用户');
      return;
    }

    let muted_until: string | null = null;
    if (minutes === 'forever') muted_until = '2999-01-01T00:00:00.000Z';
    else if (minutes === 'clear') muted_until = null;
    else muted_until = new Date(Date.now() + minutes * 60 * 1000).toISOString();

    setAllUsers(prev => prev.map(u => u.username === username ? { ...u, muted_until } : u));

    fetch('/api/users', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, muted_until, adminUsername: currentUser.username }),
    }).catch(console.error);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-dark text-slate-900 dark:text-slate-200 pt-20 pb-8">
      <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row gap-6 min-h-[calc(100vh-5rem)]">
        <aside className="w-full md:w-56 flex-shrink-0 flex flex-row md:flex-col gap-2 border-b md:border-b-0 md:border-r border-gray-200 dark:border-gray-800 pb-4 md:pb-0 md:pr-4">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-slate-600 dark:text-gray-400 hover:text-primary mb-2 md:mb-4"
          >
            <ChevronLeft size={20} /> 返回
          </button>
          <button
            type="button"
            onClick={() => switchTab('community')}
            className={`flex items-center gap-2 px-4 py-3 rounded-xl text-left transition-colors ${
              tab === 'community'
                ? 'bg-primary/15 text-primary font-medium'
                : 'hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Users size={20} /> 群聊
          </button>
          {currentUser?.username !== 'owner' && (
            <button
              type="button"
              onClick={() => openDm('owner')}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl text-left transition-colors ${
                tab === 'dm' && dmPeer === 'owner'
                  ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 font-medium'
                  : 'hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Shield size={20} /> 群主
            </button>
          )}

          <div className="mt-2 flex flex-col gap-1 max-h-48 overflow-y-auto text-xs border-t border-gray-200 dark:border-gray-800 pt-2">
            <p className="text-gray-500 px-2">最近会话</p>
            {threads.filter(t => t.peer !== 'owner').map((t) => (
              <button
                key={t.thread_id}
                type="button"
                onClick={() => openDm(t.peer)}
                className={`flex items-center gap-2 text-left px-2 py-1.5 rounded-lg truncate relative ${
                  dmPeer === t.peer ? 'bg-primary/10 text-primary' : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <div className="w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center text-primary font-bold flex-shrink-0 relative">
                  {t.peer.charAt(0).toUpperCase()}
                  <span 
                    className={`absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full border border-white dark:border-slate-900 ${isOnline(t.peer) ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600'}`}
                    title={isOnline(t.peer) ? '在线' : '离线'}
                  />
                </div>
                <span className="truncate">{t.peer}</span>
              </button>
            ))}
          </div>
        </aside>

        <div className="flex-1 flex flex-col min-h-0 border border-gray-200 dark:border-gray-800 rounded-2xl overflow-hidden bg-slate-50 dark:bg-slate-900/50">
          <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <MessageSquare className="text-primary" size={20} />
              <span className="font-semibold flex items-center gap-2">
                {tab === 'community' && '群聊'}
                {tab === 'dm' && (dmPeer ? (
                  <>
                    {dmPeer === 'owner' ? '与群主的私聊' : `与 ${dmPeer} 的私聊`}
                    <span 
                      className={`w-2 h-2 rounded-full ${isOnline(dmPeer) ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600'}`}
                      title={isOnline(dmPeer) ? '在线' : '离线'}
                    />
                  </>
                ) : '私聊 — 选择或输入对方用户名')}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setUserListOpen(true)}
                className="text-xs border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-1.5 hover:bg-white dark:hover:bg-slate-800 flex items-center gap-1"
              >
                <UserIcon size={14} /> 用户
              </button>
              <button type="button" onClick={() => load()} className="text-xs text-primary hover:underline">
                刷新
              </button>
            </div>
          </div>

          {tab === 'dm' && !dmPeer && (
            <div className="p-4 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-slate-900/80">
              <label className="text-xs text-gray-500 block mb-1">开始与谁私聊？（输入用户名）</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="用户名"
                  className="flex-1 bg-white dark:bg-slate-900 border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 text-sm"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      const v = (e.target as HTMLInputElement).value.trim();
                      if (v) openDm(v);
                    }
                  }}
                  id="dm-peer-input"
                />
                <button
                  type="button"
                  className="bg-primary text-white px-4 py-2 rounded-lg text-sm"
                  onClick={() => {
                    const el = document.getElementById('dm-peer-input') as HTMLInputElement;
                    const v = el?.value?.trim();
                    if (v) openDm(v);
                  }}
                >
                  开始
                </button>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[200px]">
            {loading ? (
              <p className="text-center text-gray-500 text-sm">加载中…</p>
            ) : tab === 'dm' && !dmPeer ? (
              <p className="text-center text-gray-500 text-sm py-12">请输入对方用户名开始私聊，或从左侧最近会话选择。</p>
            ) : messages.length === 0 ? (
              <p className="text-center text-gray-500 text-sm py-12">暂无消息。</p>
            ) : (
              messages.map((m) => {
                const isDm = 'thread_id' in m;
                const authorUser = allUsers.find(u => u.username === m.author);
                const role = authorUser?.role || 'user';
                const canRevoke =
                  ['owner', 'senior_admin', 'group_admin'].includes(currentUser.role) || m.author === currentUser.username;
                return (
                  <div
                    key={m.id}
                    className="rounded-xl bg-white dark:bg-slate-800/80 p-3 border border-gray-100 dark:border-gray-700 relative group/msg"
                  >
                    <div className="flex items-start gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          if (['owner', 'senior_admin', 'group_admin'].includes(role) && m.author !== currentUser?.username) {
                            openDm(m.author);
                          } else {
                            setProfileUser(m.author);
                          }
                        }}
                        className="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center text-primary font-bold flex-shrink-0 hover:ring-2 ring-primary/40 transition-all"
                      >
                        {m.author.charAt(0).toUpperCase()}
                      </button>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-gray-500 mb-1 flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            className={`font-bold hover:text-primary ${['owner', 'senior_admin'].includes(role) ? 'text-amber-600 dark:text-amber-400' : 'text-slate-800 dark:text-gray-100'}`}
                            onClick={() => {
                              if (['owner', 'senior_admin', 'group_admin'].includes(role) && m.author !== currentUser?.username) {
                                openDm(m.author);
                              } else {
                                setProfileUser(m.author);
                              }
                            }}
                          >
                            {m.author}
                          </button>
                          {role !== 'user' && (
                            <span className="bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 px-1.5 py-0.5 rounded text-[10px] font-bold">
                              {role.toUpperCase()}
                            </span>
                          )}
                          <span>{new Date(m.created_at).toLocaleString()}</span>
                        </div>
                        <div className="text-sm text-slate-800 dark:text-gray-200 prose dark:prose-invert max-w-none prose-sm prose-p:my-1 prose-img:rounded-lg prose-img:max-h-56">
                          <Markdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeRaw]}>
                            {m.body}
                          </Markdown>
                        </div>
                        {m.media_url && (
                          <img
                            src={m.media_url}
                            alt=""
                            className="mt-2 max-h-56 rounded-lg border border-gray-200 dark:border-gray-700"
                          />
                        )}
                      </div>
                    </div>
                    {canRevoke && (
                      <button
                        type="button"
                        title="撤回"
                        onClick={() => revoke(m, isDm ? 'dm' : 'chat')}
                        className="absolute top-2 right-2 p-1.5 rounded-lg opacity-0 group-hover/msg:opacity-100 text-red-500 hover:bg-red-500/10"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                );
              })
            )}
            <div ref={bottomRef} />
          </div>

          {((tab !== 'dm') || dmPeer) && (() => {
            const currentUserObj = allUsers.find(u => u.username === currentUser.username);
            const isMuted = currentUserObj?.muted_until && Date.parse(currentUserObj.muted_until) > Date.now();
            return (
            <div className="p-3 border-t border-gray-200 dark:border-gray-800 space-y-2">
              {pendingMedia && (
                <p className="text-xs text-gray-500 truncate">已选媒体：{pendingMedia}</p>
              )}
              <div className="relative flex flex-col gap-2">
                <MarkdownEditor
                  value={text}
                  onSave={(val) => {
                    setText(val);
                  }}
                  onSubmit={(val) => {
                    setText('');
                    send(val);
                  }}
                  className="w-full"
                  folderPath="discussion"
                  disabled={isMuted}
                  placeholder={isMuted ? "您已被禁言，暂时无法发送消息" : "输入消息… 支持 Markdown 格式，@ 可提醒用户，Shift+Enter 换行"}
                  alwaysEdit={true}
                />
                {mentionOpen && filteredMentions.length > 0 && (
                  <div className="absolute bottom-full left-0 mb-1 bg-white dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg max-h-40 overflow-y-auto z-10 min-w-[160px]">
                    {filteredMentions.map((n) => (
                      <button
                        key={n}
                        type="button"
                        className="block w-full text-left px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-700"
                        onClick={() => insertMention(n)}
                      >
                        @{n}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex flex-wrap gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setMediaOpen(true)}
                  disabled={isMuted}
                  className="flex items-center gap-1 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <ImageIcon size={16} /> 媒体
                </button>
                <button
                  type="button"
                  onClick={send}
                  disabled={isMuted}
                  className="bg-primary text-white px-5 py-2 rounded-lg flex items-center gap-1 hover:bg-blue-600 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send size={18} /> 发送
                </button>
              </div>
            </div>
          )})()}
        </div>
      </div>

      <MediaUploadModal
        isOpen={mediaOpen}
        onClose={() => setMediaOpen(false)}
        onInsert={(url, isVideo, isAudio) => {
          setPendingMedia(url);
          if (!text.trim()) {
            setText(isVideo ? '分享视频' : isAudio ? '分享音频' : '分享图片');
          }
        }}
        title="上传到讨论区"
        folderPath="discussion"
        allowAllMedia
      />

      <PublicProfileModal username={profileUser} onClose={() => setProfileUser(null)} />

      {userListOpen && (
        <div className="fixed inset-0 z-[260] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-2xl border border-gray-200 dark:border-gray-800 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users size={18} className="text-primary" />
                <span className="font-bold">所有用户</span>
              </div>
              <button
                type="button"
                onClick={() => setUserListOpen(false)}
                className="text-gray-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-4 max-h-[70vh] flex flex-col min-h-0">
              <div className="mb-3 flex-shrink-0">
                <input
                  type="text"
                  placeholder="搜索用户..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-300 dark:border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary"
                />
              </div>
              <div className="space-y-2 overflow-y-auto flex-1 pr-1 max-h-[320px]">
                {allUsers.filter(u => u.username.toLowerCase().includes(userSearch.toLowerCase())).map((u) => {
                  const isMuted = u.muted_until && Date.parse(u.muted_until) > Date.now();
                  return (
                  <div
                    key={u.username}
                    className="flex items-center justify-between gap-2 p-3 rounded-xl border border-gray-100 dark:border-gray-800 bg-slate-50 dark:bg-slate-900/40"
                  >
                    <button
                      type="button"
                      className="flex items-center gap-3 min-w-0"
                      onClick={() => {
                        setUserListOpen(false);
                        setProfileUser(u.username);
                      }}
                    >
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          isOnline(u.username) ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600'
                        }`}
                        title={isOnline(u.username) ? '在线' : '离线'}
                      />
                      <span className="font-semibold truncate">{u.username}</span>
                      <span className="text-xs text-gray-500">{isOnline(u.username) ? '在线' : '离线'}</span>
                      {isMuted && (
                        <span className="text-[10px] bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400 px-1.5 py-0.5 rounded font-bold">
                          已禁言
                        </span>
                      )}
                    </button>
                    {['owner', 'senior_admin', 'group_admin'].includes(currentUser.role) && u.username !== 'owner' && (
                      <div className="flex items-center gap-2 flex-wrap justify-end">
                        <button
                          type="button"
                          className="text-xs px-2 py-1 rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-white dark:hover:bg-slate-800"
                          onClick={() => muteUser(u.username, 10)}
                        >
                          禁言10m
                        </button>
                        <button
                          type="button"
                          className="text-xs px-2 py-1 rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-white dark:hover:bg-slate-800"
                          onClick={() => muteUser(u.username, 60)}
                        >
                          禁言1h
                        </button>
                        <button
                          type="button"
                          className="text-xs px-2 py-1 rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-white dark:hover:bg-slate-800"
                          onClick={() => muteUser(u.username, 'forever')}
                        >
                          永久
                        </button>
                        <button
                          type="button"
                          className="text-xs px-2 py-1 rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-white dark:hover:bg-slate-800"
                          onClick={() => muteUser(u.username, 'clear')}
                        >
                          解除
                        </button>
                      </div>
                    )}
                  </div>
                )})}
              </div>
              <p className="text-[11px] text-gray-500 mt-3">
                在线判定：最近 2 分钟内有活动视为在线（讨论区会自动心跳刷新）。
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiscussPage;
