import React from 'react';
import Hero from '../components/Hero';
import About from '../components/About';
import Skills from '../components/Skills';
import { FollowMe } from '../components/FollowMe';
import Contact from '../components/Contact';

const Home: React.FC = () => {
  return (
    <main>
      <Hero />
      <About />
      <Skills />
      <FollowMe />
      <Contact />
    </main>
  );
};

export default Home;
