import React, { createContext, useContext, useState, useEffect } from 'react';
import { ProfileData, ContactMethod, BlogPost } from '../types';
import { PROFILE_DATA as initialData } from '../constants';

interface User {
  username: string;
  role: string;
  avatar?: string;
  email?: string;
  bio?: string;
  email_public?: number;
  muted_until?: string | null;
}

function normalizeContact(raw: any): ContactMethod {
  if (!raw || typeof raw !== 'object') {
    return {
      id: Date.now().toString(),
      type: 'entry',
      title: '联系',
      icon: 'link',
    };
  }
  const id = String(raw.id || Date.now());
  if (raw.type === 'qr') {
    return {
      id,
      type: 'qr',
      title: raw.title || raw.name || '扫码联系',
      imageUrl: raw.imageUrl,
      icon: raw.icon || 'scan',
    };
  }
  if (raw.type === 'link') {
    return {
      id,
      type: 'entry',
      title: raw.title || raw.name || '链接',
      href: raw.href || raw.value,
      subtitle: raw.subtitle,
      icon: raw.icon || 'link',
    };
  }
  if (raw.type === 'text') {
    return {
      id,
      type: 'entry',
      title: raw.title || raw.name || '联系',
      subtitle: raw.value || raw.subtitle,
      href: raw.href,
      icon: raw.icon || 'message',
    };
  }
  if (raw.type === 'entry') {
    return { ...raw, id, title: raw.title || raw.name || '联系' };
  }
  return {
    id,
    type: 'entry',
    title: raw.title || raw.name || '联系',
    subtitle: raw.subtitle || raw.value,
    href: raw.href,
    icon: raw.icon || 'link',
  };
}

function normalizeBlogPost(p: any): BlogPost {
  const pinned = p.pinned ?? p.isFavorite;
  return {
    ...p,
    pinned,
    isFavorite: !!pinned,
  };
}

interface PortfolioContextType {
  data: ProfileData;
  setData: React.Dispatch<React.SetStateAction<ProfileData>>;
  isEditMode: boolean;
  setIsEditMode: (mode: boolean) => void;
  beginEdit: () => void;
  cancelEdit: () => void;
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  saveData: () => Promise<void>;
  updateField: (path: string[], value: any) => void;
  addArrayItem: (path: string[], newItem: any) => void;
  removeArrayItem: (path: string[], index: number) => void;
  moveArrayItem: (path: string[], fromIndex: number, toIndex: number) => void;
  portfolioLoaded: boolean;
}

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

export const PortfolioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<ProfileData>(initialData);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [portfolioLoaded, setPortfolioLoaded] = useState(false);
  const [editSnapshot, setEditSnapshot] = useState<ProfileData | null>(null);

  useEffect(() => {
    if (!sessionStorage.getItem('portfolio_view_tracked')) {
      sessionStorage.setItem('portfolio_view_tracked', '1');
      fetch('/api/track', { method: 'POST' }).catch(() => {});
    }
  }, []);

  useEffect(() => {
    const storedUser = localStorage.getItem('portfolio_user');
    if (storedUser) {
      try {
        setCurrentUser(JSON.parse(storedUser));
      } catch (e) {
        console.error('Failed to parse user session');
      }
    }

    const fetchData = async () => {
      try {
        const res = await fetch('/api/portfolio');
        if (res.ok) {
          const json = await res.json();

          const rawContacts = Array.isArray(json.contacts) ? json.contacts : initialData.contacts;
          const contacts: ContactMethod[] = rawContacts.map(normalizeContact);

          const blogPosts: BlogPost[] = (Array.isArray(json.blogPosts) ? json.blogPosts : initialData.blogPosts).map(
            normalizeBlogPost
          );

          setData({
            ...initialData,
            ...json,
            socials: Array.isArray(json.socials) ? json.socials : initialData.socials,
            contacts,
            logoUrl: json.logoUrl || initialData.logoUrl,
            projects: Array.isArray(json.projects) ? json.projects : initialData.projects,
            skills: Array.isArray(json.skills) ? json.skills : initialData.skills,
            experience: Array.isArray(json.experience) ? json.experience : initialData.experience,
            achievements: Array.isArray(json.achievements) ? json.achievements : initialData.achievements,
            futureAchievements: Array.isArray(json.futureAchievements)
              ? json.futureAchievements
              : initialData.futureAchievements,
            blogPosts,
            blogCategories: Array.isArray(json.blogCategories) ? json.blogCategories : initialData.blogCategories,
            heroBackground: json.heroBackground || json.backgrounds?.home || initialData.heroBackground,
            theme: json.theme || initialData.theme,
          });
        }
      } catch (e) {
        console.log('Using local constants data as fallback');
      } finally {
        setPortfolioLoaded(true);
      }
    };
    fetchData();
  }, []);

  const saveData = async () => {
    try {
      const res = await fetch('/api/portfolio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        alert('保存成功！数据已同步到云端。');
      } else {
        const errorText = await res.text();
        alert(`保存失败 (${res.status}): ${errorText}\n\n请检查 Cloudflare Pages 的 D1 绑定或数据表是否创建。`);
      }
    } catch (e) {
      alert('保存失败（网络错误）：' + e);
    }
  };

  const beginEdit = () => {
    setEditSnapshot(JSON.parse(JSON.stringify(data)));
    setIsEditMode(true);
  };

  const cancelEdit = () => {
    if (editSnapshot) {
      setData(editSnapshot);
    }
    setEditSnapshot(null);
    setIsEditMode(false);
  };

  const updateField = (path: string[], value: any) => {
    setData((prev) => {
      const newData = JSON.parse(JSON.stringify(prev));
      let current: any = newData;
      for (let i = 0; i < path.length - 1; i++) {
        current = current[path[i]];
      }
      current[path[path.length - 1]] = value;
      return newData;
    });
  };

  const addArrayItem = (path: string[], newItem: any) => {
    setData((prev) => {
      const newData = JSON.parse(JSON.stringify(prev));
      let current: any = newData;
      for (let i = 0; i < path.length; i++) {
        current = current[path[i]];
      }
      if (Array.isArray(current)) {
        current.push(newItem);
      }
      return newData;
    });
  };

  const removeArrayItem = (path: string[], index: number) => {
    setData((prev) => {
      const newData = JSON.parse(JSON.stringify(prev));
      let current: any = newData;
      for (let i = 0; i < path.length; i++) {
        current = current[path[i]];
      }
      if (Array.isArray(current)) {
        current.splice(index, 1);
      }
      return newData;
    });
  };

  const moveArrayItem = (path: string[], fromIndex: number, toIndex: number) => {
    setData((prev) => {
      const newData = JSON.parse(JSON.stringify(prev));
      let current: any = newData;
      for (let i = 0; i < path.length; i++) {
        current = current[path[i]];
      }
      if (Array.isArray(current)) {
        if (toIndex >= 0 && toIndex < current.length) {
          const [movedItem] = current.splice(fromIndex, 1);
          current.splice(toIndex, 0, movedItem);
        }
      }
      return newData;
    });
  };

  const handleSetCurrentUser = (user: User | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem('portfolio_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('portfolio_user');
      setIsEditMode(false);
      setEditSnapshot(null);
    }
  };

  useEffect(() => {
    if (!currentUser) return;
    const tick = async () => {
      try {
        await fetch('/api/presence', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: currentUser.username }),
        });
      } catch {
        // ignore
      }
    };
    tick();
    const t = setInterval(tick, 3500);
    return () => clearInterval(t);
  }, [currentUser]);

  return (
    <PortfolioContext.Provider
      value={{
        data,
        setData,
        isEditMode,
        setIsEditMode,
        beginEdit,
        cancelEdit,
        currentUser,
        setCurrentUser: handleSetCurrentUser,
        saveData,
        updateField,
        addArrayItem,
        removeArrayItem,
        moveArrayItem,
        portfolioLoaded,
      }}
    >
      {children}
    </PortfolioContext.Provider>
  );
};

export const usePortfolio = () => {
  const context = useContext(PortfolioContext);
  if (!context) throw new Error('usePortfolio must be used within PortfolioProvider');
  return context;
};
