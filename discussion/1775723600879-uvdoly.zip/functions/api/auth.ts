export async function onRequestPost(context: any) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: "D1 Database not bound" }), { status: 500 });
    }

    // Initialize users table if it doesn't exist
    await env.DB.prepare(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        email TEXT,
        role TEXT DEFAULT 'user',
        avatar TEXT
      )
    `).run();

    // Add avatar column if it doesn't exist (for existing databases)
    try {
      await env.DB.prepare("ALTER TABLE users ADD COLUMN avatar TEXT").run();
    } catch (e) {
      // Ignore error if column already exists
    }
    for (const col of [
      "ALTER TABLE users ADD COLUMN bio TEXT",
      "ALTER TABLE users ADD COLUMN email_public INTEGER DEFAULT 0",
      "ALTER TABLE users ADD COLUMN muted_until TEXT",
    ]) {
      try {
        await env.DB.prepare(col).run();
      } catch {
        // exists
      }
    }

    // Check if owner exists, if not create it
    const ownerExists = await env.DB.prepare("SELECT * FROM users WHERE role = 'owner'").first();
    if (!ownerExists) {
      const adminExists = await env.DB.prepare("SELECT * FROM users WHERE username = 'admin'").first();
      if (adminExists) {
        await env.DB.prepare("UPDATE users SET username = 'owner', role = 'owner' WHERE username = 'admin'").run();
      } else {
        const adminPass =
          (env as any).OWNER_PASSWORD || "CzCzh12345@";
        await env.DB.prepare(
          "INSERT INTO users (username, password, role) VALUES ('owner', ?, 'owner')"
        )
          .bind(adminPass)
          .run();
      }
    } else {
      // Update owner password if OWNER_PASSWORD is set
      const adminPass = (env as any).OWNER_PASSWORD;
      if (adminPass) {
        await env.DB.prepare("UPDATE users SET password = ? WHERE role = 'owner'").bind(adminPass).run();
      }
    }

    const body = await request.json();
    const { action, username, password, email, newUsername, newPassword, avatar, oldUsername, bio, email_public } = body;

    if (action === 'login') {
      let user;
      if (username === 'owner') {
        user = await env.DB.prepare("SELECT * FROM users WHERE role = 'owner' AND password = ?").bind(password).first();
      } else {
        user = await env.DB.prepare("SELECT * FROM users WHERE username = ? AND password = ?").bind(username, password).first();
      }
      if (user) {
        return new Response(JSON.stringify({ success: true, user: { username: user.username, role: user.role, avatar: user.avatar, email: user.email, bio: user.bio, email_public: user.email_public } }), {
          headers: { "Content-Type": "application/json" }
        });
      } else {
        return new Response(JSON.stringify({ error: "用户名或密码错误" }), { status: 401 });
      }
    } else if (action === 'register') {
      if (!email) {
        return new Response(JSON.stringify({ error: "必须提供邮箱地址" }), { status: 400 });
      }
      if (username === 'owner') {
        return new Response(JSON.stringify({ error: "不能注册 owner 用户名" }), { status: 400 });
      }
      try {
        await env.DB.prepare(
          "INSERT INTO users (username, password, email) VALUES (?, ?, ?)"
        ).bind(username, password, email).run();

        try {
          await env.DB.prepare(`
            CREATE TABLE IF NOT EXISTS admin_notifications (
              id TEXT PRIMARY KEY,
              type TEXT NOT NULL,
              message TEXT NOT NULL,
              detail TEXT,
              created_at TEXT NOT NULL,
              read INTEGER NOT NULL DEFAULT 0
            )
          `).run();
          const nid = crypto.randomUUID();
          const ts = new Date().toISOString();
          await env.DB.prepare(
            `INSERT INTO admin_notifications (id, type, message, detail, created_at, read) VALUES (?, 'register', ?, ?, ?, 0)`
          ).bind(nid, `新用户注册：${username}`, username || '', ts).run();
        } catch {
          // ignore notification errors
        }

        return new Response(JSON.stringify({ success: true }), {
          headers: { "Content-Type": "application/json" }
        });
      } catch (e: any) {
        if (e.message.includes('UNIQUE constraint failed')) {
          return new Response(JSON.stringify({ error: "用户名已存在" }), { status: 400 });
        }
        throw e;
      }
    } else if (action === 'update') {
      try {
        const targetUsername = oldUsername || username;
        let updateQuery = "UPDATE users SET ";
        const updateParams = [];
        
        if (newUsername) {
          updateQuery += "username = ?, ";
          updateParams.push(newUsername);
        }
        if (newPassword) {
          updateQuery += "password = ?, ";
          updateParams.push(newPassword);
        }
        if (avatar !== undefined) {
          updateQuery += "avatar = ?, ";
          updateParams.push(avatar);
        }
        if (email !== undefined) {
          updateQuery += "email = ?, ";
          updateParams.push(email);
        }
        if (bio !== undefined) {
          updateQuery += "bio = ?, ";
          updateParams.push(bio);
        }
        if (email_public !== undefined) {
          updateQuery += "email_public = ?, ";
          updateParams.push(email_public ? 1 : 0);
        }
        
        if (updateParams.length === 0) {
          const updatedUser = await env.DB.prepare("SELECT * FROM users WHERE username = ?").bind(targetUsername).first();
          if (!updatedUser) {
            return new Response(JSON.stringify({ error: "用户不存在" }), { status: 404 });
          }
          return new Response(JSON.stringify({ success: true, user: { username: updatedUser.username, role: updatedUser.role, avatar: updatedUser.avatar, email: updatedUser.email, bio: updatedUser.bio, email_public: updatedUser.email_public } }), {
            headers: { "Content-Type": "application/json" }
          });
        }

        const currentUser = await env.DB.prepare("SELECT * FROM users WHERE username = ?").bind(targetUsername).first();
        if (!currentUser) {
          return new Response(JSON.stringify({ error: "用户不存在" }), { status: 404 });
        }
        if (currentUser.role === 'owner' && newPassword) {
          return new Response(JSON.stringify({ error: "主管理员密码只能通过环境变量修改" }), { status: 403 });
        }

        updateQuery = updateQuery.slice(0, -2);
        updateQuery += " WHERE username = ?";
        updateParams.push(targetUsername);

        await env.DB.prepare(updateQuery).bind(...updateParams).run();
        
        const updatedUser = await env.DB.prepare("SELECT * FROM users WHERE username = ?").bind(newUsername || targetUsername).first();
        
        return new Response(JSON.stringify({ success: true, user: { username: updatedUser.username, role: updatedUser.role, avatar: updatedUser.avatar, email: updatedUser.email, bio: updatedUser.bio, email_public: updatedUser.email_public } }), {
          headers: { "Content-Type": "application/json" }
        });
      } catch (e: any) {
        if (e.message.includes('UNIQUE constraint failed')) {
          return new Response(JSON.stringify({ error: "用户名已存在" }), { status: 400 });
        }
        throw e;
      }
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), { status: 400 });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
