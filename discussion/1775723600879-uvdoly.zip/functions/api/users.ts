async function ensureUserCols(env: { DB: any }) {
  const alters = [
    'ALTER TABLE users ADD COLUMN bio TEXT',
    'ALTER TABLE users ADD COLUMN email_public INTEGER DEFAULT 0',
    'ALTER TABLE users ADD COLUMN muted_until TEXT',
  ];
  for (const q of alters) {
    try {
      await env.DB.prepare(q).run();
    } catch {
      // exists
    }
  }
}

export async function onRequestGet(context: { env: any }) {
  try {
    const { env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureUserCols(env);
    const { results } = await env.DB.prepare(
      `SELECT id, username, email, role, avatar, bio, email_public, muted_until FROM users ORDER BY id ASC`
    ).all();
    return new Response(JSON.stringify({ users: results || [] }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPost(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureUserCols(env);
    const body = await request.json();
    const { username, password, email, role } = body;
    if (!username || !password) {
      return new Response(JSON.stringify({ error: 'Missing username or password' }), { status: 400 });
    }
    await env.DB.prepare(
      `INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)`
    )
      .bind(username, password, email || '', role || 'user')
      .run();
    return new Response(JSON.stringify({ success: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    if (String(err.message).includes('UNIQUE')) {
      return new Response(JSON.stringify({ error: '用户名已存在' }), { status: 400 });
    }
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPatch(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureUserCols(env);
    const body = await request.json();
    const { username, role, email, muted_until, bio, email_public, adminUsername } = body;
    if (!username) {
      return new Response(JSON.stringify({ error: 'Missing username' }), { status: 400 });
    }

    if (role !== undefined || muted_until !== undefined) {
      if (!adminUsername) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
      }
      const admin = await env.DB.prepare('SELECT role FROM users WHERE username = ?').bind(adminUsername).first();
      if (!admin || !['owner', 'senior_admin', 'group_admin'].includes(admin.role)) {
        return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403 });
      }
      if (role !== undefined) {
        if (!['owner', 'senior_admin'].includes(admin.role)) {
           return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403 });
        }
        if (admin.role === 'senior_admin' && role === 'owner') {
          return new Response(JSON.stringify({ error: 'Cannot set owner role' }), { status: 403 });
        }
      }
    }

    const mainAdmin = 'owner';
    if (username === mainAdmin && role && role !== 'owner') {
      return new Response(JSON.stringify({ error: '不可取消主管理员权限' }), { status: 400 });
    }

    const parts: string[] = [];
    const vals: any[] = [];
    if (role !== undefined) {
      parts.push('role = ?');
      vals.push(role);
    }
    if (email !== undefined) {
      parts.push('email = ?');
      vals.push(email);
    }
    if (muted_until !== undefined) {
      parts.push('muted_until = ?');
      vals.push(muted_until);
    }
    if (bio !== undefined) {
      parts.push('bio = ?');
      vals.push(bio);
    }
    if (email_public !== undefined) {
      parts.push('email_public = ?');
      vals.push(email_public ? 1 : 0);
    }
    if (!parts.length) {
      return new Response(JSON.stringify({ error: 'Nothing to update' }), { status: 400 });
    }
    vals.push(username);
    await env.DB.prepare(`UPDATE users SET ${parts.join(', ')} WHERE username = ?`).bind(...vals).run();
    const updated = await env.DB.prepare(
      `SELECT id, username, email, role, avatar, bio, email_public, muted_until FROM users WHERE username = ?`
    )
      .bind(username)
      .first();
    return new Response(JSON.stringify({ success: true, user: updated || null }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestDelete(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    const url = new URL(request.url);
    const username = url.searchParams.get('username');
    if (!username) {
      return new Response(JSON.stringify({ error: 'Missing username' }), { status: 400 });
    }
    if (username === 'owner') {
      return new Response(JSON.stringify({ error: '不能删除主管理员账号' }), { status: 400 });
    }
    await env.DB.prepare('DELETE FROM users WHERE username = ?').bind(username).run();
    return new Response(JSON.stringify({ success: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
