async function ensurePresence(env: { DB: any }) {
  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS user_presence (
      username TEXT PRIMARY KEY,
      last_seen TEXT NOT NULL
    )
  `).run();
}

export async function onRequestGet(context: { env: any }) {
  try {
    const { env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensurePresence(env);
    const { results } = await env.DB.prepare(`SELECT username, last_seen FROM user_presence ORDER BY username ASC`).all();
    return new Response(JSON.stringify({ items: results || [] }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPost(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensurePresence(env);
    const body = await request.json();
    const username = String(body?.username || '').trim();
    if (!username) {
      return new Response(JSON.stringify({ error: 'Missing username' }), { status: 400 });
    }
    const ts = new Date().toISOString();
    await env.DB.prepare(
      `INSERT INTO user_presence (username, last_seen) VALUES (?, ?)
       ON CONFLICT(username) DO UPDATE SET last_seen = excluded.last_seen`
    )
      .bind(username, ts)
      .run();
    return new Response(JSON.stringify({ success: true, last_seen: ts }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

