async function ensureNotifications(env: { DB: any }) {
  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS user_notifications (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL,
      type TEXT NOT NULL,
      from_user TEXT,
      body TEXT,
      link TEXT,
      read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    )
  `).run();
}

export async function onRequestGet(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureNotifications(env);
    const url = new URL(request.url);
    const forUser = url.searchParams.get('for');
    if (!forUser) {
      return new Response(JSON.stringify({ error: 'Missing for' }), { status: 400 });
    }

    const { results } = await env.DB.prepare(
      `SELECT * FROM user_notifications WHERE username = ? ORDER BY created_at DESC LIMIT 100`
    )
      .bind(forUser)
      .all();

    return new Response(JSON.stringify({ notifications: results || [] }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPost(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureNotifications(env);
    const body = await request.json();
    const { markReadIds, forUser } = body;
    if (!forUser || !Array.isArray(markReadIds)) {
      return new Response(JSON.stringify({ error: 'Invalid body' }), { status: 400 });
    }
    const stmt = env.DB.prepare('UPDATE user_notifications SET read = 1 WHERE id = ? AND username = ?');
    for (const id of markReadIds) {
      await stmt.bind(id, forUser).run();
    }
    return new Response(JSON.stringify({ success: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestDelete(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureNotifications(env);
    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    const forUser = url.searchParams.get('for');
    if (!id || !forUser) {
      return new Response(JSON.stringify({ error: 'Missing id or for' }), { status: 400 });
    }
    await env.DB.prepare('DELETE FROM user_notifications WHERE id = ? AND username = ?').bind(id, forUser).run();
    return new Response(JSON.stringify({ success: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
