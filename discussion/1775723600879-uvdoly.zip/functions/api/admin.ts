async function ensureTables(env: { DB: any }) {
  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS site_stats (
      key TEXT PRIMARY KEY,
      value INTEGER NOT NULL DEFAULT 0
    )
  `).run();

  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS admin_notifications (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      detail TEXT,
      created_at TEXT NOT NULL,
      read INTEGER NOT NULL DEFAULT 0
    )
  `).run();

  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS comments (
      id TEXT PRIMARY KEY,
      target_id TEXT NOT NULL,
      author_name TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL
    )
  `).run();

  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      email TEXT,
      role TEXT DEFAULT 'user',
      avatar TEXT
    )
  `).run();
}

export async function onRequestGet(context: { env: any }) {
  try {
    const { env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 Database not bound' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    await ensureTables(env);

    const userRow = (await env.DB.prepare('SELECT COUNT(*) as c FROM users').first()) as { c: number } | null;
    const commentRow = (await env.DB.prepare('SELECT COUNT(*) as c FROM comments').first()) as { c: number } | null;
    const viewRow = (await env.DB.prepare("SELECT value FROM site_stats WHERE key = 'total_views'").first()) as { value: number } | null;

    const { results: notifications } = await env.DB.prepare(
      'SELECT id, type, message, detail, created_at, read FROM admin_notifications ORDER BY created_at DESC LIMIT 50'
    ).all();

    return new Response(
      JSON.stringify({
        users: userRow?.c ?? 0,
        comments: commentRow?.c ?? 0,
        views: viewRow?.value ?? 0,
        notifications: notifications || [],
      }),
      { headers: { 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

export async function onRequestPost(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 Database not bound' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    await ensureTables(env);

    const body = await request.json().catch(() => ({}));
    const ids: string[] | undefined = body?.markReadIds;

    if (Array.isArray(ids) && ids.length > 0) {
      const stmt = env.DB.prepare('UPDATE admin_notifications SET read = 1 WHERE id = ?');
      for (const id of ids) {
        await stmt.bind(id).run();
      }
      return new Response(JSON.stringify({ success: true }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Invalid body' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
