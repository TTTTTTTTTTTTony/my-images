async function ensureStats(env: { DB: any }) {
  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS site_stats (
      key TEXT PRIMARY KEY,
      value INTEGER NOT NULL DEFAULT 0
    )
  `).run();
}

export async function onRequestPost(context: { env: any }) {
  try {
    const { env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ ok: false }), { status: 500 });
    }

    await ensureStats(env);

    await env.DB.prepare(
      `INSERT INTO site_stats (key, value) VALUES ('total_views', 1)
       ON CONFLICT(key) DO UPDATE SET value = value + 1`
    ).run();

    return new Response(JSON.stringify({ ok: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch {
    return new Response(JSON.stringify({ ok: false }), { status: 500 });
  }
}
