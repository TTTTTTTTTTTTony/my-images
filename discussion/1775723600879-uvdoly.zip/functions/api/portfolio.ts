export async function onRequestGet(context: any) {
  try {
    const { env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: "D1 Database not bound" }), { status: 500 });
    }
    
    const { results } = await env.DB.prepare("SELECT data FROM portfolio_state WHERE id = 1").all();
    
    if (results && results.length > 0) {
      return new Response(results[0].data, {
        headers: { "Content-Type": "application/json" }
      });
    } else {
      return new Response(JSON.stringify({ error: "No data found" }), { status: 404 });
    }
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPost(context: any) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: "D1 Database not bound" }), { status: 500 });
    }

    // In a real app, you would verify a token or password here
    // const authHeader = request.headers.get('Authorization');
    // if (authHeader !== `Bearer ${env.ADMIN_PASSWORD}`) return new Response('Unauthorized', { status: 401 });

    const data = await request.json();
    const jsonString = JSON.stringify(data);

    // Upsert the data
    await env.DB.prepare(
      "INSERT INTO portfolio_state (id, data) VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET data = excluded.data"
    ).bind(jsonString).run();

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
