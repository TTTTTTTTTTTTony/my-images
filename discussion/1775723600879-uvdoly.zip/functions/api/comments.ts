export async function onRequestGet(context: any) {
  try {
    const { request, env } = context;
    const url = new URL(request.url);
    const targetId = url.searchParams.get('targetId');

    if (!env.DB) {
      return new Response(JSON.stringify({ error: "D1 Database not bound" }), { status: 500 });
    }

    // Initialize comments table if it doesn't exist
    await env.DB.prepare(`
      CREATE TABLE IF NOT EXISTS comments (
        id TEXT PRIMARY KEY,
        target_id TEXT NOT NULL,
        author_name TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    `).run();

    try {
      await env.DB.prepare("ALTER TABLE comments ADD COLUMN replies TEXT DEFAULT '[]'").run();
    } catch {
      // exists
    }

    if (url.searchParams.get('all') === '1') {
      const { results } = await env.DB.prepare(
        "SELECT * FROM comments ORDER BY created_at DESC LIMIT 500"
      ).all();
      return new Response(JSON.stringify(results || []), {
        headers: { "Content-Type": "application/json" },
      });
    }

    if (!targetId) {
      return new Response(JSON.stringify({ error: "Missing targetId" }), { status: 400 });
    }

    const { results } = await env.DB.prepare(
      "SELECT * FROM comments WHERE target_id = ? ORDER BY created_at DESC"
    ).bind(targetId).all();

    return new Response(JSON.stringify(results || []), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPost(context: any) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: "D1 Database not bound" }), { status: 500 });
    }

    // Initialize comments table if it doesn't exist
    await env.DB.prepare(`
      CREATE TABLE IF NOT EXISTS comments (
        id TEXT PRIMARY KEY,
        target_id TEXT NOT NULL,
        author_name TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    `).run();

    try {
      await env.DB.prepare("ALTER TABLE comments ADD COLUMN replies TEXT DEFAULT '[]'").run();
    } catch {
      // exists
    }

    const data = await request.json();
    const { targetId, authorName, content, action, commentId } = data;

    if (action === 'reply') {
      if (!commentId || !authorName || !content) {
        return new Response(JSON.stringify({ error: "Missing required fields for reply" }), { status: 400 });
      }
      const row = await env.DB.prepare("SELECT replies FROM comments WHERE id = ?").bind(commentId).first();
      if (!row) {
        return new Response(JSON.stringify({ error: "Comment not found" }), { status: 404 });
      }
      let replies = [];
      try {
        replies = JSON.parse(row.replies || '[]');
      } catch {
        replies = [];
      }
      const replyId = crypto.randomUUID();
      const createdAt = new Date().toISOString();
      replies.push({ id: replyId, author_name: authorName, content, created_at: createdAt });
      await env.DB.prepare("UPDATE comments SET replies = ? WHERE id = ?").bind(JSON.stringify(replies), commentId).run();
      
      try {
        // Notify original author
        const authorRow = await env.DB.prepare("SELECT author_name FROM comments WHERE id = ?").bind(commentId).first();
        if (authorRow && authorRow.author_name !== authorName) {
          await env.DB.prepare(`
            CREATE TABLE IF NOT EXISTS user_notifications (
              id TEXT PRIMARY KEY,
              username TEXT NOT NULL,
              type TEXT NOT NULL,
              from_user TEXT NOT NULL,
              body TEXT NOT NULL,
              link TEXT,
              read INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL
            )
          `).run();
          const nid = crypto.randomUUID();
          await env.DB.prepare(
            `INSERT INTO user_notifications (id, username, type, from_user, body, link, read, created_at) VALUES (?, ?, 'reply', ?, ?, ?, 0, ?)`
          ).bind(nid, authorRow.author_name, authorName, `${authorName} 回复了你的评论：${content.slice(0, 50)}`, '', createdAt).run();
        }
      } catch {
        // ignore
      }

      const updatedRow = await env.DB.prepare("SELECT * FROM comments WHERE id = ?").bind(commentId).first();
      return new Response(JSON.stringify({ success: true, comment: updatedRow }), {
        headers: { "Content-Type": "application/json" }
      });
    }

    if (!targetId || !authorName || !content) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), { status: 400 });
    }

    const id = crypto.randomUUID();
    const createdAt = new Date().toISOString();

    await env.DB.prepare(
      "INSERT INTO comments (id, target_id, author_name, content, created_at) VALUES (?, ?, ?, ?, ?)"
    ).bind(id, targetId, authorName, content, createdAt).run();

    try {
      await env.DB.prepare(`
        CREATE TABLE IF NOT EXISTS admin_notifications (
          id TEXT PRIMARY KEY,
          type TEXT NOT NULL,
          message TEXT NOT NULL,
          detail TEXT,
          created_at TEXT NOT NULL,
          read INTEGER NOT NULL DEFAULT 0
        )
      `).run();
      const nid = crypto.randomUUID();
      await env.DB.prepare(
        `INSERT INTO admin_notifications (id, type, message, detail, created_at, read) VALUES (?, 'comment', ?, ?, ?, 0)`
      ).bind(
        nid,
        `新评论：${authorName} 在内容 ${targetId} 下留言`,
        JSON.stringify({ targetId, authorName, preview: content.slice(0, 120) }),
        createdAt
      ).run();
    } catch {
      // ignore
    }

    return new Response(JSON.stringify({ success: true, comment: { id, target_id: targetId, author_name: authorName, content, created_at: createdAt } }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPatch(context: any) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: "D1 Database not bound" }), { status: 500 });
    }

    await env.DB.prepare(`
      CREATE TABLE IF NOT EXISTS comments (
        id TEXT PRIMARY KEY,
        target_id TEXT NOT NULL,
        author_name TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    `).run();

    const data = await request.json();
    const { id, content, editorUsername } = data;

    if (!id || !content || !String(content).trim()) {
      return new Response(JSON.stringify({ error: "Missing id or content" }), { status: 400 });
    }

    const row = await env.DB.prepare("SELECT * FROM comments WHERE id = ?").bind(id).first();
    if (!row) {
      return new Response(JSON.stringify({ error: "Not found" }), { status: 404 });
    }

    const editor = editorUsername
      ? await env.DB.prepare("SELECT role FROM users WHERE username = ?").bind(editorUsername).first()
      : null;
    const isAdmin = editor?.role === 'admin';
    const isAuthor = editorUsername && row.author_name === editorUsername;
    if (!isAdmin && !isAuthor) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403 });
    }

    await env.DB.prepare(
      "UPDATE comments SET content = ? WHERE id = ?"
    ).bind(String(content).trim(), id).run();

    const updatedRow = await env.DB.prepare("SELECT * FROM comments WHERE id = ?").bind(id).first();

    return new Response(JSON.stringify({ success: true, comment: updatedRow }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestDelete(context: any) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: "D1 Database not bound" }), { status: 500 });
    }

    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    const editorUsername = url.searchParams.get('editorUsername');

    if (!id) {
      return new Response(JSON.stringify({ error: "Missing comment id" }), { status: 400 });
    }

    const row = await env.DB.prepare("SELECT * FROM comments WHERE id = ?").bind(id).first();
    if (!row) {
      return new Response(JSON.stringify({ error: "Not found" }), { status: 404 });
    }

    const editor = editorUsername
      ? await env.DB.prepare("SELECT role FROM users WHERE username = ?").bind(editorUsername).first()
      : null;
    const isAdmin = editor?.role === 'admin';
    const isAuthor = editorUsername && row.author_name === editorUsername;
    if (!isAdmin && !isAuthor) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403 });
    }

    await env.DB.prepare("DELETE FROM comments WHERE id = ?").bind(id).run();

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
