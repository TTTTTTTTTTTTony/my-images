export async function onRequestPost(context: any) {
  try {
    const { request, env } = context;
    
    // Check for required environment variables or headers
    const githubToken = request.headers.get('x-github-token') || env.GITHUB_TOKEN;
    const githubRepo = request.headers.get('x-github-repo') || env.GITHUB_REPO;
    
    if (!githubToken || !githubRepo) {
      return new Response(
        JSON.stringify({
          error:
            "GitHub 未配置：请在 Cloudflare Pages → 项目 → Settings → Environment variables 中为生产环境设置密钥 GITHUB_TOKEN（Personal access token，需 repo 权限），并设置变量 GITHUB_REPO，格式为 用户名/仓库名。本地可用 wrangler pages dev 并配置 .dev.vars。",
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    let filename, content, message, folderPath;

    const contentType = request.headers.get('content-type') || '';
    if (contentType.includes('multipart/form-data')) {
      const formData = await request.formData();
      const file = formData.get('file');
      folderPath = formData.get('folderPath') || '';
      message = formData.get('message') || '';
      
      if (!file || !(file instanceof File)) {
        return new Response(JSON.stringify({ error: "Missing file" }), { 
          status: 400,
          headers: { "Content-Type": "application/json" }
        });
      }

      const buffer = await file.arrayBuffer();
      const base64 = btoa(
        new Uint8Array(buffer)
          .reduce((data, byte) => data + String.fromCharCode(byte), '')
      );
      
      content = base64;
      const timestamp = new Date().getTime();
      const randomStr = Math.random().toString(36).substring(2, 8);
      const extension = file.name.split('.').pop() || 'png';
      filename = `${timestamp}-${randomStr}.${extension}`;
    } else {
      const body = await request.json();
      filename = body.filename;
      content = body.content;
      message = body.message;
      folderPath = body.folderPath;
    }

    if (!filename || !content) {
      return new Response(JSON.stringify({ error: "Missing filename or content" }), { 
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }

    const safeName = String(filename).replace(/^\/+/, '');
    const path = folderPath
      ? `${String(folderPath).replace(/\/+$/, '')}/${safeName}`.replace(/\/+/g, '/')
      : safeName;

    const tokenStr = String(githubToken);
    const authHeader =
      tokenStr.startsWith('ghp_') || tokenStr.startsWith('github_pat_')
        ? `Bearer ${tokenStr}`
        : `token ${tokenStr}`;

    const encodedPath = path
      .split('/')
      .map((seg: string) => encodeURIComponent(seg))
      .join('/');

    const response = await fetch(`https://api.github.com/repos/${githubRepo}/contents/${encodedPath}`, {
      method: 'PUT',
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json',
        'User-Agent': 'Cloudflare-Pages-Function'
      },
      body: JSON.stringify({
        message: message || `Upload ${filename}`,
        content: content,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      let errorMsg = errorData.message || 'GitHub API error';
      if (response.status === 404) {
        errorMsg = `GitHub API 返回 404 Not Found。请检查：1. GITHUB_REPO 格式是否正确 (例如 user/repo)。2. GITHUB_TOKEN 是否具有该仓库的写入权限 (repo 权限)。3. 仓库是否存在。`;
      }
      return new Response(JSON.stringify({ error: errorMsg }), { 
        status: response.status,
        headers: { "Content-Type": "application/json" }
      });
    }

    const data = await response.json();
    
    // jsDelivr: full path under repo (default branch)
    const cdnUrl = `https://cdn.jsdelivr.net/gh/${githubRepo}/${path}`;
    
    return new Response(JSON.stringify({ success: true, url: cdnUrl, data }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { 
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
}
