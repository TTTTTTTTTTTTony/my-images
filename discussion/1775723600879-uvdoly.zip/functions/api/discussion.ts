function threadIdForPair(a: string, b: string): string {
  return a < b ? `${a}::${b}` : `${b}::${a}`;
}

async function ensureDiscussionTables(env: { DB: any }) {
  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS chat_messages (
      id TEXT PRIMARY KEY,
      channel TEXT NOT NULL,
      author TEXT NOT NULL,
      body TEXT NOT NULL,
      media_url TEXT,
      created_at TEXT NOT NULL,
      revoked_at TEXT
    )
  `).run();

  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS dm_messages (
      id TEXT PRIMARY KEY,
      thread_id TEXT NOT NULL,
      author TEXT NOT NULL,
      body TEXT NOT NULL,
      media_url TEXT,
      created_at TEXT NOT NULL,
      revoked_at TEXT
    )
  `).run();

  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS user_notifications (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL,
      type TEXT NOT NULL,
      from_user TEXT,
      body TEXT,
      link TEXT,
      read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    )
  `).run();
}

function parseMentions(body: string): string[] {
  const set = new Set<string>();
  const re = /@([\w\u4e00-\u9fa5.\-]{1,48})/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(body)) !== null) {
    set.add(m[1]);
  }
  return [...set];
}

async function insertMentionNotifications(
  env: { DB: any },
  mentions: string[],
  fromUser: string,
  body: string,
  link: string,
  allowedMentions?: string[],
  prefix: string = '在讨论区提到你'
) {
  const ts = new Date().toISOString();
  const preview = body.length > 80 ? body.slice(0, 80) + '…' : body;
  
  let targetMentions = mentions;
  if (mentions.includes('所有人')) {
    const { results } = await env.DB.prepare('SELECT username FROM users').all();
    targetMentions = (results || []).map((r: any) => r.username);
  }

  for (const username of targetMentions) {
    if (username === fromUser) continue;
    if (allowedMentions && !allowedMentions.includes(username)) continue;
    const exists = await env.DB.prepare('SELECT 1 FROM users WHERE username = ?').bind(username).first();
    if (!exists) continue;
    const id = crypto.randomUUID();
    await env.DB.prepare(
      `INSERT INTO user_notifications (id, username, type, from_user, body, link, read, created_at) VALUES (?, ?, 'mention', ?, ?, ?, 0, ?)`
    )
      .bind(id, username, fromUser, `${fromUser} ${prefix}：${preview}`, link, ts)
      .run();
  }
}

async function isMuted(env: { DB: any }, username: string): Promise<boolean> {
  const u = await env.DB.prepare('SELECT muted_until FROM users WHERE username = ?').bind(username).first();
  if (!u || !u.muted_until) return false;
  const ms = Date.parse(u.muted_until);
  return Number.isFinite(ms) && ms > Date.now();
}

export async function onRequestGet(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureDiscussionTables(env);
    const url = new URL(request.url);

    if (url.searchParams.get('mentionList') === '1') {
      const { results } = await env.DB.prepare('SELECT username FROM users ORDER BY username ASC').all();
      return new Response(JSON.stringify({ usernames: (results || []).map((r: any) => r.username) }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (url.searchParams.get('channel') === 'dm' && url.searchParams.get('admin_all') === '1') {
      const reader = url.searchParams.get('reader');
      if (!reader) {
        return new Response(JSON.stringify({ error: 'Missing reader' }), { status: 400 });
      }
      const admin = await env.DB.prepare("SELECT role FROM users WHERE username = ?").bind(reader).first();
      if (!admin || !['owner', 'senior_admin'].includes(admin.role)) {
        return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403 });
      }
      const { results } = await env.DB.prepare(
        `SELECT * FROM dm_messages WHERE revoked_at IS NULL ORDER BY created_at DESC LIMIT 500`
      ).all();
      return new Response(JSON.stringify({ messages: results || [] }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (url.searchParams.get('channel') === 'dm' && url.searchParams.get('list') === '1') {
      const reader = url.searchParams.get('reader');
      if (!reader) {
        return new Response(JSON.stringify({ error: 'Missing reader' }), { status: 400 });
      }
      const { results } = await env.DB.prepare(
        `SELECT thread_id, MAX(created_at) as last_at FROM dm_messages WHERE revoked_at IS NULL GROUP BY thread_id`
      ).all();
      const threads: { thread_id: string; peer: string; last_at: string }[] = [];
      for (const r of results || []) {
        const tid = (r as any).thread_id as string;
        const parts = tid.split('::');
        if (parts.length !== 2) continue;
        const [a, b] = parts;
        if (a !== reader && b !== reader) continue;
        const peer = a === reader ? b : a;
        threads.push({
          thread_id: tid,
          peer,
          last_at: (r as any).last_at,
        });
      }
      threads.sort((x, y) => (y.last_at > x.last_at ? 1 : -1));
      return new Response(JSON.stringify({ threads }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (url.searchParams.get('channel') === 'dm') {
      const peer = url.searchParams.get('peer');
      const reader = url.searchParams.get('reader');
      if (!peer || !reader) {
        return new Response(JSON.stringify({ error: 'Missing peer or reader' }), { status: 400 });
      }
      const tid = threadIdForPair(peer, reader);
      const { results } = await env.DB.prepare(
        `SELECT * FROM dm_messages WHERE thread_id = ? AND revoked_at IS NULL ORDER BY created_at ASC LIMIT 300`
      )
        .bind(tid)
        .all();
      return new Response(JSON.stringify({ messages: results || [] }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const channel = url.searchParams.get('channel') || 'community';
    const { results } = await env.DB.prepare(
      `SELECT * FROM chat_messages WHERE channel = ? AND revoked_at IS NULL ORDER BY created_at ASC LIMIT 300`
    )
      .bind(channel)
      .all();
    return new Response(JSON.stringify({ messages: results || [] }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPost(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureDiscussionTables(env);
    const body = await request.json();
    const { channel, body: textBody, author, media_url, peer } = body;

    if (!author || !textBody) {
      return new Response(JSON.stringify({ error: 'Missing fields' }), { status: 400 });
    }

    if (await isMuted(env, author)) {
      return new Response(JSON.stringify({ error: '您已被禁言' }), { status: 403 });
    }

    const createdAt = new Date().toISOString();

    if (channel === 'dm') {
      if (!peer) {
        return new Response(JSON.stringify({ error: 'Missing peer for DM' }), { status: 400 });
      }
      const tid = threadIdForPair(peer, author);
      const id = crypto.randomUUID();
      await env.DB.prepare(
        `INSERT INTO dm_messages (id, thread_id, author, body, media_url, created_at) VALUES (?, ?, ?, ?, ?, ?)`
      )
        .bind(id, tid, author, String(textBody), media_url || null, createdAt)
        .run();

      const dmLink = `/discuss?dm=${encodeURIComponent(author)}`;
      
      // Notify the peer about the new DM
      const preview = String(textBody).length > 80 ? String(textBody).slice(0, 80) + '…' : String(textBody);
      
      // Check if peer is mentioned. If so, we might not need a separate DM notification, or we can have both.
      // Let's just add the mention notification for the peer if they are mentioned.
      const mentions = parseMentions(String(textBody));
      if (mentions.includes(peer)) {
        await insertMentionNotifications(env, [peer], author, String(textBody), dmLink, [peer], '在私聊中提到你');
      } else {
        const notifId = crypto.randomUUID();
        await env.DB.prepare(
          `INSERT INTO user_notifications (id, username, type, from_user, body, link, read, created_at) VALUES (?, ?, 'dm', ?, ?, ?, 0, ?)`
        )
          .bind(notifId, peer, author, `${author} 给你发送了私信：${preview}`, dmLink, createdAt)
          .run();
      }

      const message = { id, thread_id: tid, author, body: textBody, media_url: media_url || null, created_at: createdAt };
      return new Response(JSON.stringify({ success: true, message }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (!channel || !['community', 'staff'].includes(channel)) {
      return new Response(JSON.stringify({ error: 'Invalid channel' }), { status: 400 });
    }

    /** 管理员频道：所有已登录用户可见可发（与社区一致，仅分区不同） */
    const id = crypto.randomUUID();
    await env.DB.prepare(
      `INSERT INTO chat_messages (id, channel, author, body, media_url, created_at) VALUES (?, ?, ?, ?, ?, ?)`
    )
      .bind(id, channel, author, String(textBody), media_url || null, createdAt)
      .run();

    const link = `/discuss?channel=${channel}`;
    const allowed = channel === 'staff' ? ['owner'] : undefined;
    const prefix = channel === 'staff' ? '在管理员频道提到你' : '在群聊中提到你';
    await insertMentionNotifications(env, parseMentions(String(textBody)), author, String(textBody), link, allowed, prefix);

    if (author === 'owner' && (channel === 'community' || channel === 'staff')) {
      const { results: allUsers } = await env.DB.prepare('SELECT username FROM users WHERE username != ?').bind('owner').all();
      const mentions = parseMentions(String(textBody));
      const preview = String(textBody).length > 80 ? String(textBody).slice(0, 80) + '…' : String(textBody);
      const channelName = channel === 'community' ? '群聊' : '管理员频道';
      for (const u of allUsers || []) {
        const username = (u as any).username;
        if (!mentions.includes(username) && !mentions.includes('所有人')) {
          const notifId = crypto.randomUUID();
          await env.DB.prepare(
            `INSERT INTO user_notifications (id, username, type, from_user, body, link, read, created_at) VALUES (?, ?, 'system', ?, ?, ?, 0, ?)`
          )
            .bind(notifId, username, author, `群主在${channelName}发布了新消息：${preview}`, link, createdAt)
            .run();
        }
      }
    }

    const message = {
      id,
      channel,
      author,
      body: textBody,
      media_url: media_url || null,
      created_at: createdAt,
    };
    return new Response(JSON.stringify({ success: true, message }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPatch(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }
    await ensureDiscussionTables(env);
    const data = await request.json();
    const { messageId, kind, revokedBy } = data;
    if (!messageId || !revokedBy || !kind) {
      return new Response(JSON.stringify({ error: 'Missing fields' }), { status: 400 });
    }

    const editor = await env.DB.prepare('SELECT role FROM users WHERE username = ?').bind(revokedBy).first();
    const isPrivileged = ['owner', 'senior_admin', 'group_admin'].includes(editor?.role);

    if (kind === 'chat') {
      const row = await env.DB.prepare('SELECT * FROM chat_messages WHERE id = ?').bind(messageId).first();
      if (!row) {
        return new Response(JSON.stringify({ error: 'Not found' }), { status: 404 });
      }
      if (!isPrivileged && row.author !== revokedBy) {
        return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403 });
      }
      const ts = new Date().toISOString();
      await env.DB.prepare('UPDATE chat_messages SET revoked_at = ? WHERE id = ?').bind(ts, messageId).run();
      return new Response(JSON.stringify({ success: true }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (kind === 'dm') {
      const row = await env.DB.prepare('SELECT * FROM dm_messages WHERE id = ?').bind(messageId).first();
      if (!row) {
        return new Response(JSON.stringify({ error: 'Not found' }), { status: 404 });
      }
      if (!isPrivileged && row.author !== revokedBy) {
        return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403 });
      }
      const ts = new Date().toISOString();
      await env.DB.prepare('UPDATE dm_messages SET revoked_at = ? WHERE id = ?').bind(ts, messageId).run();
      return new Response(JSON.stringify({ success: true }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Invalid kind' }), { status: 400 });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
