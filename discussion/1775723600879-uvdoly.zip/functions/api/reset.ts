export async function onRequestPost(context: any) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: "D1 Database not bound" }), { status: 500 });
    }

    const data = await request.json();
    const { action, adminUsername, days = 30 } = data;

    if (!adminUsername) {
      return new Response(JSON.stringify({ error: "Missing adminUsername" }), { status: 400 });
    }

    const admin = await env.DB.prepare("SELECT role FROM users WHERE username = ?").bind(adminUsername).first();
    if (!admin || !['owner', 'senior_admin'].includes(admin.role)) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403 });
    }

    if (action === 'reset_portfolio') {
      await env.DB.prepare("DELETE FROM portfolio_state WHERE id = 1").run();
    } else if (action === 'clear_community_chats') {
      const dateLimit = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
      await env.DB.prepare("DELETE FROM chat_messages WHERE channel = 'community' AND created_at < ?").bind(dateLimit).run();
    } else if (action === 'clear_owner_chats') {
      const dateLimit = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
      await env.DB.prepare("DELETE FROM chat_messages WHERE channel = 'owner' AND created_at < ?").bind(dateLimit).run();
    } else if (action === 'clear_dms') {
      const dateLimit = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
      await env.DB.prepare("DELETE FROM dm_messages WHERE created_at < ?").bind(dateLimit).run();
    } else if (action === 'clear_notifications') {
      const dateLimit = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
      await env.DB.prepare("DELETE FROM user_notifications WHERE read = 1 AND created_at < ?").bind(dateLimit).run();
      try {
        await env.DB.prepare("DELETE FROM admin_notifications WHERE read = 1 AND created_at < ?").bind(dateLimit).run();
      } catch {
        // ignore
      }
    } else if (action === 'clear_inactive_users') {
      const dateLimit = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
      // Assuming we have a last_login or created_at. We'll use created_at for now if last_login doesn't exist.
      // But let's check if we can delete users with role 'user'
      await env.DB.prepare("DELETE FROM users WHERE role = 'user' AND created_at < ?").bind(dateLimit).run();
    } else if (action === 'clear_unused_media') {
      // Placeholder for GitHub media cleanup
      // In a real scenario, this would call GitHub API to delete unused files
    } else if (action === 'optimize_db') {
      // Placeholder for D1 optimization (VACUUM is not supported directly via D1 API yet, but we can return success)
    } else {
      return new Response(JSON.stringify({ error: "Invalid action" }), { status: 400 });
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
