/** Public profile for a user (by username). */
export async function onRequestGet(context: { request: Request; env: any }) {
  try {
    const { request, env } = context;
    if (!env.DB) {
      return new Response(JSON.stringify({ error: 'D1 not bound' }), { status: 500 });
    }

    const url = new URL(request.url);
    const u = url.searchParams.get('u');
    if (!u) {
      return new Response(JSON.stringify({ error: 'Missing u' }), { status: 400 });
    }

    const row = await env.DB.prepare(
      'SELECT username, avatar, bio, email, email_public, role FROM users WHERE username = ?'
    )
      .bind(u)
      .first();

    if (!row) {
      return new Response(JSON.stringify({ error: 'Not found' }), { status: 404 });
    }

    const emailPublic = Number(row.email_public) === 1;
    return new Response(
      JSON.stringify({
        username: row.username,
        avatar: row.avatar || null,
        bio: row.bio || null,
        email: emailPublic ? row.email || null : null,
        emailVisible: emailPublic,
        role: row.role === 'admin' ? 'admin' : 'user',
      }),
      { headers: { 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
