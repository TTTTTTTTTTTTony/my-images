import React from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { EditableText } from './EditableText';
import { Plus, Trash2 } from 'lucide-react';
import { ReorderButtons } from './ReorderButtons';

const Skills: React.FC = () => {
  const { data, updateField, addArrayItem, removeArrayItem, isEditMode } = usePortfolio();

  const handleAddSkill = () => {
    addArrayItem(['skills'], {
      name: '新技能',
      level: 50,
      icon: '🔧',
      category: '新分类'
    });
  };

  return (
    <section id="skills" className="py-20 bg-gray-50 dark:bg-slate-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 relative">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">我的技能</h2>
          <div className="w-20 h-1 bg-primary mx-auto rounded-full"></div>
          
          {isEditMode && (
            <button 
              onClick={handleAddSkill}
              className="absolute right-0 top-0 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Plus size={18} /> 添加技能
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.skills.map((skill, index) => (
            <div key={index} className="relative bg-white dark:bg-slate-800 p-6 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-600 transition-all hover:-translate-y-1 group">
              {isEditMode && (
                <div className="absolute -top-3 -right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                  <ReorderButtons path={['skills']} index={index} totalLength={data.skills.length} className="flex-row" />
                  <button 
                    onClick={() => removeArrayItem(['skills'], index)}
                    className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"
                    title="删除技能"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              )}
              
              <div className="flex justify-between items-start mb-4 gap-2">
                <div className="flex items-center gap-3 min-h-[3rem]">
                  <EditableText
                    as="span"
                    value={skill.icon}
                    onSave={(val) => updateField(['skills', index.toString(), 'icon'], val)}
                    className="text-4xl block"
                  />
                </div>
                <EditableText
                  as="span"
                  value={skill.category}
                  onSave={(val) => updateField(['skills', index.toString(), 'category'], val)}
                  className="text-xs font-semibold px-2 py-1 bg-slate-200 dark:bg-gray-800 rounded text-slate-700 dark:text-gray-300 border border-slate-300 dark:border-gray-700 block shrink-0"
                />
              </div>
              <EditableText
                as="h3"
                value={skill.name}
                onSave={(val) => updateField(['skills', index.toString(), 'name'], val)}
                className="text-lg font-bold text-slate-900 dark:text-white mb-2 block"
              />
              <div className="w-full bg-slate-200 dark:bg-gray-800 rounded-full h-2 mb-2 relative overflow-hidden">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-1000 ease-out"
                  style={{ width: `${skill.level}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-xs text-slate-600 dark:text-gray-500 mt-2">
                <span>熟练度:</span>
                <div className="flex items-center gap-1">
                  {isEditMode ? (
                    <input 
                      type="number" 
                      min="0" 
                      max="100" 
                      value={skill.level}
                      onChange={(e) => updateField(['skills', index.toString(), 'level'], parseInt(e.target.value) || 0)}
                      className="w-16 px-1 py-0.5 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-primary"
                    />
                  ) : null}
                  <span className="w-8 text-right">{skill.level}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
