import React, { useState, useRef, useMemo, useEffect } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import { usePortfolio } from '../context/PortfolioContext';
import { Upload, Link2 } from 'lucide-react';
import { MediaUploadModal } from './MediaUploadModal';

interface MarkdownEditorProps {
  value: string;
  onSave: (val: string) => void;
  className?: string;
  folderPath?: string;
  onSubmit?: (val: string) => void;
  disabled?: boolean;
  placeholder?: string;
  alwaysEdit?: boolean;
}

export const MarkdownEditor: React.FC<MarkdownEditorProps> = ({ value, onSave, className = '', folderPath = 'markdown', onSubmit, disabled, placeholder, alwaysEdit }) => {
  const { isEditMode } = usePortfolio();
  const [isEditing, setIsEditing] = useState(alwaysEdit || false);
  const [tempValue, setTempValue] = useState(value);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setTempValue(value);
  }, [value]);

  useEffect(() => {
    if (alwaysEdit) {
      setIsEditing(true);
    }
  }, [alwaysEdit]);

  const mdComponents = useMemo(
    () => ({
      video: (props: React.ComponentProps<'video'>) => (
        <video {...props} className={`w-full rounded-lg my-4 max-h-[70vh] ${props.className || ''}`} controls playsInline />
      ),
      audio: (props: React.ComponentProps<'audio'>) => (
        <audio {...props} className={`w-full my-4 ${props.className || ''}`} controls />
      ),
    }),
    []
  );

  const insertLink = () => {
    const label = window.prompt('链接文字', '链接');
    if (label === null) return;
    const href = window.prompt('URL（https://…）', 'https://');
    if (!href) return;
    const md = `\n[${label || '链接'}](${href})\n`;
    const textarea = textareaRef.current;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      setTempValue(tempValue.substring(0, start) + md + tempValue.substring(end));
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + md.length;
        textarea.focus();
      }, 0);
    } else {
      setTempValue((prev) => prev + md);
    }
  };

  const handleInsertMedia = (url: string, isVideo: boolean, isAudio?: boolean) => {
    let markdownInsert = `\n![图片](${url})\n`;
    if (isVideo) {
      markdownInsert = `\n<video src="${url}" controls playsinline class="w-full rounded-lg my-4 max-h-[70vh]"></video>\n`;
    } else if (isAudio) {
      markdownInsert = `\n<audio src="${url}" controls class="w-full my-4"></audio>\n`;
    }

    const textarea = textareaRef.current;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const newValue = tempValue.substring(0, start) + markdownInsert + tempValue.substring(end);
      setTempValue(newValue);
      
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + markdownInsert.length;
        textarea.focus();
      }, 0);
    } else {
      setTempValue(prev => prev + markdownInsert);
    }
  };

  if (!isEditMode && !alwaysEdit) {
    return (
      <div className={`prose dark:prose-invert max-w-none ${className}`}>
        <Markdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeRaw]} components={mdComponents as any}>
          {value}
        </Markdown>
      </div>
    );
  }

  if (isEditing) {
    return (
      <div className={`flex flex-col gap-2 ${className}`}>
        <div className="flex flex-wrap items-center gap-4 bg-gray-100 dark:bg-slate-800 p-2 rounded-t-lg border border-b-0 border-gray-300 dark:border-primary">
          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1 bg-white dark:bg-slate-700 text-slate-700 dark:text-white px-3 py-1.5 rounded hover:bg-gray-50 dark:hover:bg-slate-600 transition-colors text-sm border border-gray-200 dark:border-transparent shadow-sm"
          >
            <Upload size={16} /> 插入媒体
          </button>
          <button
            type="button"
            onClick={insertLink}
            className="flex items-center gap-1 bg-white dark:bg-slate-700 text-slate-700 dark:text-white px-3 py-1.5 rounded hover:bg-gray-50 dark:hover:bg-slate-600 transition-colors text-sm border border-gray-200 dark:border-transparent shadow-sm"
          >
            <Link2 size={16} /> 插入链接
          </button>
        </div>
        
        <textarea
          ref={textareaRef}
          value={tempValue}
          onChange={(e) => setTempValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && onSubmit) {
              e.preventDefault();
              onSubmit(tempValue);
              setTempValue('');
            }
          }}
          onPaste={async (e) => {
            const items = e.clipboardData?.items;
            if (!items) return;
            for (let i = 0; i < items.length; i++) {
              if (items[i].type.indexOf('image') !== -1) {
                e.preventDefault();
                const file = items[i].getAsFile();
                if (file) {
                  const formData = new FormData();
                  formData.append('file', file);
                  formData.append('folderPath', folderPath);
                  try {
                    const res = await fetch('/api/upload', {
                      method: 'POST',
                      body: formData,
                    });
                    if (res.ok) {
                      const d = await res.json();
                      if (d.url) {
                        const markdownInsert = `\n![图片](${d.url})\n`;
                        const textarea = textareaRef.current;
                        if (textarea) {
                          const start = textarea.selectionStart;
                          const end = textarea.selectionEnd;
                          const newValue = tempValue.substring(0, start) + markdownInsert + tempValue.substring(end);
                          setTempValue(newValue);
                          setTimeout(() => {
                            textarea.selectionStart = textarea.selectionEnd = start + markdownInsert.length;
                            textarea.focus();
                          }, 0);
                        } else {
                          setTempValue(prev => prev + markdownInsert);
                        }
                      }
                    } else {
                      const d = await res.json();
                      alert('图片上传失败: ' + (d.error || '未知错误'));
                    }
                  } catch (err: any) {
                    alert('图片上传失败: ' + err.message);
                  }
                }
                break;
              }
            }
          }}
          className={`w-full min-h-[200px] md:min-h-[300px] resize-y bg-white dark:bg-slate-900 text-slate-900 dark:text-white border border-gray-300 dark:border-primary px-4 py-3 ${alwaysEdit ? 'rounded-b-lg' : 'rounded-b-lg'} focus:outline-none font-mono text-sm disabled:opacity-50 disabled:cursor-not-allowed`}
          placeholder={placeholder || "支持 Markdown 语法… 可插入媒体或链接"}
          disabled={disabled}
        />
        
        {!alwaysEdit && (
          <div className="flex gap-2 mt-2">
            <button 
              onClick={() => { onSave(tempValue); setIsEditing(false); }} 
              className="bg-primary text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors text-sm"
            >
              保存内容
            </button>
            <button 
              onClick={() => setIsEditing(false)} 
              className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-500 transition-colors text-sm"
            >
              取消
            </button>
          </div>
        )}

        <MediaUploadModal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          onInsert={handleInsertMedia} 
          folderPath={folderPath}
          allowAllMedia={true}
        />
      </div>
    );
  }

  return (
    <div 
      className={`prose dark:prose-invert max-w-none group relative ${disabled ? '' : 'cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800/50 hover:border-gray-300 dark:hover:border-gray-700'} p-4 rounded-lg border border-transparent transition-colors ${className}`}
      onClick={() => {
        if (!disabled) {
          setIsEditing(true);
        }
      }}
    >
      <Markdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeRaw]} components={mdComponents as any}>
        {value}
      </Markdown>
      {!disabled && (
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 bg-primary text-white text-xs px-2 py-1 rounded transition-opacity">
          点击编辑 Markdown
        </div>
      )}
    </div>
  );
};
