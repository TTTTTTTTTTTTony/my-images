import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface ReorderButtonsProps {
  path: string[];
  index: number;
  totalLength: number;
  className?: string;
}

export const ReorderButtons: React.FC<ReorderButtonsProps> = ({ path, index, totalLength, className = '' }) => {
  const { isEditMode, moveArrayItem } = usePortfolio();

  if (!isEditMode) return null;

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      <button
        onClick={() => moveArrayItem(path, index, index - 1)}
        disabled={index === 0}
        className="p-1 bg-slate-700 hover:bg-slate-600 disabled:opacity-30 disabled:hover:bg-slate-700 text-white rounded transition-colors"
        title="上移"
      >
        <ArrowUp size={14} />
      </button>
      <button
        onClick={() => moveArrayItem(path, index, index + 1)}
        disabled={index === totalLength - 1}
        className="p-1 bg-slate-700 hover:bg-slate-600 disabled:opacity-30 disabled:hover:bg-slate-700 text-white rounded transition-colors"
        title="下移"
      >
        <ArrowDown size={14} />
      </button>
    </div>
  );
};
