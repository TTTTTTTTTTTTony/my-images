import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, User, Trash2, Plus, Pencil, Check, Reply } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

interface ReplyData {
  id: string;
  author_name: string;
  content: string;
  created_at: string;
}

interface Comment {
  id: string;
  target_id: string;
  author_name: string;
  content: string;
  created_at: string;
  replies?: string | ReplyData[];
}

interface CommentsProps {
  targetId: string;
}

export const Comments: React.FC<CommentsProps> = ({ targetId }) => {
  const { currentUser, isEditMode } = usePortfolio();
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  useEffect(() => {
    fetchComments();
  }, [targetId]);

  const fetchComments = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/comments?targetId=${targetId}`);
      if (res.ok) {
        const data = await res.json();
        setComments(data);
      }
    } catch (error) {
      console.error('Failed to fetch comments:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !currentUser) return;

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetId,
          authorName: currentUser.username,
          content: newComment.trim()
        })
      });

      if (res.ok) {
        const data = await res.json();
        setComments([data.comment, ...comments]);
        setNewComment('');
        setShowForm(false);
      }
    } catch (error) {
      console.error('Failed to post comment:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReply = async (commentId: string) => {
    if (!replyText.trim() || !currentUser) return;
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'reply',
          commentId,
          authorName: currentUser.username,
          content: replyText.trim()
        })
      });
      if (res.ok) {
        const data = await res.json();
        setComments(prev => prev.map(c => c.id === commentId ? data.comment : c));
        setReplyingTo(null);
        setReplyText('');
      }
    } catch (error) {
      console.error('Failed to post reply:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const startEdit = (c: Comment) => {
    setEditingId(c.id);
    setEditText(c.content);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditText('');
  };

  const saveEdit = async (id: string) => {
    const trimmed = editText.trim();
    if (!trimmed || !currentUser) return;
    try {
      const res = await fetch('/api/comments', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, content: trimmed, editorUsername: currentUser?.username }),
      });
      if (res.ok) {
        setComments((prev) =>
          prev.map((c) => (c.id === id ? { ...c, content: trimmed } : c))
        );
        cancelEdit();
      }
    } catch (error) {
      console.error('Failed to update comment:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!currentUser) return;
    if (!window.confirm('确定要删除这条评论吗？')) return;
    try {
      const res = await fetch(
        `/api/comments?id=${encodeURIComponent(id)}&editorUsername=${encodeURIComponent(currentUser?.username || '')}`,
        { method: 'DELETE' }
      );
      if (res.ok) {
        setComments(comments.filter(c => c.id !== id));
      }
    } catch (error) {
      console.error('Failed to delete comment:', error);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('zh-CN', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit'
    }).format(date);
  };

  const parseReplies = (replies: string | ReplyData[] | undefined): ReplyData[] => {
    if (!replies) return [];
    if (typeof replies === 'string') {
      try {
        return JSON.parse(replies);
      } catch {
        return [];
      }
    }
    return replies;
  };

  return (
    <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-800">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <MessageSquare size={24} className="text-primary" />
          评论区 ({comments.length})
        </h3>
        {!showForm && (
          <button 
            onClick={() => {
              if (!currentUser) {
                alert('请先登录后发表评论');
                return;
              }
              setShowForm(true);
            }}
            className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg font-medium transition-colors"
          >
            <Plus size={18} /> 写评论
          </button>
        )}
      </div>

      {/* Comment Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="mb-10 bg-gray-50 dark:bg-slate-800/50 p-4 md:p-6 rounded-xl border border-gray-100 dark:border-gray-700 animate-slide-up">
          <div className="mb-4 flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
            <User size={16} />
            <span>当前登录身份：<span className="font-bold text-primary">{currentUser?.username}</span></span>
          </div>
          <div className="mb-4">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="写下您的想法..."
              required
              rows={3}
              className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all resize-none dark:text-white"
            />
          </div>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !newComment.trim()}
              className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-6 py-2 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? '发送中...' : (
                <>
                  <Send size={18} /> 发送评论
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* Comments List */}
      <div className="space-y-6">
        {isLoading ? (
          <div className="text-center py-8 text-gray-500">加载评论中...</div>
        ) : comments.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-slate-800/30 rounded-xl border border-dashed border-gray-200 dark:border-gray-700">
            还没有人评论，来做第一个留言的人吧！
          </div>
        ) : (
          comments.map((comment) => (
            <div key={comment.id} className="flex gap-4 group relative">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold flex-shrink-0">
                {comment.author_name.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1">
                <div className="bg-gray-50 dark:bg-slate-800/80 p-4 rounded-2xl rounded-tl-none border border-gray-100 dark:border-gray-700">
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-bold text-slate-900 dark:text-white">{comment.author_name}</span>
                    <span className="text-xs text-gray-500">{formatDate(comment.created_at)}</span>
                  </div>
                  {editingId === comment.id ? (
                    <div className="space-y-2">
                      <textarea
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        rows={3}
                        className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-gray-300 dark:border-gray-600 rounded-lg text-slate-900 dark:text-white text-sm"
                      />
                      <div className="flex gap-2 justify-end">
                        <button
                          type="button"
                          onClick={cancelEdit}
                          className="text-sm text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                        >
                          取消
                        </button>
                        <button
                          type="button"
                          onClick={() => saveEdit(comment.id)}
                          className="flex items-center gap-1 text-sm bg-primary text-white px-3 py-1 rounded-lg"
                        >
                          <Check size={14} /> 保存
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-slate-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed">
                      {comment.content}
                    </p>
                  )}
                  
                  {/* Replies */}
                  {parseReplies(comment.replies).length > 0 && (
                    <div className="mt-4 space-y-3 pl-4 border-l-2 border-gray-200 dark:border-gray-700">
                      {parseReplies(comment.replies).map(reply => (
                        <div key={reply.id} className="bg-white dark:bg-slate-800 p-3 rounded-xl border border-gray-100 dark:border-gray-700">
                          <div className="flex justify-between items-start mb-1">
                            <span className="font-semibold text-sm text-slate-900 dark:text-white">{reply.author_name}</span>
                            <span className="text-xs text-gray-500">{formatDate(reply.created_at)}</span>
                          </div>
                          <p className="text-sm text-slate-700 dark:text-gray-300 whitespace-pre-wrap">{reply.content}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reply Form */}
                  {replyingTo === comment.id && (
                    <div className="mt-4">
                      <textarea
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder={`回复 ${comment.author_name}...`}
                        rows={2}
                        className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-gray-300 dark:border-gray-600 rounded-lg text-sm outline-none focus:ring-1 focus:ring-primary dark:text-white mb-2"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => { setReplyingTo(null); setReplyText(''); }}
                          className="text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                        >
                          取消
                        </button>
                        <button
                          type="button"
                          onClick={() => handleReply(comment.id)}
                          disabled={isSubmitting || !replyText.trim()}
                          className="text-xs bg-primary text-white px-3 py-1 rounded-md disabled:opacity-50"
                        >
                          发送回复
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                {currentUser && replyingTo !== comment.id && (
                  <button
                    onClick={() => setReplyingTo(comment.id)}
                    className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded-full hover:bg-blue-200 dark:hover:bg-blue-900/50"
                    title="回复"
                  >
                    <Reply size={16} />
                  </button>
                )}
                {currentUser && editingId !== comment.id && (isEditMode || comment.author_name === currentUser.username) && (
                  <>
                    <button
                      onClick={() => startEdit(comment)}
                      className="p-2 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 rounded-full hover:bg-amber-200 dark:hover:bg-amber-900/50"
                      title="编辑评论"
                    >
                      <Pencil size={16} />
                    </button>
                    <button
                      onClick={() => handleDelete(comment.id)}
                      className="p-2 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-full hover:bg-red-200 dark:hover:bg-red-900/50"
                      title="删除评论"
                    >
                      <Trash2 size={16} />
                    </button>
                  </>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
