import React from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { X, Moon, Sun } from 'lucide-react';

interface GlobalSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlobalSettingsModal: React.FC<GlobalSettingsModalProps> = ({ isOpen, onClose }) => {
  const { data, updateField } = usePortfolio();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-white dark:bg-slate-900 w-full max-w-lg max-h-[90vh] rounded-xl shadow-2xl overflow-hidden border border-gray-200 dark:border-gray-800 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-6 border-b border-gray-200 dark:border-gray-800">
          <h3 className="text-xl font-bold text-slate-900 dark:text-white">全局设置</h3>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-slate-900 dark:text-gray-400 dark:hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-grow flex flex-col gap-6">
          <section>
            <h4 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">主题设置</h4>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
              首页「你好我是」区域的背景图请在首页进入编辑模式后，用右上角「设置首屏背景」按钮修改。
            </p>
            <div className="flex items-center gap-4">
              <button
                onClick={() => updateField(['theme'], 'light')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${
                  data.theme === 'light'
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-gray-300 dark:border-gray-700 text-gray-600 dark:text-gray-400'
                }`}
              >
                <Sun size={20} /> 浅色模式
              </button>
              <button
                onClick={() => updateField(['theme'], 'dark')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${
                  data.theme !== 'light'
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-gray-300 dark:border-gray-700 text-gray-600 dark:text-gray-400'
                }`}
              >
                <Moon size={20} /> 深色模式
              </button>
            </div>
          </section>

          <p className="text-xs text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-800 pt-4">
            数据清理、批量操作与定时清理已移至 <strong className="text-slate-700 dark:text-gray-300">管理面板</strong>。
          </p>
        </div>
      </div>
    </div>
  );
};
