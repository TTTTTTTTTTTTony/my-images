import React, { useState, useEffect, useRef } from 'react';
import { usePortfolio } from '../context/PortfolioContext';

interface EditableTextProps {
  value: string;
  onSave: (val: string) => void;
  as?: keyof JSX.IntrinsicElements;
  className?: string;
  multiline?: boolean;
}

export const EditableText: React.FC<EditableTextProps> = ({ value, onSave, as: Component = 'span', className = '', multiline = false }) => {
  const { isEditMode } = usePortfolio();
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState(value);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  useEffect(() => {
    setTempValue(value);
  }, [value]);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isEditing]);

  if (!isEditMode) {
    return <Component className={className}>{value}</Component>;
  }

  if (isEditing) {
    const commonProps = {
      value: tempValue,
      onChange: (e: any) => setTempValue(e.target.value),
      onBlur: () => {
        setIsEditing(false);
        if (tempValue !== value) onSave(tempValue);
      },
      className: `bg-white dark:bg-slate-800 text-slate-900 dark:text-white border border-gray-300 dark:border-primary rounded px-2 py-1 w-full focus:outline-none focus:ring-2 focus:ring-primary ${className}`,
    };

    return multiline ? (
      <textarea {...commonProps} rows={4} ref={inputRef as any} />
    ) : (
      <input type="text" {...commonProps} ref={inputRef as any} />
    );
  }

  return (
    <Component 
      className={`cursor-pointer hover:ring-2 hover:ring-primary hover:ring-dashed rounded transition-all ${className}`}
      onClick={() => setIsEditing(true)}
      title="点击编辑"
    >
      {value || '点击输入内容...'}
    </Component>
  );
};
