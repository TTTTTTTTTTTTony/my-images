import React, { useEffect, useState } from 'react';
import { X, User, Mail, MessageCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';

interface PublicProfile {
  username: string;
  avatar: string | null;
  bio: string | null;
  email: string | null;
  emailVisible: boolean;
  role: string;
}

interface PublicProfileModalProps {
  username: string | null;
  onClose: () => void;
}

export const PublicProfileModal: React.FC<PublicProfileModalProps> = ({ username, onClose }) => {
  const { currentUser } = usePortfolio();
  const navigate = useNavigate();
  const [data, setData] = useState<PublicProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!username) {
      setData(null);
      return;
    }
    setLoading(true);
    setError('');
    fetch(`/api/profile?u=${encodeURIComponent(username)}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.error) setError(j.error);
        else setData(j);
      })
      .catch(() => setError('加载失败'))
      .finally(() => setLoading(false));
  }, [username]);

  if (!username) return null;

  const startDm = () => {
    if (!currentUser) return;
    onClose();
    navigate(`/discuss?dm=${encodeURIComponent(username)}`);
  };

  return (
    <div
      className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full shadow-2xl border border-gray-200 dark:border-gray-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center px-6 py-4 border-b border-gray-100 dark:border-gray-800">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <User size={20} className="text-primary" />
            用户资料
          </h3>
          <button type="button" onClick={onClose} className="text-gray-500 hover:text-slate-900 dark:hover:text-white">
            <X size={22} />
          </button>
        </div>
        <div className="p-6">
          {loading && <p className="text-center text-gray-500 text-sm">加载中…</p>}
          {error && <p className="text-center text-red-500 text-sm">{error}</p>}
          {data && !loading && (
            <div className="flex flex-col items-center text-center gap-4">
              {data.avatar ? (
                <img src={data.avatar} alt="" className="w-24 h-24 rounded-full object-cover border-2 border-primary" />
              ) : (
                <div className="w-24 h-24 rounded-full bg-primary/15 flex items-center justify-center text-3xl font-bold text-primary">
                  {data.username.charAt(0).toUpperCase()}
                </div>
              )}
              <div>
                <p className="text-xl font-bold text-slate-900 dark:text-white">{data.username}</p>
                {['owner', 'senior_admin', 'group_admin'].includes(data.role) && (
                  <span className="text-xs bg-primary/15 text-primary px-2 py-0.5 rounded mt-1 inline-block">{data.role}</span>
                )}
              </div>
              {data.bio && (
                <p className="text-sm text-slate-600 dark:text-gray-300 whitespace-pre-wrap w-full">{data.bio}</p>
              )}
              {data.email && (
                <p className="flex items-center justify-center gap-2 text-sm text-slate-500 dark:text-gray-400">
                  <Mail size={16} />
                  {data.email}
                </p>
              )}
              {currentUser && currentUser.username !== data.username && (
                <button
                  type="button"
                  onClick={startDm}
                  className="mt-2 flex items-center gap-2 bg-primary text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-blue-600 transition-colors"
                >
                  <MessageCircle size={18} />
                  {data.username === 'owner' ? '群主的私聊' : '私聊'}
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
