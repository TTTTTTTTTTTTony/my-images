import React, { useState } from 'react';
import { ArrowDown, Image as ImageIcon } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { EditableText } from './EditableText';
import { useNavigate } from 'react-router-dom';
import { MediaUploadModal } from './MediaUploadModal';

const Hero: React.FC = () => {
  const { data, updateField, isEditMode } = usePortfolio();
  const navigate = useNavigate();
  const [bgModal, setBgModal] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const bgUrl = data.heroBackground || data.backgrounds?.home || '';

  return (
    <section id="home" className="relative min-h-screen py-20 flex items-center justify-center">
      {bgUrl ? (
        <>
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${bgUrl})` }}
          />
          <div className="absolute inset-0 bg-white/50 dark:bg-slate-950/65" />
        </>
      ) : (
        <>
          <div className="absolute inset-0 bg-slate-50 dark:bg-slate-950" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-100 via-transparent to-transparent dark:from-blue-900/20" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-indigo-100 via-transparent to-transparent dark:from-indigo-900/20" />
        </>
      )}

      {isEditMode && (
        <div className="absolute top-24 right-4 z-30 flex flex-col gap-2">
          <button
            type="button"
            onClick={() => setBgModal(true)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-full shadow-lg text-sm font-medium"
          >
            <ImageIcon size={18} />
            {bgUrl ? '更换首屏背景' : '设置首屏背景'}
          </button>
          {bgUrl && (
            <button
              type="button"
              onClick={() => updateField(['heroBackground'], '')}
              className="text-xs text-white/90 bg-black/40 hover:bg-black/60 px-3 py-1.5 rounded-full"
            >
              清除背景图
            </button>
          )}
        </div>
      )}

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="space-y-6 animate-slide-up">
          <h2 className="text-primary font-semibold tracking-wider uppercase text-sm md:text-base">
            你好, 我是
          </h2>
          <EditableText
            as="h1"
            value={data.name}
            onSave={(val) => updateField(['name'], val)}
            className="text-5xl md:text-7xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight drop-shadow-sm block"
          />
          <EditableText
            as="p"
            value={data.tagline}
            onSave={(val) => updateField(['tagline'], val)}
            className="text-xl md:text-2xl text-slate-600 dark:text-gray-300 max-w-2xl mx-auto font-light block"
            multiline
          />

          <div className="pt-10 flex flex-wrap gap-4 justify-center">
            <button
              onClick={() => navigate('/projects')}
              className="inline-block bg-primary hover:bg-blue-600 text-white font-medium px-8 py-3 rounded-full transition-all shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 cursor-pointer w-full sm:w-auto"
            >
              查看我的作品
            </button>
            <button
              onClick={() => navigate('/blog')}
              className="inline-block bg-primary hover:bg-blue-600 text-white font-medium px-8 py-3 rounded-full transition-all shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 cursor-pointer w-full sm:w-auto"
            >
              查看我的空间
            </button>
            <button
              onClick={() => navigate('/discuss')}
              className="inline-block bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 font-medium px-8 py-3 rounded-full transition-all shadow-lg w-full sm:w-auto"
            >
              加入讨论
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button
          onClick={() => scrollToSection('about')}
          className="text-slate-500 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white transition-colors focus:outline-none"
        >
          <ArrowDown className="w-6 h-6" />
        </button>
      </div>

      <MediaUploadModal
        isOpen={bgModal}
        onClose={() => setBgModal(false)}
        onInsert={(url) => updateField(['heroBackground'], url)}
        title="设置首页首屏背景"
        folderPath="hero"
        allowAllMedia={false}
        currentUrl={bgUrl}
      />
    </section>
  );
};

export default Hero;
