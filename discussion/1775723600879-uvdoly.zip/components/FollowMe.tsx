import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { EditableText } from './EditableText';
import { ReorderButtons } from './ReorderButtons';
import { MarkdownEditor } from './MarkdownEditor';
import { EditableImage } from './EditableImage';

export const FollowMe: React.FC = () => {
  const { data, updateField, addArrayItem, removeArrayItem, isEditMode } = usePortfolio();

  const handleAddSocial = () => {
    addArrayItem(['socials'], {
      id: Date.now().toString(),
      name: '新社交账号',
      imageUrl: 'https://placehold.co/100x100/1e293b/FFF?text=Icon',
      url: 'https://example.com',
    });
  };

  return (
    <section className="py-20 bg-gray-50 dark:bg-slate-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">跟随我</h2>
          <div className="w-20 h-1 bg-primary mx-auto rounded-full"></div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-8 mb-20 relative">
          {isEditMode && (
            <button
              onClick={handleAddSocial}
              className="absolute -top-10 right-0 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1 rounded text-sm flex items-center gap-1"
            >
              <Plus size={14} /> 添加社交账号
            </button>
          )}

          {data.socials?.map((social, index) => (
            <div key={social.id || index} className="relative group flex flex-col items-center gap-2">
              {isEditMode && (
                <div className="absolute -top-8 right-0 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                  <ReorderButtons path={['socials']} index={index} totalLength={data.socials.length} className="flex-row scale-75" />
                  <button
                    onClick={() => removeArrayItem(['socials'], index)}
                    className="bg-red-500 hover:bg-red-600 text-white p-1 rounded-full shadow-lg"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              )}
              <div className="flex flex-col items-center gap-4 text-slate-600 dark:text-gray-400 hover:text-primary dark:hover:text-white transition-colors transform hover:scale-[1.02] relative min-w-[160px] min-h-[180px] p-8 bg-white dark:bg-slate-800 rounded-2xl shadow-md hover:shadow-lg border border-gray-100 dark:border-gray-800">
                <div className="w-16 h-16 relative">
                  <EditableImage
                    src={social.imageUrl || 'https://placehold.co/100x100/1e293b/FFF?text=Icon'}
                    alt={social.name}
                    onSave={(val) => updateField(['socials', index.toString(), 'imageUrl'], val)}
                    className="w-full h-full rounded-2xl"
                    folderPath="homepage"
                  />
                </div>
                <EditableText
                  as="span"
                  value={social.name}
                  onSave={(val) => updateField(['socials', index.toString(), 'name'], val)}
                  className="text-base font-medium text-center"
                />
                {!isEditMode && social.url && (
                  <a href={social.url} target="_blank" rel="noreferrer" className="absolute inset-0 rounded-2xl" aria-label={social.name} />
                )}
              </div>
              {isEditMode && (
                <div className="flex flex-col gap-1 mt-1 w-full max-w-[200px]">
                  <label className="text-[10px] text-gray-500">跳转链接</label>
                  <EditableText
                    as="span"
                    value={social.url}
                    onSave={(val) => updateField(['socials', index.toString(), 'url'], val)}
                    className="text-xs text-gray-500 bg-gray-100 dark:bg-slate-800 px-2 py-1 rounded text-center truncate"
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="max-w-4xl mx-auto bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
          <div className="bg-gray-50 dark:bg-slate-900/50 px-6 py-4 border-b border-gray-100 dark:border-gray-700">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              最新发布
            </h3>
          </div>
          <div className="p-6">
            <MarkdownEditor
              value={data.latestRelease || ''}
              onSave={(val) => updateField(['latestRelease'], val)}
              folderPath="latest-release"
              className="text-slate-700 dark:text-gray-300"
            />
          </div>
        </div>
      </div>
    </section>
  );
};
