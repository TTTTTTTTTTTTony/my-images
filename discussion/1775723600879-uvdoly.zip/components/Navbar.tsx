import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { usePortfolio } from "../context/PortfolioContext";
import { EditableImage } from "./EditableImage";
import { NAV_LINKS } from "../constants";
import { AuthModal } from "./AuthModal";
import { UserProfileModal } from "./UserProfileModal";
import {
  LogIn,
  LogOut,
  User,
  Save,
  X,
  Pencil,
  Sun,
  Moon,
  Menu,
} from "lucide-react";
import { UserNotificationBell } from "./UserNotificationBell";

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const {
    data,
    updateField,
    currentUser,
    setCurrentUser,
    isEditMode,
    setIsEditMode,
    beginEdit,
    cancelEdit,
    saveData,
  } = usePortfolio();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleTheme = () => {
    updateField(["theme"], data.theme === "dark" ? "light" : "dark");
  };

  return (
    <>
      <nav
        className={`fixed w-full z-50 transition-all duration-300 ${
          scrolled
            ? "bg-white/90 dark:bg-secondary/90 backdrop-blur-md shadow-lg py-2 border-b border-slate-200/80 dark:border-transparent"
            : "bg-white/50 dark:bg-secondary/50 backdrop-blur-sm py-4"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex-shrink-0 flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg overflow-hidden border border-primary/20 shadow-sm">
                <EditableImage
                  src={
                    data.logoUrl ||
                    "https://static.dingtalk.com/media/lQDPIuzdpr-mLMfNAyDNAyCwr5ccgpAMXMUJTQoKeoVFAA_800_800.jpg_720x720q90.jpg?bizType=im"
                  }
                  alt="Logo"
                  onSave={(val) => updateField(["logoUrl"], val)}
                  className="h-full w-full object-cover"
                  folderPath="homepage"
                />
              </div>
              <Link
                to="/"
                className="font-bold text-xl tracking-tight text-slate-900 dark:text-white cursor-pointer"
                onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              >
                {data.name}
              </Link>
            </div>

            <div className="hidden md:flex items-center">
              <div className="ml-10 flex items-baseline space-x-8">
                {NAV_LINKS.map((link) => {
                  const isActive =
                    link.href === "/"
                      ? location.pathname === "/"
                      : location.pathname === link.href ||
                        location.pathname.startsWith(link.href + "/");
                  const goDiscuss = link.href === "/discuss" && !currentUser;
                  return goDiscuss ? (
                    <button
                      key={link.name}
                      type="button"
                      onClick={() => setIsAuthModalOpen(true)}
                      className="px-3 py-2 rounded-md text-sm font-medium text-slate-600 dark:text-gray-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5"
                    >
                      {link.name}
                    </button>
                  ) : (
                    <Link
                      key={link.name}
                      to={link.href}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        isActive
                          ? "text-primary bg-primary/10"
                          : "text-slate-600 dark:text-gray-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5"
                      }`}
                    >
                      {link.name}
                    </Link>
                  );
                })}
              </div>

              <div className="ml-8 pl-8 border-l border-slate-200 dark:border-gray-700 flex items-center gap-4">
                <button
                  onClick={toggleTheme}
                  className="p-2 text-slate-600 dark:text-gray-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                  title={
                    data.theme === "dark" ? "切换到浅色模式" : "切换到深色模式"
                  }
                >
                  {data.theme === "dark" ? (
                    <Sun size={18} />
                  ) : (
                    <Moon size={18} />
                  )}
                </button>
                {currentUser ? (
                  <div className="flex items-center gap-4">
                    <UserNotificationBell />
                    <button
                      onClick={() => setIsProfileModalOpen(true)}
                      className="flex items-center gap-2 text-sm text-slate-600 dark:text-gray-300 hover:text-slate-900 dark:hover:text-white transition-colors"
                      title="编辑个人信息"
                    >
                      {currentUser.avatar ? (
                        <img
                          src={currentUser.avatar}
                          alt="Avatar"
                          className="w-6 h-6 rounded-full object-cover"
                        />
                      ) : (
                        <User size={16} />
                      )}
                      <span>{currentUser.username}</span>
                      {currentUser.role === "owner" && (
                        <span className="bg-primary/20 text-primary text-xs px-2 py-0.5 rounded">
                          Owner
                        </span>
                      )}
                    </button>
                    {currentUser.role === "owner" && (
                      <>
                        <Link
                          to="/admin"
                          className="text-sm px-3 py-1.5 rounded-md transition-colors bg-blue-500/15 text-blue-700 dark:text-blue-400 border border-blue-500/30 hover:bg-blue-500/25 dark:hover:bg-blue-500/30"
                        >
                          管理面板
                        </Link>
                        {isEditMode ? (
                          <div className="flex items-center gap-2">
                            <button
                              onClick={async () => {
                                await saveData();
                                setIsEditMode(false);
                              }}
                              className="flex items-center gap-1 text-sm px-3 py-1.5 rounded-md transition-colors bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30"
                            >
                              <Save size={14} /> 保存
                            </button>
                            <button
                              onClick={() => cancelEdit()}
                              className="flex items-center gap-1 text-sm px-3 py-1.5 rounded-md transition-colors bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 border border-slate-200 dark:border-gray-700"
                            >
                              <X size={14} /> 取消
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => beginEdit()}
                            className="flex items-center gap-1 text-sm px-3 py-1.5 rounded-md transition-colors bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 border border-slate-200 dark:border-gray-700"
                          >
                            <Pencil size={14} /> 进入编辑
                          </button>
                        )}
                      </>
                    )}
                    <button
                      onClick={() => setCurrentUser(null)}
                      className="text-slate-500 dark:text-gray-400 hover:text-slate-800 dark:hover:text-white transition-colors"
                      title="退出登录"
                    >
                      <LogOut size={18} />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsAuthModalOpen(true)}
                    className="flex items-center gap-2 text-sm font-medium text-slate-600 dark:text-gray-300 hover:text-slate-900 dark:hover:text-white transition-colors"
                  >
                    <LogIn size={16} /> 登录
                  </button>
                )}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center gap-4">
              <button
                onClick={toggleTheme}
                className="p-2 text-slate-600 dark:text-gray-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                {data.theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              {currentUser && <UserNotificationBell />}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-slate-600 dark:text-gray-300 hover:text-primary transition-colors"
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu dropdown */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-gray-800">
            <div className="px-4 pt-2 pb-4 space-y-1">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  className="block px-3 py-2 text-base font-medium text-slate-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary hover:bg-slate-50 dark:hover:bg-slate-800 rounded-md transition-colors"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </Link>
              ))}
              <div className="pt-4 mt-4 border-t border-gray-200 dark:border-gray-800">
                {currentUser ? (
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => {
                        setIsProfileModalOpen(true);
                        setIsMobileMenuOpen(false);
                      }}
                      className="flex items-center gap-2 px-3 py-2 text-base font-medium text-slate-600 dark:text-gray-300 hover:text-primary hover:bg-slate-50 dark:hover:bg-slate-800 rounded-md transition-colors"
                    >
                      {currentUser.avatar ? (
                        <img
                          src={currentUser.avatar}
                          alt="Avatar"
                          className="w-6 h-6 rounded-full object-cover"
                        />
                      ) : (
                        <User size={18} />
                      )}
                      <span>{currentUser.username}</span>
                      {currentUser.role === "owner" && (
                        <span className="bg-primary/20 text-primary text-xs px-2 py-0.5 rounded ml-2">
                          Owner
                        </span>
                      )}
                    </button>

                    {currentUser.role === "owner" && (
                      <>
                        <Link
                          to="/admin"
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="flex items-center gap-2 px-3 py-2 text-base font-medium text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-md transition-colors"
                        >
                          管理面板
                        </Link>
                        {isEditMode ? (
                          <div className="flex flex-col gap-2 px-3 py-2">
                            <button
                              onClick={async () => {
                                await saveData();
                                setIsEditMode(false);
                                setIsMobileMenuOpen(false);
                              }}
                              className="flex items-center justify-center gap-2 w-full py-2 bg-emerald-500 text-white rounded-md"
                            >
                              <Save size={18} /> 保存更改
                            </button>
                            <button
                              onClick={() => {
                                cancelEdit();
                                setIsMobileMenuOpen(false);
                              }}
                              className="flex items-center justify-center gap-2 w-full py-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-gray-300 rounded-md"
                            >
                              <X size={18} /> 取消编辑
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              beginEdit();
                              setIsMobileMenuOpen(false);
                            }}
                            className="flex items-center gap-2 px-3 py-2 text-base font-medium text-slate-600 dark:text-gray-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-md transition-colors"
                          >
                            <Pencil size={18} /> 进入编辑模式
                          </button>
                        )}
                      </>
                    )}

                    <button
                      onClick={() => {
                        setCurrentUser(null);
                        setIsMobileMenuOpen(false);
                      }}
                      className="flex items-center gap-2 px-3 py-2 text-base font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
                    >
                      <LogOut size={18} />
                      退出登录
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setIsAuthModalOpen(true);
                      setIsMobileMenuOpen(false);
                    }}
                    className="flex items-center justify-center gap-2 px-3 py-2 text-base font-medium text-white bg-primary hover:bg-blue-600 rounded-md transition-colors w-full"
                  >
                    <LogIn size={18} />
                    登录 / 注册
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </nav>

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />
    </>
  );
};

export default Navbar;
