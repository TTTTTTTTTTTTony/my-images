import React, { useState, useEffect, useCallback } from 'react';
import { Bell, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';

export const UserNotificationBell: React.FC = () => {
  const { currentUser } = usePortfolio();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<any[]>([]);

  const load = useCallback(async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/notifications?for=${encodeURIComponent(currentUser.username)}`);
      if (res.ok) {
        const d = await res.json();
        setItems(Array.isArray(d.notifications) ? d.notifications : []);
      }
    } catch {
      // ignore
    }
  }, [currentUser]);

  useEffect(() => {
    load();
    const t = setInterval(load, 60000);
    return () => clearInterval(t);
  }, [load]);

  if (!currentUser) return null;

  const unread = items.filter((n) => !n.read).length;

  const markRead = async (ids: string[]) => {
    await fetch('/api/notifications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ forUser: currentUser.username, markReadIds: ids }),
    });
    load();
  };

  const del = async (id: string) => {
    await fetch(`/api/notifications?id=${encodeURIComponent(id)}&for=${encodeURIComponent(currentUser.username)}`, {
      method: 'DELETE',
    });
    load();
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => {
          setOpen(!open);
          load();
        }}
        className="relative p-2 rounded-lg text-slate-600 dark:text-gray-300 hover:bg-slate-100 dark:hover:bg-slate-800"
        aria-label="通知"
      >
        <Bell size={20} />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 flex items-center justify-center rounded-full bg-rose-500 text-white text-[10px] font-bold">
            {unread > 99 ? '99+' : unread}
          </span>
        )}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-[60]" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 w-80 max-h-96 overflow-y-auto bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl shadow-xl z-[70] text-left">
            <div className="px-3 py-2 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center">
              <span className="text-sm font-semibold text-slate-900 dark:text-white">通知</span>
              {unread > 0 && (
                <button
                  type="button"
                  className="text-xs text-primary"
                  onClick={() => markRead(items.filter((n) => !n.read).map((n) => n.id))}
                >
                  全部已读
                </button>
              )}
            </div>
            {items.length === 0 ? (
              <p className="p-4 text-sm text-gray-500 text-center">暂无通知</p>
            ) : (
              items.map((n) => (
                <div
                  key={n.id}
                  className={`px-3 py-2 border-b border-gray-50 dark:border-gray-800 text-sm ${
                    !n.read ? 'bg-primary/5' : ''
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <div className="flex-1 min-w-0">
                      {n.link ? (
                        <Link
                          to={n.link}
                          className="block text-slate-800 dark:text-gray-200 hover:text-primary"
                          onClick={() => {
                            if (!n.read) markRead([n.id]);
                            setOpen(false);
                          }}
                        >
                          {n.body}
                        </Link>
                      ) : (
                        <span className="text-slate-700 dark:text-gray-300">{n.body}</span>
                      )}
                    </div>
                    <button
                      type="button"
                      title="删除通知"
                      className="p-1 rounded text-slate-400 hover:text-red-500 hover:bg-red-500/10"
                      onClick={() => del(n.id)}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1">{new Date(n.created_at).toLocaleString()}</p>
                </div>
              ))
            )}
            <div className="px-3 py-2 border-t border-gray-100 dark:border-gray-800">
              <Link to="/discuss" className="text-xs text-primary" onClick={() => setOpen(false)}>
                打开讨论区
              </Link>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
