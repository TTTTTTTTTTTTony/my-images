import React from 'react';
import { ScanLine, Plus, Trash2 } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { EditableText } from './EditableText';
import { EditableImage } from './EditableImage';
import { ReorderButtons } from './ReorderButtons';
import { ContactMethod } from '../types';
import { LucideIconByName } from './LucideIconByName';

const Contact: React.FC = () => {
  const { data, updateField, addArrayItem, removeArrayItem, isEditMode } = usePortfolio();

  const handleAddEntry = () => {
    const c: ContactMethod = {
      id: Date.now().toString(),
      type: 'entry',
      title: '联系方式',
      subtitle: '',
      href: '',
      icon: 'mail',
    };
    addArrayItem(['contacts'], c);
  };

  const handleAddQr = () => {
    const c: ContactMethod = {
      id: Date.now().toString(),
      type: 'qr',
      title: '扫码联系',
      imageUrl: 'https://placehold.co/300x300/e2e8f0/64748b?text=QR',
      icon: 'scan',
    };
    addArrayItem(['contacts'], c);
  };

  const entries = (data.contacts || []).filter((c) => c.type === 'entry');
  const qrs = (data.contacts || []).filter((c) => c.type === 'qr');

  const renderEntry = (contact: ContactMethod, index: number) => {
    const globalIndex = data.contacts.findIndex((c) => c.id === contact.id);
    const href = contact.href?.trim();
    const inner = (
      <div className="flex items-start gap-3 text-left w-full max-w-xl">
        <span className="mt-0.5 flex-shrink-0">
          <LucideIconByName name={contact.icon || 'link'} size="sm" />
        </span>
        <div className="flex-1 min-w-0">
          <EditableText
            as="div"
            value={contact.title}
            onSave={(val) => updateField(['contacts', globalIndex.toString(), 'title'], val)}
            className="font-semibold text-slate-900 dark:text-white"
          />
          <EditableText
            as="div"
            value={contact.subtitle || ''}
            onSave={(val) => updateField(['contacts', globalIndex.toString(), 'subtitle'], val)}
            className="text-sm text-slate-600 dark:text-gray-400 mt-1"
            multiline
          />
        </div>
      </div>
    );

    return (
      <div
        key={contact.id}
        className="relative group w-full border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 bg-white dark:bg-slate-800/80 shadow-sm"
      >
        {isEditMode && (
          <div className="absolute -top-2 -right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-20">
            <ReorderButtons path={['contacts']} index={globalIndex} totalLength={data.contacts.length} className="flex-row scale-75" />
            <button
              type="button"
              onClick={() => removeArrayItem(['contacts'], globalIndex)}
              className="bg-red-500 text-white p-1.5 rounded-full"
            >
              <Trash2 size={14} />
            </button>
          </div>
        )}
        {href && !isEditMode ? (
          <a href={href} target="_blank" rel="noopener noreferrer" className="block hover:opacity-90">
            {inner}
          </a>
        ) : (
          inner
        )}
        {isEditMode && (
          <div className="mt-2 space-y-1 text-xs">
            <label className="text-gray-500">链接（可留空）</label>
            <EditableText
              as="div"
              value={contact.href || ''}
              onSave={(val) => updateField(['contacts', globalIndex.toString(), 'href'], val)}
              className="text-primary break-all bg-slate-50 dark:bg-slate-900 px-2 py-1 rounded"
            />
            <label className="text-gray-500 block mt-2">图标关键词 / 图片 URL / Emoji</label>
            <EditableText
              as="div"
              value={contact.icon || ''}
              onSave={(val) => updateField(['contacts', globalIndex.toString(), 'icon'], val)}
              className="bg-slate-50 dark:bg-slate-900 px-2 py-1 rounded"
            />
          </div>
        )}
      </div>
    );
  };

  const renderQr = (contact: ContactMethod, index: number) => {
    const globalIndex = data.contacts.findIndex((c) => c.id === contact.id);
    return (
      <div key={contact.id} className="relative group flex flex-col items-center">
        {isEditMode && (
          <div className="absolute -top-2 -right-2 flex gap-1 z-20 opacity-0 group-hover:opacity-100">
            <ReorderButtons path={['contacts']} index={globalIndex} totalLength={data.contacts.length} className="flex-row scale-75" />
            <button type="button" onClick={() => removeArrayItem(['contacts'], globalIndex)} className="bg-red-500 text-white p-1.5 rounded-full">
              <Trash2 size={14} />
            </button>
          </div>
        )}
        <div className="w-44 h-44 sm:w-48 sm:h-48 bg-gray-100 dark:bg-slate-900 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700">
          <EditableImage
            src={contact.imageUrl || ''}
            alt={contact.title}
            onSave={(val) => updateField(['contacts', globalIndex.toString(), 'imageUrl'], val)}
            className="w-full h-full"
            folderPath="homepage/contact-qr"
          />
        </div>
        <div className="mt-2 flex items-center gap-2 text-slate-800 dark:text-gray-200 font-medium text-sm">
          <ScanLine className="w-4 h-4" />
          <EditableText
            as="span"
            value={contact.title}
            onSave={(val) => updateField(['contacts', globalIndex.toString(), 'title'], val)}
          />
        </div>
      </div>
    );
  };

  return (
    <section id="contact" className="py-20 bg-white dark:bg-dark border-t border-gray-200 dark:border-gray-800">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4 text-center">联系我</h2>
        <p className="text-slate-600 dark:text-gray-400 text-lg mb-10 text-center">
          无论是技术交流还是合作机会，我都很乐意与你沟通。
        </p>

        {isEditMode && (
          <div className="absolute right-0 top-0 flex flex-wrap gap-2 justify-end">
            <button type="button" onClick={handleAddEntry} className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-sm flex items-center gap-1">
              <Plus size={14} /> 添加一行联系
            </button>
            <button type="button" onClick={handleAddQr} className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-sm flex items-center gap-1">
              <Plus size={14} /> 添加二维码
            </button>
          </div>
        )}

        {/* 文案 + 链接：纵向排列 */}
        {entries.length > 0 && (
          <div className="flex flex-col items-center gap-4 mb-12">
            {entries.map((c, i) => renderEntry(c, i))}
          </div>
        )}

        {/* 二维码：居中排列 */}
        {qrs.length > 0 && (
          <div className="w-full flex justify-center">
            <div className="flex flex-wrap justify-center items-center gap-6 sm:gap-10">
              {qrs.map((c, i) => renderQr(c, i))}
            </div>
          </div>
        )}

        {(!data.contacts || data.contacts.length === 0) && !isEditMode && (
          <p className="text-center text-gray-500">暂无联系信息</p>
        )}

        <div className="mt-16 text-gray-600 dark:text-gray-500 text-sm text-center">
          <p>
            © {new Date().getFullYear()} {data.name}. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Contact;
