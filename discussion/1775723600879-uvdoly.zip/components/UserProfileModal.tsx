import React, { useState, useEffect } from 'react';
import { X, User, Lock, Image as ImageIcon, Upload, Mail } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { MediaUploadModal } from './MediaUploadModal';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, setCurrentUser } = usePortfolio();
  const [username, setUsername] = useState(currentUser?.username || '');
  const [password, setPassword] = useState('');
  const [avatar, setAvatar] = useState(currentUser?.avatar || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [emailPublic, setEmailPublic] = useState(!!currentUser?.email_public);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [avatarUploadOpen, setAvatarUploadOpen] = useState(false);

  useEffect(() => {
    if (isOpen && currentUser) {
      setUsername(currentUser.username);
      setAvatar(currentUser.avatar || '');
      setEmail(currentUser.email || '');
      setBio(currentUser.bio || '');
      setEmailPublic(!!currentUser.email_public);
      setPassword('');
      setError('');
      setSuccess('');
    }
  }, [isOpen, currentUser]);

  if (!isOpen || !currentUser) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsSubmitting(true);

    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update',
          oldUsername: currentUser.username,
          newUsername: username !== currentUser.username ? username : undefined,
          newPassword: password ? password : undefined,
          avatar,
          email,
          bio,
          email_public: emailPublic ? 1 : 0,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        setCurrentUser(data.user);
        setSuccess('个人信息更新成功！');
        setPassword('');
        setTimeout(() => {
          onClose();
        }, 1500);
      } else {
        setError(data.error || '更新失败');
      }
    } catch (err) {
      setError('网络错误，请稍后重试');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-slide-up border border-gray-100 dark:border-gray-800 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b border-gray-100 dark:border-gray-800 sticky top-0 bg-white dark:bg-slate-900 z-10">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">个人信息</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6">
          {error && (
            <div className="mb-6 p-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg text-sm border border-red-100 dark:border-red-800">
              {error}
            </div>
          )}
          {success && (
            <div className="mb-6 p-3 bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg text-sm border border-green-100 dark:border-green-800">
              {success}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">头像</label>
              <button
                type="button"
                onClick={() => setAvatarUploadOpen(true)}
                className="flex items-center justify-center gap-2 w-full py-2.5 bg-slate-100 dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-lg text-slate-700 dark:text-gray-200 hover:bg-slate-200 dark:hover:bg-slate-700 text-sm font-medium"
              >
                <Upload size={18} /> 上传到 avatars 文件夹
              </button>
              {avatar && (
                <div className="mt-2 flex justify-center">
                  <img src={avatar} alt="Avatar" className="w-16 h-16 rounded-full object-cover border-2 border-primary" />
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">用户名</label>
              <div className="relative">
                <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">邮箱</label>
              <div className="relative">
                <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-primary outline-none dark:text-white"
                  placeholder="选填"
                />
              </div>
              <label className="mt-2 flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={emailPublic}
                  onChange={(e) => setEmailPublic(e.target.checked)}
                  className="rounded border-gray-300 dark:border-gray-600 text-primary"
                />
                在个人资料中公开邮箱
              </label>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">个人介绍</label>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={4}
                className="w-full px-3 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm dark:text-white"
                placeholder="写几句介绍自己…"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                {currentUser?.role === 'owner' ? '主管理员密码只能通过环境变量修改' : '新密码 (留空则不修改)'}
              </label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  disabled={currentUser?.role === 'owner'}
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-primary outline-none dark:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-2.5 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed mt-6"
            >
              {isSubmitting ? '保存中...' : '保存修改'}
            </button>
          </form>
        </div>
      </div>

      <MediaUploadModal
        isOpen={avatarUploadOpen}
        onClose={() => setAvatarUploadOpen(false)}
        onInsert={(url) => setAvatar(url)}
        title="上传头像"
        folderPath="avatars"
        allowAllMedia={false}
        currentUrl={avatar}
      />
    </div>
  );
};
