import React from "react";
import { useNavigate } from "react-router-dom";
import {
  Trophy,
  Calendar,
  Target,
  Rocket,
  BookOpen,
  School,
  Plus,
  Trash2,
} from "lucide-react";
import { usePortfolio } from "../context/PortfolioContext";
import { EditableText } from "./EditableText";
import { EditableImage } from "./EditableImage";
import { ReorderButtons } from "./ReorderButtons";

const About: React.FC = () => {
  const { data, updateField, addArrayItem, removeArrayItem, isEditMode } =
    usePortfolio();
  const navigate = useNavigate();

  const getIcon = (iconName?: string) => {
    switch (iconName) {
      case "study":
        return <BookOpen className="w-16 h-16 text-emerald-400" />;
      case "trophy":
        return <Trophy className="w-16 h-16 text-emerald-400" />;
      case "university":
        return <School className="w-16 h-16 text-emerald-400" />;
      default:
        return <Rocket className="w-16 h-16 text-emerald-400" />;
    }
  };

  const handleAddAchievement = () => {
    addArrayItem(["achievements"], {
      id: Date.now().toString(),
      title: "新成就",
      score: "100",
      description: "成就描述",
      imageUrl: "https://placehold.co/600x400/1e293b/FFF?text=Achievement",
    });
  };

  const handleAddFutureAchievement = () => {
    addArrayItem(["futureAchievements"], {
      id: Date.now().toString(),
      title: "新目标",
      goal: "目标细节",
      description: "目标描述",
      imageUrl: "https://placehold.co/100x100/1e293b/FFF?text=Goal",
    });
  };

  const handleAddExperience = () => {
    addArrayItem(["experience"], {
      id: Date.now().toString(),
      period: "2026 - Present",
      role: "新角色",
      company: "新组织",
      description: ["描述 1"],
      imageUrl: "https://placehold.co/400x300/1e293b/FFF?text=Experience",
    });
  };

  return (
    <>
      <section id="about" className="py-20 bg-gray-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Intro Section */}
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">
              关于我
            </h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full"></div>
            <EditableText
              as="p"
              value={data.about}
              onSave={(val) => updateField(["about"], val)}
              className="mt-6 text-lg text-slate-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed block"
              multiline
            />
          </div>

          {/* Current Achievements Section */}
          <div id="achievements" className="mb-16 relative">
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-8 flex items-center gap-2">
              <Trophy className="text-yellow-500" /> 成就
            </h3>
            {isEditMode && (
              <button
                onClick={handleAddAchievement}
                className="absolute right-0 top-0 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Plus size={18} /> 添加成就
              </button>
            )}

            <div className="space-y-8">
              {data.achievements?.map((achievement, index) => (
                <div
                  key={achievement.id || index}
                  className="relative group grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-white dark:bg-secondary p-8 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xl"
                >
                  {isEditMode && (
                    <div className="absolute top-3 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                      <ReorderButtons
                        path={["achievements"]}
                        index={index}
                        totalLength={data.achievements.length}
                        className="flex-row"
                      />
                      <button
                        onClick={() => removeArrayItem(["achievements"], index)}
                        className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"
                        title="删除成就"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  )}
                  <div
                    className={`order-2 md:order-1 ${!isEditMode ? "cursor-pointer group/item" : ""}`}
                    onClick={() =>
                      !isEditMode && navigate(`/achievements/${achievement.id}`)
                    }
                  >
                    <EditableText
                      as="h4"
                      value={achievement.title}
                      onSave={(val) =>
                        updateField(
                          ["achievements", index.toString(), "title"],
                          val,
                        )
                      }
                      className="text-3xl font-bold text-primary mb-2 block group-hover/item:underline"
                    />
                    <EditableText
                      as="div"
                      value={achievement.score}
                      onSave={(val) =>
                        updateField(
                          ["achievements", index.toString(), "score"],
                          val,
                        )
                      }
                      className="text-4xl font-extrabold text-slate-900 dark:text-white mb-4 block"
                    />
                    <EditableText
                      as="p"
                      value={achievement.description}
                      onSave={(val) =>
                        updateField(
                          ["achievements", index.toString(), "description"],
                          val,
                        )
                      }
                      className="text-gray-400 leading-relaxed block"
                      multiline
                    />
                  </div>
                  <div className="order-1 md:order-2 h-64 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700 relative">
                    <EditableImage
                      src={achievement.imageUrl}
                      alt="Achievement"
                      onSave={(val) =>
                        updateField(
                          ["achievements", index.toString(), "imageUrl"],
                          val,
                        )
                      }
                      className="w-full h-full object-contain"
                      folderPath="homepage"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Future Achievements Section - Green Theme with Icons */}
          <div className="mb-20 relative">
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-8 flex items-center gap-2">
              <Rocket className="text-emerald-400" /> 即将实现的成就 (Goals)
            </h3>
            {isEditMode && (
              <button
                onClick={handleAddFutureAchievement}
                className="absolute right-0 top-0 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Plus size={18} /> 添加目标
              </button>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {data.futureAchievements?.map((item, index) => (
                <div
                  key={item.id || index}
                  className={`relative bg-white dark:bg-secondary/50 rounded-xl overflow-hidden border-2 border-dashed border-gray-200 dark:border-gray-700 hover:border-emerald-500/50 transition-all hover:shadow-lg hover:shadow-emerald-500/10 flex flex-col group ${!isEditMode ? "cursor-pointer" : ""}`}
                  onClick={() =>
                    !isEditMode && navigate(`/future-achievements/${item.id}`)
                  }
                >
                  {isEditMode && (
                    <div className="absolute top-3 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                      <ReorderButtons
                        path={["futureAchievements"]}
                        index={index}
                        totalLength={data.futureAchievements.length}
                        className="flex-row"
                      />
                      <button
                        onClick={() =>
                          removeArrayItem(["futureAchievements"], index)
                        }
                        className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"
                        title="删除目标"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  )}
                  {/* Icon Header Area */}
                  <div className="h-40 relative bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 flex flex-col items-center justify-center group-hover:from-emerald-50 group-hover:to-emerald-100 dark:group-hover:from-gray-800 dark:group-hover:to-emerald-900/30 transition-colors duration-500">
                    <div className="w-20 h-20 relative transform group-hover:scale-110 transition-transform duration-300">
                      <EditableImage
                        src={
                          item.imageUrl ||
                          "https://placehold.co/100x100/1e293b/FFF?text=Goal"
                        }
                        alt={item.title}
                        onSave={(val) =>
                          updateField(
                            [
                              "futureAchievements",
                              index.toString(),
                              "imageUrl",
                            ],
                            val,
                          )
                        }
                        className="w-full h-full object-contain"
                        folderPath="homepage"
                      />
                    </div>
                    <div className="absolute top-2 left-2 bg-emerald-600 text-white text-xs font-bold px-2 py-1 rounded shadow-lg">
                      IN PROGRESS
                    </div>
                  </div>

                  <div className="p-6 flex flex-col flex-grow">
                    <EditableText
                      as="h4"
                      value={item.title}
                      onSave={(val) =>
                        updateField(
                          ["futureAchievements", index.toString(), "title"],
                          val,
                        )
                      }
                      className="text-xl font-bold text-slate-900 dark:text-white mb-1 group-hover:text-emerald-400 transition-colors block"
                    />
                    <EditableText
                      as="div"
                      value={item.goal}
                      onSave={(val) =>
                        updateField(
                          ["futureAchievements", index.toString(), "goal"],
                          val,
                        )
                      }
                      className="text-sm font-semibold text-emerald-400 mb-3 block"
                    />
                    <EditableText
                      as="p"
                      value={item.description}
                      onSave={(val) =>
                        updateField(
                          [
                            "futureAchievements",
                            index.toString(),
                            "description",
                          ],
                          val,
                        )
                      }
                      className="text-gray-400 text-sm leading-relaxed mb-4 flex-grow block"
                      multiline
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Academic Journey (Experience) Section */}
        </div>
      </section>

      <section id="experience" className="py-20 bg-white dark:bg-dark">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-6 relative">
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-8 flex items-center gap-2">
              <Target className="text-primary" /> 成长历程
            </h3>
            {isEditMode && (
              <button
                onClick={handleAddExperience}
                className="absolute right-0 top-0 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors z-10"
              >
                <Plus size={18} /> 添加历程
              </button>
            )}

            <div className="relative border-l-2 border-slate-300 dark:border-gray-700 ml-3 md:ml-6 space-y-12 pb-4">
              {data.experience?.map((item, index) => (
                <div
                  key={item.id || index}
                  className="relative pl-8 md:pl-12 group/exp"
                >
                  {/* Timeline Dot */}
                  <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-primary border-4 border-white dark:border-dark shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>

                  <div
                    className={`relative flex flex-col lg:flex-row gap-6 bg-gray-50 dark:bg-slate-900/50 p-6 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/5 ${!isEditMode ? "cursor-pointer" : ""}`}
                    onClick={() =>
                      !isEditMode && navigate(`/experience/${item.id}`)
                    }
                  >
                    {isEditMode && (
                      <div className="absolute -top-3 -right-3 flex items-center gap-2 opacity-0 group-hover/exp:opacity-100 transition-opacity z-20">
                        <ReorderButtons
                          path={["experience"]}
                          index={index}
                          totalLength={data.experience.length}
                          className="flex-row"
                        />
                        <button
                          onClick={() => removeArrayItem(["experience"], index)}
                          className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"
                          title="删除历程"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    )}

                    {/* Text Content */}
                    <div className="flex-1">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                        <EditableText
                          as="h4"
                          value={item.company}
                          onSave={(val) =>
                            updateField(
                              ["experience", index.toString(), "company"],
                              val,
                            )
                          }
                          className="text-xl font-bold text-slate-900 dark:text-white block"
                        />
                        <div className="flex items-center gap-2 text-primary text-sm font-bold bg-primary/10 px-3 py-1 rounded-full mt-2 sm:mt-0 w-fit">
                          <Calendar className="w-4 h-4" />
                          <EditableText
                            as="span"
                            value={item.period}
                            onSave={(val) =>
                              updateField(
                                ["experience", index.toString(), "period"],
                                val,
                              )
                            }
                          />
                        </div>
                      </div>
                      <EditableText
                        as="div"
                        value={item.role}
                        onSave={(val) =>
                          updateField(
                            ["experience", index.toString(), "role"],
                            val,
                          )
                        }
                        className="text-lg text-slate-700 dark:text-gray-200 font-medium mb-4 block"
                      />
                      <ul className="list-disc list-inside text-slate-600 dark:text-gray-400 space-y-2 text-sm">
                        {item.description.map((desc, i) => (
                          <li key={i} className="relative group/desc">
                            <EditableText
                              as="span"
                              value={desc}
                              onSave={(val) =>
                                updateField(
                                  [
                                    "experience",
                                    index.toString(),
                                    "description",
                                    i.toString(),
                                  ],
                                  val,
                                )
                              }
                            />
                            {isEditMode && (
                              <div className="absolute -left-12 top-0 flex items-center gap-1 opacity-0 group-hover/desc:opacity-100">
                                <ReorderButtons
                                  path={[
                                    "experience",
                                    index.toString(),
                                    "description",
                                  ]}
                                  index={i}
                                  totalLength={item.description.length}
                                  className="flex-row scale-75"
                                />
                                <button
                                  onClick={() =>
                                    removeArrayItem(
                                      [
                                        "experience",
                                        index.toString(),
                                        "description",
                                      ],
                                      i,
                                    )
                                  }
                                  className="text-red-500 hover:text-red-400"
                                >
                                  ×
                                </button>
                              </div>
                            )}
                          </li>
                        ))}
                      </ul>
                      {isEditMode && (
                        <button
                          onClick={() =>
                            addArrayItem(
                              ["experience", index.toString(), "description"],
                              "新描述",
                            )
                          }
                          className="mt-2 text-xs text-emerald-500 hover:text-emerald-400"
                        >
                          + 添加描述
                        </button>
                      )}
                    </div>

                    {/* Image Content */}
                    <div className="w-full lg:w-48 h-32 flex-shrink-0 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 relative">
                      <EditableImage
                        src={
                          item.imageUrl ||
                          "https://placehold.co/400x300/1e293b/FFF?text=Experience"
                        }
                        alt={item.role}
                        onSave={(val) =>
                          updateField(
                            ["experience", index.toString(), "imageUrl"],
                            val,
                          )
                        }
                        className="w-full h-full"
                        folderPath="homepage"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
