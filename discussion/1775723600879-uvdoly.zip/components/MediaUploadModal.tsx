import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X, Upload, Link as LinkIcon, Loader2, Image as ImageIcon, Video } from 'lucide-react';

interface MediaUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsert: (url: string, isVideo: boolean, isAudio?: boolean) => void;
  title?: string;
  folderPath?: string;
  allowAllMedia?: boolean;
  currentUrl?: string;
}

export const MediaUploadModal: React.FC<MediaUploadModalProps> = ({ 
  isOpen, 
  onClose, 
  onInsert, 
  title = "插入媒体",
  folderPath = "uploads",
  allowAllMedia = false,
  currentUrl = ""
}) => {
  const [activeTab, setActiveTab] = useState<'url' | 'upload'>('upload');
  const [urlInput, setUrlInput] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'video' | 'audio'>('image');
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState('');
  /** Default: keep original; enable WebP compression only when checked */
  const [compressEnabled, setCompressEnabled] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setUrlInput(currentUrl || '');
      setError('');
      setMediaType('image');
      setActiveTab('upload');
    }
  }, [isOpen, currentUrl]);

  const handleUrlInsert = () => {
    if (!urlInput.trim()) return;
    let isVid = mediaType === 'video';
    let isAud = mediaType === 'audio';
    if (urlInput.match(/\.(mp4|webm|ogg)$/i)) isVid = true;
    if (urlInput.match(/\.(mp3|wav|m4a)$/i)) isAud = true;
    onInsert(urlInput.trim(), isVid, isAud);
    onClose();
  };

  const compressImageFile = (file: File): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const MAX_WIDTH = 1920;
          const MAX_HEIGHT = 1080;
          
          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          canvas.toBlob((blob) => {
            if (blob) {
              resolve(blob);
            } else {
              reject(new Error('Canvas to Blob failed'));
            }
          }, 'image/webp', 0.8);
        };
        img.onerror = (error) => reject(error);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const fileToBase64 = (file: File | Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = error => reject(error);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setError('');

    try {
      const isVideo = file.type.startsWith('video/');
      const isAudio = file.type.startsWith('audio/');
      let fileToUpload: File | Blob = file;
      let extension = file.name.split('.').pop() || (isVideo ? 'mp4' : (isAudio ? 'mp3' : 'png'));

      if (!isVideo && !isAudio && compressEnabled) {
        fileToUpload = await compressImageFile(file);
        extension = 'webp';
      }

      const base64Content = await fileToBase64(fileToUpload);
      const timestamp = new Date().getTime();
      const randomStr = Math.random().toString(36).substring(2, 8);
      const subPath = `${timestamp}-${randomStr}.${extension}`;

      const response = await fetch('/api/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filename: subPath,
          folderPath: folderPath.replace(/^\/+|\/+$/g, ''),
          message: `Upload ${folderPath}/${subPath} via Portfolio Editor`,
          content: base64Content,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '上传失败');
      }

      onInsert(data.url, isVideo, isAudio);
      onClose();
    } catch (err: any) {
      setError(err.message || '上传失败');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  if (!isOpen) return null;

  const modalContent = (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white dark:bg-slate-900 w-full max-w-md h-[450px] flex flex-col rounded-xl shadow-2xl overflow-hidden border border-gray-200 dark:border-gray-800" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-slate-900/50 flex-shrink-0">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">{title}</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-slate-900 dark:text-gray-400 dark:hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="flex border-b border-gray-200 dark:border-gray-800 flex-shrink-0">
          <button 
            className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === 'upload' ? 'text-primary border-b-2 border-primary bg-primary/5' : 'text-gray-500 dark:text-gray-400 hover:text-slate-900 dark:hover:text-gray-200 hover:bg-gray-50 dark:hover:bg-slate-800/50'}`}
            onClick={() => setActiveTab('upload')}
          >
            <Upload size={16} /> GitHub 上传
          </button>
          <button 
            className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === 'url' ? 'text-primary border-b-2 border-primary bg-primary/5' : 'text-gray-500 dark:text-gray-400 hover:text-slate-900 dark:hover:text-gray-200 hover:bg-gray-50 dark:hover:bg-slate-800/50'}`}
            onClick={() => setActiveTab('url')}
          >
            <LinkIcon size={16} /> 输入链接
          </button>
        </div>

        <div className="p-6 flex-1 overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 bg-red-100 dark:bg-red-500/10 border border-red-200 dark:border-red-500/50 rounded-lg text-red-600 dark:text-red-400 text-sm">
              {error}
            </div>
          )}

          {currentUrl && (
            <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800/50 rounded-lg">
              <p className="text-xs text-blue-600 dark:text-blue-400 font-medium mb-1">当前使用的链接：</p>
              <p className="text-xs text-slate-700 dark:text-gray-300 break-all line-clamp-2" title={currentUrl}>{currentUrl}</p>
            </div>
          )}

          {activeTab === 'upload' && (
            <div className="flex flex-col gap-4">
              <div className="flex flex-col items-center justify-center py-8 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-slate-900/50 hover:bg-gray-100 dark:hover:bg-slate-800/50 hover:border-primary/50 transition-colors cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                <input 
                  type="file" 
                  accept={allowAllMedia ? "image/*,video/*,audio/*" : "image/*"} 
                  className="hidden" 
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  disabled={isUploading}
                />
                {isUploading ? (
                  <div className="flex flex-col items-center gap-3">
                    <Loader2 size={32} className="text-primary animate-spin" />
                    <span className="text-sm text-gray-500 dark:text-gray-400">正在上传...</span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-3 bg-primary/10 rounded-full text-primary">
                      <Upload size={24} />
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-medium text-slate-900 dark:text-white mb-1">点击选择{allowAllMedia ? '图片、视频或音频' : '图片'}</p>
                      <p className="text-xs text-gray-500">将自动上传至服务器</p>
                    </div>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <input 
                  type="checkbox" 
                  id="compressImage" 
                  checked={compressEnabled}
                  onChange={(e) => setCompressEnabled(e.target.checked)}
                  className="rounded border-gray-300 dark:border-gray-600 text-primary focus:ring-primary dark:bg-slate-800"
                />
                <label htmlFor="compressImage" className="text-sm text-gray-600 dark:text-gray-300 cursor-pointer">
                  压缩图片（转为 WebP，减小体积）
                </label>
              </div>
            </div>
          )}

          {activeTab === 'url' && (
            <div className="flex flex-col gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-gray-300 mb-1">媒体链接 (URL)</label>
                <input 
                  type="text" 
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://example.com/image.png"
                  className="w-full bg-gray-50 dark:bg-slate-900 text-slate-900 dark:text-white border border-gray-300 dark:border-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                />
              </div>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer">
                  <input 
                    type="radio" 
                    checked={mediaType === 'image'} 
                    onChange={() => setMediaType('image')}
                    className="text-primary focus:ring-primary border-gray-300 dark:border-gray-700 dark:bg-slate-800"
                  />
                  <ImageIcon size={16} /> 图片
                </label>
                {allowAllMedia && (
                  <>
                    <label className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer">
                      <input 
                        type="radio" 
                        checked={mediaType === 'video'} 
                        onChange={() => setMediaType('video')}
                        className="text-primary focus:ring-primary border-gray-300 dark:border-gray-700 dark:bg-slate-800"
                      />
                      <Video size={16} /> 视频
                    </label>
                    <label className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer">
                      <input 
                        type="radio" 
                        checked={mediaType === 'audio'} 
                        onChange={() => setMediaType('audio')}
                        className="text-primary focus:ring-primary border-gray-300 dark:border-gray-700 dark:bg-slate-800"
                      />
                      <span className="text-xs font-bold">🎵</span> 音频
                    </label>
                  </>
                )}
              </div>
              <button 
                onClick={handleUrlInsert}
                disabled={!urlInput.trim()}
                className="w-full py-2 bg-primary hover:bg-blue-600 disabled:bg-gray-300 disabled:dark:bg-gray-700 disabled:text-gray-500 text-white rounded-lg font-medium transition-colors mt-2"
              >
                确认插入
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return createPortal(modalContent, document.body);
};
