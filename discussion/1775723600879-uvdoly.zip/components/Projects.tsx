import React, { useState } from "react";
import { ExternalLink, Github, Plus, Trash2, Pin, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { usePortfolio } from "../context/PortfolioContext";
import { EditableText } from "./EditableText";
import { EditableImage } from "./EditableImage";
import { ReorderButtons } from "./ReorderButtons";

const Projects: React.FC = () => {
  const { data, updateField, addArrayItem, removeArrayItem, isEditMode } =
    usePortfolio();
  const navigate = useNavigate();
  const [displayCount, setDisplayCount] = useState(9);
  const [pageSize, setPageSize] = useState(9);

  const handleAddProject = () => {
    addArrayItem(["projects"], {
      id: Date.now().toString(),
      title: "新项目名称",
      description: "这里是新项目的描述，你可以点击修改。",
      imageUrl: "https://placehold.co/600x400/1e293b/FFF?text=New+Project",
      tags: ["React", "TypeScript"],
      link: "https://example.com",
      github: "https://github.com",
      pinned: false,
    });
  };

  const pinnedProjects = data.projects.filter((p) => p.pinned);
  const unpinnedProjects = data.projects.filter((p) => !p.pinned);

  return (
    <section id="projects" className="py-20 bg-gray-50 dark:bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 relative">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">
            我的创作
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto rounded-full"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">
            这里的每一个项目都凝聚了我的灵感与心血。
          </p>

          {isEditMode && (
            <button
              onClick={handleAddProject}
              className="absolute right-0 top-0 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Plus size={18} /> 添加项目
            </button>
          )}
        </div>

        {/* Notice Board */}
        {(data.notices?.projects || isEditMode) && (
          <div className="mb-8 p-4 bg-primary/10 border border-primary/20 rounded-xl text-slate-800 dark:text-slate-200 relative group max-w-7xl mx-auto">
            <div className="flex items-start gap-2">
              <span className="text-primary font-bold mt-1">📢 公告：</span>
              <div className="flex-1">
                <EditableText
                  as="div"
                  value={data.notices?.projects || "点击此处编辑公告内容..."}
                  onSave={(val) => updateField(["notices", "projects"], val)}
                  className="w-full"
                  multiline
                />
              </div>
            </div>
            {isEditMode && data.notices?.projects && (
              <button
                onClick={() => updateField(["notices", "projects"], "")}
                className="absolute top-2 right-2 text-red-500 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                title="清除公告"
              >
                <X size={16} />
              </button>
            )}
          </div>
        )}

        {pinnedProjects.length > 0 && (
          <div className="mb-12 max-w-7xl mx-auto">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
              <Pin className="text-amber-500 fill-current" size={20} /> 置顶项目
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {pinnedProjects.map((project) => {
                const index = data.projects.findIndex(
                  (p) => p.id === project.id,
                );
                return (
                  <div
                    key={project.id || index}
                    className={`relative group bg-amber-50/50 dark:bg-amber-900/10 rounded-xl overflow-hidden border border-amber-200/50 dark:border-amber-700/30 hover:border-amber-400/50 transition-all hover:shadow-2xl hover:shadow-amber-500/10 flex flex-col h-full ${!isEditMode ? "cursor-pointer" : ""}`}
                    onClick={() =>
                      !isEditMode && navigate(`/projects/${project.id}`)
                    }
                  >
                    {isEditMode && (
                      <>
                        <div className="absolute top-3 right-3 z-20 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              updateField(
                                ["projects", index.toString(), "pinned"],
                                false,
                              );
                            }}
                            className="p-2 rounded-full shadow-lg bg-amber-500 text-white"
                            title="取消置顶"
                          >
                            <Pin size={16} className="fill-current" />
                          </button>
                        </div>
                        <div
                          className="absolute bottom-3 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-20"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <ReorderButtons
                            path={["projects"]}
                            index={index}
                            totalLength={data.projects.length}
                            className="flex-row"
                          />
                          <button
                            onClick={() => removeArrayItem(["projects"], index)}
                            className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"
                            title="删除项目"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </>
                    )}

                    <div className="relative h-64 overflow-hidden">
                      <EditableImage
                        src={project.imageUrl}
                        alt={project.title}
                        onSave={(val) =>
                          updateField(
                            ["projects", index.toString(), "imageUrl"],
                            val,
                          )
                        }
                        className="w-full h-full"
                        folderPath={`projects/${project.id}`}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-secondary to-transparent opacity-60 pointer-events-none"></div>
                    </div>

                    <div className="p-8 flex flex-col flex-grow">
                      <EditableText
                        as="h3"
                        value={project.title}
                        onSave={(val) =>
                          updateField(
                            ["projects", index.toString(), "title"],
                            val,
                          )
                        }
                        className="text-2xl font-bold text-slate-900 dark:text-white mb-3 group-hover:text-primary transition-colors block"
                      />
                      <EditableText
                        as="p"
                        value={project.description}
                        onSave={(val) =>
                          updateField(
                            ["projects", index.toString(), "description"],
                            val,
                          )
                        }
                        className="text-slate-600 dark:text-gray-400 text-base mb-6 flex-grow leading-relaxed block"
                        multiline
                      />

                      <div className="flex flex-wrap gap-2 mb-8">
                        {project.tags.map((tag, tagIndex) => (
                          <div key={tagIndex} className="relative group/tag">
                            <EditableText
                              as="span"
                              value={tag}
                              onSave={(val) =>
                                updateField(
                                  [
                                    "projects",
                                    index.toString(),
                                    "tags",
                                    tagIndex.toString(),
                                  ],
                                  val,
                                )
                              }
                              className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-slate-600 dark:text-gray-300 text-sm rounded-full border border-gray-200 dark:border-gray-700 block"
                            />
                            {isEditMode && (
                              <div className="absolute -top-3 -right-3 flex items-center gap-1 opacity-0 group-hover/tag:opacity-100">
                                <ReorderButtons
                                  path={["projects", index.toString(), "tags"]}
                                  index={tagIndex}
                                  totalLength={project.tags.length}
                                  className="flex-row scale-75"
                                />
                                <button
                                  onClick={() =>
                                    removeArrayItem(
                                      ["projects", index.toString(), "tags"],
                                      tagIndex,
                                    )
                                  }
                                  className="bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px]"
                                >
                                  ×
                                </button>
                              </div>
                            )}
                          </div>
                        ))}
                        {isEditMode && (
                          <button
                            onClick={() =>
                              addArrayItem(
                                ["projects", index.toString(), "tags"],
                                "新标签",
                              )
                            }
                            className="px-3 py-1 bg-gray-100/50 dark:bg-gray-800/50 text-slate-500 dark:text-gray-400 text-sm rounded-full border border-gray-300 dark:border-gray-700 border-dashed hover:bg-gray-200 dark:hover:bg-gray-700"
                          >
                            + 标签
                          </button>
                        )}
                      </div>

                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-auto">
                        <div className="flex items-center gap-2">
                          <ExternalLink className="w-4 h-4 text-primary" />
                          <EditableText
                            as="span"
                            value={project.link || "https://"}
                            onSave={(val) =>
                              updateField(
                                ["projects", index.toString(), "link"],
                                val,
                              )
                            }
                            className="text-primary font-medium hover:text-blue-400 transition-colors text-sm"
                          />
                        </div>
                        <div className="flex items-center gap-2 sm:ml-auto">
                          <Github className="w-4 h-4 text-slate-400 dark:text-gray-400" />
                          <EditableText
                            as="span"
                            value={project.github || "https://github.com"}
                            onSave={(val) =>
                              updateField(
                                ["projects", index.toString(), "github"],
                                val,
                              )
                            }
                            className="text-slate-500 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white transition-colors text-sm"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="flex justify-end mb-4 max-w-7xl mx-auto">
          <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-gray-400">
            每页
            <select
              value={pageSize}
              onChange={(e) => {
                const newSize = Number(e.target.value);
                setPageSize(newSize);
                setDisplayCount(newSize);
              }}
              className="bg-white dark:bg-slate-800 border border-gray-300 dark:border-gray-700 rounded px-2 py-1"
            >
              {[9, 18, 27].map((n) => (
                <option key={n} value={n}>
                  {n} 个
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {unpinnedProjects.slice(0, displayCount).map((project) => {
            const index = data.projects.findIndex((p) => p.id === project.id);
            return (
              <div
                key={project.id || index}
                className={`relative group bg-white dark:bg-secondary rounded-xl overflow-hidden border border-gray-200 dark:border-gray-800 hover:border-primary/50 transition-all hover:shadow-2xl hover:shadow-primary/10 flex flex-col h-full ${!isEditMode ? "cursor-pointer" : ""}`}
                onClick={() =>
                  !isEditMode && navigate(`/projects/${project.id}`)
                }
              >
                {isEditMode && (
                  <>
                    <div className="absolute top-3 right-3 z-20 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          updateField(
                            ["projects", index.toString(), "pinned"],
                            true,
                          );
                        }}
                        className="p-2 rounded-full shadow-lg bg-slate-700 text-gray-300 hover:bg-slate-600"
                        title="置顶"
                      >
                        <Pin size={16} />
                      </button>
                    </div>
                    <div
                      className="absolute bottom-3 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-20"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ReorderButtons
                        path={["projects"]}
                        index={index}
                        totalLength={data.projects.length}
                        className="flex-row"
                      />
                      <button
                        onClick={() => removeArrayItem(["projects"], index)}
                        className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"
                        title="删除项目"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </>
                )}

                <div className="relative h-64 overflow-hidden">
                  <EditableImage
                    src={project.imageUrl}
                    alt={project.title}
                    onSave={(val) =>
                      updateField(
                        ["projects", index.toString(), "imageUrl"],
                        val,
                      )
                    }
                    className="w-full h-full"
                    folderPath={`projects/${project.id}`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-secondary to-transparent opacity-60 pointer-events-none"></div>
                </div>

                <div className="p-8 flex flex-col flex-grow">
                  <EditableText
                    as="h3"
                    value={project.title}
                    onSave={(val) =>
                      updateField(["projects", index.toString(), "title"], val)
                    }
                    className="text-2xl font-bold text-slate-900 dark:text-white mb-3 group-hover:text-primary transition-colors block"
                  />
                  <EditableText
                    as="p"
                    value={project.description}
                    onSave={(val) =>
                      updateField(
                        ["projects", index.toString(), "description"],
                        val,
                      )
                    }
                    className="text-slate-600 dark:text-gray-400 text-base mb-6 flex-grow leading-relaxed block"
                    multiline
                  />

                  <div className="flex flex-wrap gap-2 mb-8">
                    {project.tags.map((tag, tagIndex) => (
                      <div key={tagIndex} className="relative group/tag">
                        <EditableText
                          as="span"
                          value={tag}
                          onSave={(val) =>
                            updateField(
                              [
                                "projects",
                                index.toString(),
                                "tags",
                                tagIndex.toString(),
                              ],
                              val,
                            )
                          }
                          className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-slate-600 dark:text-gray-300 text-sm rounded-full border border-gray-200 dark:border-gray-700 block"
                        />
                        {isEditMode && (
                          <div className="absolute -top-3 -right-3 flex items-center gap-1 opacity-0 group-hover/tag:opacity-100">
                            <ReorderButtons
                              path={["projects", index.toString(), "tags"]}
                              index={tagIndex}
                              totalLength={project.tags.length}
                              className="flex-row scale-75"
                            />
                            <button
                              onClick={() =>
                                removeArrayItem(
                                  ["projects", index.toString(), "tags"],
                                  tagIndex,
                                )
                              }
                              className="bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px]"
                            >
                              ×
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                    {isEditMode && (
                      <button
                        onClick={() =>
                          addArrayItem(
                            ["projects", index.toString(), "tags"],
                            "新标签",
                          )
                        }
                        className="px-3 py-1 bg-gray-100/50 dark:bg-gray-800/50 text-slate-500 dark:text-gray-400 text-sm rounded-full border border-gray-300 dark:border-gray-700 border-dashed hover:bg-gray-200 dark:hover:bg-gray-700"
                      >
                        + 标签
                      </button>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-auto">
                    <div className="flex items-center gap-2">
                      <ExternalLink className="w-4 h-4 text-primary" />
                      <EditableText
                        as="span"
                        value={project.link || "https://"}
                        onSave={(val) =>
                          updateField(
                            ["projects", index.toString(), "link"],
                            val,
                          )
                        }
                        className="text-primary font-medium hover:text-blue-400 transition-colors text-sm"
                      />
                    </div>
                    <div className="flex items-center gap-2 sm:ml-auto">
                      <Github className="w-4 h-4 text-slate-400 dark:text-gray-400" />
                      <EditableText
                        as="span"
                        value={project.github || "https://github.com"}
                        onSave={(val) =>
                          updateField(
                            ["projects", index.toString(), "github"],
                            val,
                          )
                        }
                        className="text-slate-500 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white transition-colors text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {!isEditMode && unpinnedProjects.length > displayCount && (
          <div className="mt-12 text-center">
            <button
              onClick={() => setDisplayCount((prev) => prev + pageSize)}
              className="px-6 py-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-full text-slate-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors shadow-sm"
            >
              加载更多项目
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default Projects;
