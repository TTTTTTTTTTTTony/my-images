import React from 'react';
import {
  Link as LinkIcon,
  Github,
  Twitter,
  Linkedin,
  Tv,
  BookOpen,
  Mail,
  MessageCircle,
  Youtube,
  Instagram,
  Facebook,
  Music2,
  Globe,
  Rss,
  Send,
} from 'lucide-react';

const sizeMap = { sm: 20, md: 28, lg: 40 };

type SizeKey = keyof typeof sizeMap;

function wrap(node: React.ReactNode, key?: string) {
  return (
    <span key={key} className="inline-flex items-center justify-center text-slate-700 dark:text-slate-200">
      {node}
    </span>
  );
}

/**
 * Renders a Lucide icon by keyword, a custom image URL, or falls back to emoji/text.
 */
export function LucideIconByName({
  name,
  size = 'md',
  className = '',
}: {
  name: string;
  size?: SizeKey;
  className?: string;
}) {
  const s = sizeMap[size];
  const n = (name || '').trim();
  if (!n) return wrap(<LinkIcon size={s} className={className} />);

  if (/^https?:\/\//i.test(n)) {
    return (
      <img
        src={n}
        alt=""
        className={`rounded object-cover ${size === 'lg' ? 'w-14 h-14' : size === 'md' ? 'w-10 h-10' : 'w-6 h-6'} ${className}`}
      />
    );
  }

  const lower = n.toLowerCase();
  const icon = (() => {
    switch (lower) {
      case 'bilibili':
      case '哔哩':
        return <Tv size={s} className={className} />;
      case 'zhihu':
      case '知乎':
        return <BookOpen size={s} className={className} />;
      case 'github':
        return <Github size={s} className={className} />;
      case 'twitter':
      case 'x':
        return <Twitter size={s} className={className} />;
      case 'linkedin':
        return <Linkedin size={s} className={className} />;
      case 'youtube':
        return <Youtube size={s} className={className} />;
      case 'instagram':
        return <Instagram size={s} className={className} />;
      case 'facebook':
        return <Facebook size={s} className={className} />;
      case 'mail':
      case 'email':
      case '邮箱':
        return <Mail size={s} className={className} />;
      case 'music':
      case '网易云':
        return <Music2 size={s} className={className} />;
      case 'telegram':
        return <Send size={s} className={className} />;
      case 'rss':
        return <Rss size={s} className={className} />;
      case 'wechat':
      case '微信':
        return <MessageCircle size={s} className={className} />;
      case 'link':
      case 'url':
      case '网站':
        return <LinkIcon size={s} className={className} />;
      case 'web':
      case 'globe':
        return <Globe size={s} className={className} />;
      default:
        return null;
    }
  })();

  if (icon) return wrap(icon);

  // Emoji or short text label
  return wrap(
    <span className={`select-none leading-none ${size === 'lg' ? 'text-4xl' : size === 'md' ? 'text-3xl' : 'text-xl'} ${className}`}>
      {n}
    </span>
  );
}
