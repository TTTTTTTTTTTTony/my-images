import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Sparkles, Loader2 } from 'lucide-react';
import { ChatMessage, ChatSender } from '../types';
import { usePortfolio } from '../context/PortfolioContext';
import { sendMessageStream } from '../services/geminiService';

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { data } = usePortfolio();
  
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: ChatSender.Bot,
      text: `Hi there! I'm ${data.name.split(' ')[0]}'s AI Assistant. Ask me anything about my experience, skills, or projects!`
    }
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen, isLoading]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessageId = Date.now().toString() + Math.random().toString(36).substring(2, 9);
    const userMessage: ChatMessage = {
      id: userMessageId,
      sender: ChatSender.User,
      text: input.trim()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const botMessageId = (Date.now() + 1).toString() + Math.random().toString(36).substring(2, 9);
    // Initialize empty bot message with streaming state
    setMessages(prev => [...prev, {
      id: botMessageId,
      sender: ChatSender.Bot,
      text: '',
      isStreaming: true
    }]);

    try {
      let accumulatedText = '';
      const stream = sendMessageStream(userMessage.text);
      
      for await (const chunk of stream) {
        accumulatedText += chunk;
        setMessages(prev => prev.map(msg => 
          msg.id === botMessageId 
            ? { ...msg, text: accumulatedText } 
            : msg
        ));
      }
    } catch (error) {
      console.error("Chat Error", error);
    } finally {
      // Ensure streaming indicator is turned off
      setMessages(prev => prev.map(msg => 
        msg.id === botMessageId 
          ? { ...msg, isStreaming: false } 
          : msg
      ));
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <>
      {/* Trigger Button */}
      <button
        id="chat-trigger-btn"
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 z-40 bg-primary hover:bg-blue-600 text-white p-4 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-110 ${isOpen ? 'scale-0 opacity-0 pointer-events-none' : 'scale-100 opacity-100'}`}
        aria-label="Open Chat"
      >
        <MessageSquare className="w-6 h-6" />
      </button>

      {/* Chat Window */}
      <div 
        className={`fixed bottom-6 right-6 w-[90vw] sm:w-[400px] h-[500px] bg-secondary rounded-2xl shadow-2xl border border-gray-700 z-50 flex flex-col transition-all duration-300 origin-bottom-right ${isOpen ? 'scale-100 opacity-100 translate-y-0' : 'scale-95 opacity-0 translate-y-10 pointer-events-none'}`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700 bg-gray-800/50 rounded-t-2xl">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <h3 className="text-white font-medium flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              AI Assistant
            </h3>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex ${msg.sender === ChatSender.User ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed ${
                  msg.sender === ChatSender.User 
                    ? 'bg-primary text-white rounded-br-none' 
                    : 'bg-gray-800 text-gray-200 rounded-bl-none border border-gray-700'
                }`}
              >
                {msg.text}
                {msg.isStreaming && (
                   <span className="inline-block w-1.5 h-4 ml-1 align-middle bg-primary animate-pulse" />
                )}
              </div>
            </div>
          ))}
          {/* Show loader only if we are loading AND the last message hasn't started streaming text yet (text is empty) */}
          {isLoading && messages[messages.length - 1]?.text === '' && (
             <div className="flex justify-start">
               <div className="bg-gray-800 p-3 rounded-2xl rounded-bl-none border border-gray-700">
                  <Loader2 className="w-4 h-4 text-gray-400 animate-spin" />
               </div>
             </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-700 bg-gray-800/30 rounded-b-2xl">
          <div className="flex items-center gap-2">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Ask about my skills..."
              className="flex-1 bg-gray-900 border border-gray-700 rounded-full px-4 py-2 text-white focus:outline-none focus:border-primary transition-colors text-sm"
              disabled={isLoading}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="bg-primary hover:bg-blue-600 disabled:opacity-50 disabled:hover:bg-primary text-white p-2 rounded-full transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <div className="text-[10px] text-gray-500 text-center mt-2">
            Powered by Google Gemini
          </div>
        </div>
      </div>
    </>
  );
};

export default ChatBot;