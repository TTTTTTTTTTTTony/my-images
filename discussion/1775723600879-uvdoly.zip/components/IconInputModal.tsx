import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { LucideIconByName } from './LucideIconByName';

export function IconInputModal({
  open,
  title,
  initialValue,
  onClose,
  onSave,
}: {
  open: boolean;
  title: string;
  initialValue: string;
  onClose: () => void;
  onSave: (val: string) => void;
}) {
  const [val, setVal] = useState(initialValue || '');

  useEffect(() => {
    if (open) setVal(initialValue || '');
  }, [open, initialValue]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[260] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
          <div className="font-bold">{title}</div>
          <button type="button" onClick={onClose} className="text-gray-500 hover:text-slate-900 dark:hover:text-white">
            <X size={20} />
          </button>
        </div>
        <div className="p-5 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
              <LucideIconByName name={val} size="lg" />
            </div>
            <div className="text-xs text-gray-500 leading-relaxed">
              支持：Emoji（如 😀）、系统图标名（如 github / bilibili / mail）、或图片 URL（以 http 开头）
            </div>
          </div>
          <input
            value={val}
            onChange={(e) => setVal(e.target.value)}
            placeholder="例如：github / 😀 / https://..."
            className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-slate-900 text-sm"
            autoFocus
          />
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 text-sm hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              取消
            </button>
            <button
              type="button"
              onClick={() => {
                onSave(val.trim());
                onClose();
              }}
              className="px-4 py-2 rounded-lg bg-primary text-white text-sm hover:bg-blue-600"
            >
              保存
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

