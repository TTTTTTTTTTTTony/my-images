import React, { useState } from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { Image as ImageIcon } from 'lucide-react';
import { MediaUploadModal } from './MediaUploadModal';

interface EditableImageProps {
  src: string;
  alt: string;
  onSave: (val: string) => void;
  className?: string;
  folderPath?: string;
}

export const EditableImage: React.FC<EditableImageProps> = ({ src, alt, onSave, className = '', folderPath = 'images' }) => {
  const { isEditMode } = usePortfolio();
  const [isModalOpen, setIsModalOpen] = useState(false);

  if (!isEditMode) {
    return (
      <img 
        src={src} 
        alt={alt} 
        className={`${className.includes('object-') ? '' : 'object-cover'} ${className}`}
        onError={(e) => {
          (e.target as HTMLImageElement).src = `https://placehold.co/600x400/1e293b/FFF?text=${alt}`;
        }}
      />
    );
  }

  return (
    <>
      <div className={`relative group cursor-pointer ${className}`} onClick={() => setIsModalOpen(true)}>
        <img 
          src={src} 
          alt={alt} 
          className={`w-full h-full opacity-60 group-hover:opacity-30 transition-opacity ${className.includes('object-') ? '' : 'object-cover'} ${className}`} 
          onError={(e) => {
            (e.target as HTMLImageElement).src = `https://placehold.co/600x400/1e293b/FFF?text=${alt}`;
          }}
        />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="bg-black/80 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-bold shadow-lg transform group-hover:scale-110 transition-transform">
            <ImageIcon size={20} /> 点击修改图片
          </div>
        </div>
      </div>

      <MediaUploadModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onInsert={(url, isVideo) => onSave(url)} 
        title="更改图片"
        folderPath={folderPath}
        allowAllMedia={false}
        currentUrl={src}
      />
    </>
  );
};
