import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import ProjectsPage from './pages/ProjectsPage';
import BlogPage from './pages/BlogPage';
import { AdminDashboard } from './pages/AdminDashboard';
import DiscussPage from './pages/DiscussPage';
import DetailPage from './pages/DetailPage';
import { PortfolioProvider, usePortfolio } from './context/PortfolioContext';

function AppContent() {
  const { data, portfolioLoaded } = usePortfolio();
  useEffect(() => {
    // Update favicon when logoUrl changes
    if (data.logoUrl) {
      let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.head.appendChild(link);
      }
      link.href = data.logoUrl;
    }
  }, [data.logoUrl]);

  useEffect(() => {
    if (data.theme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  }, [data.theme]);

  if (!portfolioLoaded) {
    return (
      <div className="min-h-screen bg-white dark:bg-dark text-slate-900 dark:text-slate-200 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-slate-500 dark:text-slate-400">加载中…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-200 dark:from-dark dark:to-dark dark:bg-dark text-slate-900 dark:text-slate-200 selection:bg-primary/30 selection:text-white transition-colors duration-300">
      <Navbar />
      <div className="">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/projects/:id" element={<ProjectsPage />} />
          <Route path="/achievements/:id" element={<DetailPage />} />
          <Route path="/future-achievements/:id" element={<DetailPage />} />
          <Route path="/experience/:id" element={<DetailPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:id" element={<BlogPage />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/users" element={<AdminDashboard />} />
          <Route path="/admin/comments" element={<AdminDashboard />} />
          <Route path="/discuss" element={<DiscussPage />} />
        </Routes>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <PortfolioProvider>
        <AppContent />
      </PortfolioProvider>
    </Router>
  );
}

export default App;