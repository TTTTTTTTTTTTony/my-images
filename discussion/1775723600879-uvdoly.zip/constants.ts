import { ProfileData } from './types';

export const PROFILE_DATA: ProfileData = {
  logoUrl: "https://placehold.co/800x800/1e293b/FFF?text=Logo",
  name: "请填写姓名",
  title: "请填写头衔",
  tagline: "请填写一句话简介",
  about: "请填写关于我的详细介绍...",
  location: "请填写位置",
  socials: [],
  contacts: [],
  skills: [],
  achievements: [],
  futureAchievements: [],
  experience: [],
  projects: [],
  blogCategories: ["未分类"],
  blogPosts: [],
  theme: 'dark',
  heroBackground: '',
  backgrounds: {
    home: '',
    projects: '',
    blog: ''
  },
  banners: {
    projects: '',
    blog: ''
  },
  notices: {
    projects: '请填写作品页公告',
    blog: '请填写博客页公告'
  },
  latestRelease: '### 最新发布\n\n这里是最新发布的内容，支持 **Markdown** 语法。'
};

export const NAV_LINKS: { name: string; href: string; requireAuth?: boolean }[] = [
  { name: '首页', href: '/' },
  { name: '我的作品', href: '/projects' },
  { name: '我的空间', href: '/blog' },
  { name: '讨论', href: '/discuss', requireAuth: true },
];
