import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { PROFILE_DATA } from "../constants";

let chatSession: Chat | null = null;
let genAI: GoogleGenAI | null = null;

const getGenAI = (): GoogleGenAI => {
  if (!genAI) {
    if (!process.env.API_KEY) {
      throw new Error("API Key missing");
    }
    // API_KEY is guaranteed to be available in the environment if the check passes
    genAI = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return genAI;
};

const SYSTEM_INSTRUCTION = `
You are the AI Digital Twin of ${PROFILE_DATA.name}, a ${PROFILE_DATA.title}.
Your goal is to answer questions about ${PROFILE_DATA.name}'s professional background, skills, projects, and experience based STRICTLY on the context provided below.

CONTEXT DATA:
${JSON.stringify(PROFILE_DATA, null, 2)}

BEHAVIOR GUIDELINES:
1. Tone: Professional, friendly, enthusiastic, and concise.
2. If asked about contact info, provide the email or social links from the data.
3. If asked about something not in the data (like personal address, political views, or unrelated topics), politely decline and steer the conversation back to professional skills or projects.
4. Do not hallucinate experiences not listed in the context.
5. Keep answers relatively short (under 100 words) unless specifically asked for details.
6. You represent ${PROFILE_DATA.name} directly. You can say "I" or "My" when referring to the portfolio owner, or speak in third person if it feels more natural, but first person ("I have experience in...") is preferred for a personal touch.
`;

export const getChatSession = (): Chat => {
  if (!chatSession) {
    const ai = getGenAI();
    chatSession = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
  }
  return chatSession;
};

export async function* sendMessageStream(message: string) {
  try {
    // Initialize session inside try block to catch initialization errors (e.g., missing API key)
    const chat = getChatSession();
    const responseStream = await chat.sendMessageStream({ message });
    
    for await (const chunk of responseStream) {
      const c = chunk as GenerateContentResponse;
      if (c.text) {
        yield c.text;
      }
    }
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    yield "I'm having a little trouble connecting right now. Please check if the API key is configured correctly or try again later.";
  }
}